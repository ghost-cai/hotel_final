<template>
  <div id="app" v-title data-title="NJUSE酒店管理系统">
    <transition name="fade-transform" mode="out-in">
      <router-view/>
<!--            因为app是所有组件的父组件，不需要配置child路由-->
    </transition>
  </div>
</template>
<script>
export default {
  components: {
    
  }
}
</script>
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  width: 100%;
  /*曾经没有为了让login占满*/
  padding: 0px 0px 0px;
  /*padding: 0px 0px 144px;把下面的144px去掉了*/
  background: #F9F8F6 ;
  min-height: 800px;
}
/*url('assets/background.svg') repeat 100%;*/

#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}

/* fade-transform */
.fade-transform-leave-active,
.fade-transform-enter-active {
  transition: all .5s;
}

.fade-transform-enter {
  opacity: 0;
  transform: translateX(-30px);
}

.fade-transform-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
</style>
