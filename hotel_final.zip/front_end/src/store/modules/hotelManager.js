import {
    addRoomAPI,
    addHotelAPI,
    mgrHotelListAPI,
    submitManageHotelParamsAPI,
    submitRoomRepoEmptyCntAPI,
    senthotelimgAPI
} from '@/api/hotelManager'
import {
    managedOrdersAPI,
    roomTypeInfoAPI,
    getCurrPeriodRepoAPI,
    addRoomTypeAPI,
    setRoomPriceByRoomIdAPI
} from '@/api/hotel'
import {
    getAllOrdersAPI,
    deleteOrderAPI,
    checkInAPI,
    checkOutAPI,
    abnormalOrdersOfTheDayAPI,
} from '@/api/order'
import {
    hotelAllCouponsAPI,
    hotelTargetMoneyAPI,
    hotelFestivalAPI,
} from '@/api/coupon'
import { message } from 'ant-design-vue'

const hotelManager = {
    state: {
        priceVisible: false,
        roomTypeInfo: [],
        unusualOrderList: [],
        managedOrders: [],
        mgrHotelList: [],
        orderList: [],
        roomManageDrawerVisible: false,
        addHotelModalVisible: false,
        manageRoomVisible: true,
        addRoomParams: {
            roomType: '',
            hotelId: '',
            price: '',
            total: 0,
            curNum: 0,
        },
        addRoomTypeVisible:false,
        addRoomModalVisible: false,
        couponVisible: false,
        addCouponVisible: false,
        unusualOrderVisible: false,
        manageHotelVisible: false,
        activeHotelId: 0,
        activeRoomId: -1,
        couponList: [],
        searchedRoomRepoList: [],
        roomCntModifyModalVisible: false,
        addhotelpicVisible:false
    },
    mutations: {
        set_roomCntModifyModalVisible: function (state, data) {
            state.roomCntModifyModalVisible = data
        },
        set_searchedRoomRepoList: function (state, data) {
            data.sort(function (a, b) {
                return Date.parse(a.date) - Date.parse(b.date)
            })
            state.searchedRoomRepoList = data;
        },

        set_roomTypeInfo: function (state, data) {
            state.roomTypeInfo = data
            console.log(state.roomTypeInfo )
        },
        set_activeRoomId: function (state, data) {
            state.activeRoomId = data
            console.log(state.activeRoomId )
        },
        set_priceVisible: function(state, data) {
            state.priceVisible = data
        },
        set_roomManageDrawerVisible: function(state, data) {
            state.roomManageDrawerVisible = data
        },
        set_managedOrders: function(state, data) {
            state.managedOrders = data
        },
        set_orderList: function(state, data) {
            state.orderList = data
        },
        set_mgrHotelList: function(state, data) {
            state.mgrHotelList = data
        },
        set_addHotelModalVisible: function(state, data) {
            state.addHotelModalVisible = data
        },
        set_manageRoomVisible: function(state, data) {
            state.manageRoomVisible = data
        },
        set_unusualOrderVisible: function(state, data) {
            state.unusualOrderVisible = data

        },
        set_addHotelParams: function(state, data) {
            state.addHotelParams = {
                ...state.addHotelParams,
                ...data,
            }
        },
        set_addRoomModalVisible: function(state, data) {
            state.addRoomModalVisible = data
        },
        set_addRoomParams: function(state, data) {
            state.addRoomParams = {
                ...state.addRoomParams,
                ...data,
            }
        },
        set_couponVisible: function(state, data) {
            state.couponVisible = data
        },
        set_activeHotelId: function(state, data) {
            state.activeHotelId = data
        },
        set_couponList: function(state, data) {
            state.couponList = data
        },
        set_addCouponVisible: function(state, data) {
            state.addCouponVisible =data
        },
        set_unusualOrderList: (state, data) => {
            state.unusualOrderList = data
            console.log(state.unusualOrderList)
        },
        set_manageHotelVisible: function (state, data) {
            state.manageHotelVisible = data;
        },
        set_addRoomTypeVisible: function (state, data) {
            state.addRoomTypeVisible = data;
        },
        set_addhotelpicVisible: function (state, data) {
            state.addhotelpicVisible = data
        },
    },
    actions: {
        getRoomTypeInfo: async ({state, commit}, hotelId) => {
            const res = await roomTypeInfoAPI(hotelId)
            if (res) {
                commit('set_roomTypeInfo', res)
            }
        },
        getAllOrders: async({ state, commit }) => {

            const res = await getAllOrdersAPI()
            if(res){
                commit('set_orderList', res)
            }
        },
        getUnusualOrderList: async({ state,commit },id) => {
            const res = await abnormalOrdersOfTheDayAPI(id)
            // console.log(id)
            if(res){
                commit('set_unusualOrderList', res)
            }
        },
        addHotel: async({ state, commit,dispatch},data) => {
            const res = await addHotelAPI(data)
            if(res){
                dispatch('getMgrHotelList', data.managerId)
                commit('set_addHotelModalVisible', false)
                message.success('添加成功')
            }else{
                message.error('添加失败')
            }
        },
        addRoom: async({ state, dispatch, commit }) => {
            const res = await addRoomAPI(state.addRoomParams)
            console.log(state.addRoomParams.roomTime)
            if(res){
                commit('set_addRoomModalVisible', false)
                commit('set_addRoomParams', {
                    roomType: '',
                    hotelId: '',
                    price: '',
                    total: 0,
                    curNum: 0,
                })
                message.success('添加成功');
            }else{
                message.error('添加失败');
            }
        },
        getHotelCoupon: async({ state, commit }) => {
            const res = await hotelAllCouponsAPI(state.activeHotelId)
            if(res) {
                // 获取到酒店策略之后的操作（将获取到的数组赋值给couponList）
                commit('set_couponList', res)
            }
        },
        addHotelCoupon: async({ commit, dispatch }, data) => {
            // console.log(data);
            // console.log('优惠券类型')
            // console.log(data.type)
            let res={};
            if(data.type==3){
                 res= await hotelTargetMoneyAPI(data);
            }else if(data.type==4){
                // console.log('zhiixingl')
                 res= await hotelFestivalAPI(data);
            }else {
                // console.log('zhiixingl')
                 res= await hotelFestivalAPI(data);
            }
            if(res){
                // 添加成功后的操作（提示文案、modal框显示与关闭，调用优惠列表策略等）
                dispatch('getHotelCoupon');
                commit('set_addCouponVisible', false);
                commit('set_couponVisible',true);
                message.success('添加优惠劵成功');
            }else{
                // 添加失败后的操作
                commit('set_addCouponVisible', false);
                commit('set_couponVisible',true);
                message.error('添加失败');
            }
        },
        deleteOrder: async({ state, dispatch }, id) => {
            //console.log(id)
            const res = await deleteOrderAPI(id)
            if(res){
                message.success('删除成功')
                dispatch('getAllOrders')
            }
        },
        getEmptyRoomList: async ({state, commit}, data) => {
            const res = await getCurrPeriodRepoAPI(data)
            if (res) {
                console.log(res)
                commit('set_searchedRoomRepoList', res)
            }
        },
        getMgrHotelList: async ({state, commit}, id) => {
            //console.log(id)
            const res = await mgrHotelListAPI(id)
            if(res){
                commit('set_mgrHotelList', res)
            }
        },
        getManagedOrders: async({ state, commit }, id) => {

            const res = await managedOrdersAPI(id)
            console.log('res');
            if(res){
                commit('set_managedOrders', res)
            }
        },
        checkIn:async({ state, dispatch }, ids) => {
            const res = await checkInAPI(ids.orderId)
            if (res) {
                message.success('入住成功')
                dispatch('getManagedOrders', ids.userId)
            }
        },
        submitRoomRepoEmptyCnt: async ({state, commit, dispatch}, data) => {
            const res = await submitRoomRepoEmptyCntAPI(data)

            if (res) {
                let fromDate = state.searchedRoomRepoList[0].date;
                let toDate = state.searchedRoomRepoList[state.searchedRoomRepoList.length-1].date;
                let roomId = data.roomId;
                const d2 = {
                    fromDate, toDate, roomId
                };
                dispatch('submitRoomRepoSearch', d2)
                message.success('修改成功，请刷新页面');
                return true
            } else {
                message.error('修改失败');
                return false
            }
        },
        //提交酒店维护信息
        submitManageHotelParams:async({ commit, dispatch }, data) => {
            const res = await submitManageHotelParamsAPI(data)
            console.log('反回修改酒店')
            console.log(res)
            if (res) {//我很好奇请求成功以后会发什么回来？
                dispatch('getMgrHotelList', data.managerId)//应该是获取所有的酒店
                console.log('执行了这部分')
                commit('set_manageHotelVisible', false);
                message.success('修改成功')
            }else {
                message.error('修改失败');
            }
        },
        checkOut:async({ state, dispatch }, ids) => {

            const res = await checkOutAPI(ids.orderId)
            console.log('退房成功')
            console.log(res)
            if(res){
                message.success('退房成功')
                dispatch('getManagedOrders',ids.userId)
            }
        },
        modifyPrice:async({ state, dispatch }, data) => {
            const res = await setRoomPriceByRoomIdAPI(data)
            if (res) {
                message.success('修改成功')
                dispatch('getRoomTypeInfo',data.hotelId)
            }
        },
        submitRoomRepoSearch: async ({state, commit}, data) => {
            const res = await getCurrPeriodRepoAPI(data)
            if (res) {
                console.log(res)
                commit('set_searchedRoomRepoList', res)
            } else {
                console.log("检索失败")
            }
        },
        addRoomType:async({ state, dispatch }, data) => {
            const res = await addRoomTypeAPI(data)
            if(res){
                message.success('修改成功')
                dispatch('getRoomTypeInfo',data.hotelId)
            }
        },
        senthotelimg: async({ state},data) => {
            // console.log("id")
            // console.log(data)
            const res = await senthotelimgAPI(data)
            if(res){
                message.success('上传成功')
            }
        },
    }
}
export default hotelManager
