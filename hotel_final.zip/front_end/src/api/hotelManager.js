import { axios } from '@/utils/request'
const api = {
    hotelPre: '/api/hotel',
    repoPre: '/api/roomRepo',
}
export function addRoomAPI(data) {
    return axios({
        url: `${api.hotelPre}/roomInfo`,
        method: 'POST',
        data,
    })
}
export function addHotelAPI(data) {
    return axios({
        url: `${api.hotelPre}/addHotel`,
        method: 'POST',
        data,
    })
}
export function mgrHotelListAPI(id) {
    return axios({
        url: `/api/admin/${id}/hotelMgr/detail`,
        method: 'GET',
    })
}
export function submitManageHotelParamsAPI(data){
    return axios({
        url: `${api.hotelPre}/update`,
        method: 'POST',
        data,
    })
}
export function submitRoomRepoEmptyCntAPI(data) {
    return axios({
        url: `${api.repoPre}/setCurrPeriodRepo`,
        method: 'POST',
        data
    })
}
export function senthotelimgAPI(data) {

    return axios({
        url: `${api.hotelPre}/uploadImg/${data.id}`,
        headers: {
            'Content-Type':'multipart/form-data'
        },
        method: 'POST',
        data,
    })
}

