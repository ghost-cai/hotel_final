import { axios } from '@/utils/request'
const api = {
    hotelPre: '/api/hotel'
}
export function getHotelsAPI() {
    return axios({
        url: `${api.hotelPre}/all`,
        method: 'get',
    })
}
export function getHotelByIdAPI(param) {
    return axios({
        url: `${api.hotelPre}/${param.hotelId}/detail`,
        method: 'GET',
    })
}

export function managedOrdersAPI(id) {
    return axios({
        url: `${api.hotelPre}/${id}/managedOrders`,
        method: 'GET',
    })
}

//发送酒店搜索的请求
export function submitHotelSearchParamsAPI(data){
    return axios({
        url: `${api.hotelPre}/hotel_search/detail`,
        method: 'POST',
        data,
    })
}

//添加用户评论
export function getUserCommentAPI(id){
    return axios({
        url: `/api/comment/${id}/queryByHotelId`,
        method: 'GET',
    })
}



//后期请求改成对GET /api/hotel/{hotelId}/UserComment！！！


export function roomTypeInfoAPI(hotelId){
    return axios({
        url: `${api.hotelPre}/${hotelId}/retrieveHotelRoomInfo`,
        method: 'GET',
    })
}

export function setRoomPriceByRoomIdAPI(data){
    return axios({
        url: `${api.hotelPre}/setRoomPriceByRoomId/${data.roomId}?price=${data.price}`,
        method: 'POST',
    })
}
export function getCurrPeriodRepoAPI(data) {
    return axios({
        url: `${api.hotelPre}/roomTypeDetail`,
        method: 'POST',
        data
    })
}

export function addRoomTypeAPI(data) {
    return axios({
        url: `${api.hotelPre}/roomInfo`,
        method: 'POST',
        data
    })
}
export function mockgetUserCommentAPI(){
    console.log('zoujinlail')
    return axios.get('/mock/userReview.json')
}

export function gethotelpicAPI(data){
    return axios({
        url: `/api/hotel/getImg/${data}/`,
        method: 'GET'
    })
}
//后期请求改成对GET /api/hotel/{hotelId}/UserComment！！！
// axios.get('/mapi/userReview.json');
