import { axios } from '@/utils/request'
import Qs from 'qs';


const api = {
    userPre: '/api/user'
}
export function loginAPI(data){
    data.username = data.email;
    console.log(data);
    return axios({
        // url:`${api.userPre}/login`,
        url:`/api/user/login`,
        method: 'POST',
        data: {
            username: data.username,
            password: data.password
        }
    }).catch((r) => {
        console.log("catch: " , r)
    })
}

export function logoutAPI(data){
    return axios({
        url: `/api/user/logout`,
        method: 'post',
        data
    })
}
export function registerAPI(data){
    return axios({
        url: `${api.userPre}/register/individual`,
        method: 'POST',
        data
    })
}
export function getUserInfoAPI(id){
    return axios({
        url: `${api.userPre}/${id}/getUserInfo`,
        method: 'GET'
    })
}

export function updateUserInfoAPI(data) {
    return axios({
        url: `${api.userPre}/${data.id}/userInfo/update`,
        method: 'POST',
        data
    })
}

export function investCreditAPI(data){
    console.log(data)
    return axios({
        url: `${api.userPre}/${data.id}/investCredit?investedMoney=${data.investedMoney}`,
        method: 'POST',
    })
}
export function creditAPI(id){
    return axios({
        url: `${api.userPre}/${id}/credit`,
        method: 'GET'
    })
}
export function getuserpicAPI(data){
    return axios({
        url: `${api.userPre}/getImg/${data}/`,
        method: 'GET'
    })
}

export function addCommentAPI(data){
    return axios({
        url: `/api/comment/addComment`,
        method: 'post',
        data
    })
}

export function registeredmemberAPI(data){
    return axios({
        url: `/api/user/register/enterprise`,
        method: 'post',
        data
    })
}

