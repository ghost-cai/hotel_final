<template>
    <div class="foot">
        <a-row type="flex" justify="center" align="top">
            <a-col :span="3"  >
                <p class="height-60 foottitle" >
                    酒店预订
                </p>
                <div class="footcontent">
                    <a href="#/hotel/hotelBooking">酒店预订</a>
                    <br>
                    企业会员预订
                    <br>
                    会员申请
                    <br>
                    个人中心

                </div>
            </a-col>
            <a-col :span="3">
                <p  class="height-60 foottitle">
                    加盟合作
                </p>
                <div class="footcontent">
                    加盟高端酒店品牌
                    <br>
                    加盟中高端酒店品牌
                    <br>
                    加盟经济型酒店品牌
                    <br>
                    加盟亲子、休闲品牌
                    <br>
                    加入我们
                </div>
            </a-col>
            <a-col :span="3">
                <p  class="height-60 foottitle">
                    DUNE酒店管理团队
                </p>
                <div class="footcontent">
                    网站介绍
                    <br>
                    背景文化
                    <br>
                    招贤纳士
                    <br>
                    加入我们
                </div>
            </a-col>
            <a-col :span="7" >
                <div align="center">
                    <img class="footimg" src="../assets/library.jpeg">
                </div>

                <p  class="height-60 footfinaltitle">
                    联系我们
                </p>
                <p  class="height-60 phonenumber">
                    400 820 3333 或 1010 3333
                </p>
                <div style="text-align:center;">
                    服务时间为7点-24点
                </div>
            </a-col>
        </a-row>
    </div>
</template>

<script>
    export default {
        name: "footerPage"
    }
</script>

<style scoped lang="less">
    /*For demo*/
    .title{
        text-align: center;
    }

    .foot{

        height: 300px;
        background: #F3F0ED;
        padding-top: 20px;
    }
    .foottitle{
        font-weight:bold;
        font-size:20px;
        margin-bottom: 10px;
        color:#595757
    }
    .footcontent{
        /*font-weight:bold;*/
        font-size:14px;
        color: #858483;
        line-height: 28px;
    }
    .footimg{
        /*margin-left: 100px;*/
        max-width: 280px;
    }
    .footfinaltitle{
        /*font-weight:bold;*/
        font-size:18px;
        margin-top: 20px;
        /*margin-left: 200px;*/
        text-align:center;
        margin-bottom: 0;
        color:#595757
    }
    .phonenumber{
        font-weight:bold;
        font-size:22px;
        margin-top: 0px;
        margin-bottom: 0;
        text-align:center;
        color:#595757
    }
</style>
