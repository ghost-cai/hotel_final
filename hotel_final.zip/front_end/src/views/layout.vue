<template>
    <div id="layout">
        <Header></Header>
<!--        {{this.routerpath}}-->
<!--        引入了一个全局父样式，通过router view进行局部内容切换-->
        <transition name="fade-transform" mode="out-in">
<!--            transition其实是动画组件的内容-->
            <router-view/>
<!--            因为子组件要在框架样式内局部刷新，因此index.js路由里面要全写在这个children里面-->
        </transition>
        <footerPage/>
    </div>
</template>
<script>
import Header from '@/components/header'
import footerPage from "../components/footerPage";
export default {
    name: 'layout',
    components: {
        Header, footerPage
    },
    // data() {
    //     return {
    //        // routerpath:this.$route.path,
    //
    //     };
    // },
}
</script>