<template>
    <div>
        <home-page-search></home-page-search>
        <h1 class="title" >热门推荐酒店</h1>
        <hotel-list ></hotel-list>
    </div>
</template>

<script>
    import {mapGetters, mapMutations, mapActions} from 'vuex'
    import homePageSearch from "./components/homePageSearch";
    import hotelList from "./hotelList";
    export default {
        name: "homepage",

        components: {
            homePageSearch,
            hotelList
        },
        methods: {
            ...mapMutations([]),
        }
    }
</script>

<style scoped lang="less">
     /*For demo*/
.title{
    text-align: center;
}

.foot{
    height: 340px;
    background: #F3F0ED;
    margin-top: 80px;
    padding-top: 20px;
}
 .foottitle{
     font-weight:bold;
     font-size:20px;
     margin-bottom: 10px;
     color:#595757
 }
 .footcontent{
     /*font-weight:bold;*/
     font-size:14px;
     color: #858483;
     line-height: 28px;
 }
.footimg{
    /*margin-left: 100px;*/
    max-width: 280px;
}
 .footfinaltitle{
     /*font-weight:bold;*/
     font-size:18px;
     margin-top: 20px;
     /*margin-left: 200px;*/
     text-align:center;
     margin-bottom: 0;
     color:#595757
 }
.phonenumber{
    font-weight:bold;
    font-size:22px;
    margin-top: 0px;
    margin-bottom: 0;
    text-align:center;
    color:#595757
}
</style>