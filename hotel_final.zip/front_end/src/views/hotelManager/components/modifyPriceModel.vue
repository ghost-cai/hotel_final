<template>
    <a-modal
            title="修改价格"
            :visible="priceVisible"
            @ok="handleOk"
            @cancel="handleCancel">
        <a-form :form="form">
            <a-form-item label="房间单价">
                <a-input-number
                        :min="0"
                        ref="newValue"
                        :formatter="value => `￥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')"
                        :parser="value => value.replace(/\￥\s?|(,*)/g, '')"
                        v-decorator="[
                        'newValue',
                        { rules: [{required: true,message: '请输入金额' }] }
                    ]"
                />
            </a-form-item >

        </a-form>
    </a-modal>
</template>

<script>
    import {mapActions, mapGetters, mapMutations} from "vuex";
    export default {
        name: "modifyPriceModel",
        props:['id','hotelId'],
        computed:{
            ...mapGetters([
                'priceVisible'
            ])
        },
        methods:{
            ...mapMutations([
                'set_priceVisible'
            ]),
            ...mapActions([
                'modifyPrice',
            ]),
            handleOk(){

                let price = this.form.getFieldValue('newValue');

                let roomId = this.id;
                let hotelId = this.hotelId;
                let data  ={
                    price:price,
                    hotelId:hotelId,
                    roomId:roomId
                };
                this.modifyPrice(data);
                this.set_priceVisible(false);




                // console.log(this.id);
            },
            handleCancel(){
                this.set_priceVisible(false);
            },

        },
        beforeCreate() {
            this.form = this.$form.createForm(this, { name: 'modifyPriceModel' });
        },
    }
</script>

<style scoped>

</style>