<template>
    <div>
        <a-drawer
                title="房间管理"
                :placement="placement"
                :closable="false"
                :visible="roomManageDrawerVisible"
                @close="onClose"
                height=""
        >

            <room-search-in-drawer :id="id" style="margin-left: 20px"></room-search-in-drawer>
            <a-divider />
            <room-list-in-drawer></room-list-in-drawer>
            <div style="text-align: right; margin-top: 10px">
                <a-button type="primary" @click="onClose">确定</a-button>
            </div>
        </a-drawer>
    </div>
</template>
<script>
    import {mapGetters, mapMutations} from "vuex";
    import roomListInDrawer from "./roomListInDrawer";
    import roomSearchInDrawer from "./roomSearchInDrawer";

    export default {
        props:['id'],
        data() {
            return {
                visible: false,
                placement: 'top',
            };
        },
        components: {
            roomListInDrawer, roomSearchInDrawer
        },
        computed: {
            ...mapGetters([
                'roomManageDrawerVisible',
            ])
        },
        methods: {
            ...mapMutations([
                'set_roomManageDrawerVisible',
            ]),
            onClose() {
                this.set_roomManageDrawerVisible(false)
            }

        },
    };
</script>
