<template>
    <div>
        <a-drawer
                title="当日异常订单"
                placement="top"
                :closable="false"
                height="370"
                :visible="unusualOrderVisible"
                @close="onClose"
                destroyOnClose

        >
            <a-table
                    size="small"
                    :columns="columns1"
                    :dataSource="unusualOrderList"
                    bordered
                    :pagination="pagination"
            >
            </a-table>
        </a-drawer>
    </div>
</template>

<script>
    import {mapActions, mapGetters, mapMutations} from "vuex";

    const columns1 = [
        {
            title: '订单号',
            dataIndex: 'id',
        },
        {
            title: '酒店名',
            dataIndex: 'hotelName',
        },
        {
            title: '房型',
            dataIndex: 'roomType',
        },
        {
            title: '入住时间',
            dataIndex: 'checkInDate',
        },
        {
            title: '离店时间',
            dataIndex: 'checkOutDate',
        },
        {
            title: '入住人数',
            dataIndex: 'peopleNum',
        },
        {
            title: '房价',
            dataIndex: 'price',
        },
        {
            title: '状态',
            dataIndex: 'orderState',
        }
    ];
    export default {
        name: "unusualOrder",
        props: [
            'hotelId',
        ],
        data() {
            return {
                columns1,
                pagination:{
                    defaultPageSize:5,
                }
            }

        },
        computed: {
            ...mapGetters([
                'unusualOrderVisible',
                'unusualOrderList'
            ])
        },
        async mounted() {
            // await this.getUnusualOrderList(this.hotelId)
        },
        methods: {
            ...mapActions([
                'getUnusualOrderList'
            ]),
            ...mapMutations([
                'set_unusualOrderVisible',
                'set_unusualOrderList'
            ]),
            onClose() {
                this.set_unusualOrderList([])
                this.set_unusualOrderVisible(false);
            },
            // afterVisibleChange(id) {
            //     this.getUnusualOrderList(id)
            // },
        }
    }
</script>

<style scoped>

</style>
