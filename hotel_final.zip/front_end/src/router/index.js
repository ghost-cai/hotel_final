import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/login.vue'
import Qs from 'qs';
import store from '@/store'
import {axios} from '@/utils/request'

Vue.use(VueRouter)
Vue.prototype.Qs = Qs;
const routes = [
    {
        path: '/login',
        name: 'login',
        component: Login
    },
    {
        path: '/',
        redirect: '/NJUSE'
    },
    //  给了一条重定向
    {
        path: '/NJUSE',
        name: 'layout',
        redirect: '/hotel/homepage',
        component: () => import('@/views/layout'),
        //加载完父组件框后，子组件重定向：默认显示
        children: [
            {
                path: '/hotel/hotelBooking',
                name: 'hotelBooking',
                component: () => import('@/views/hotel/hotelBooking')
            },
            {
                path: '/hotel/homepage',
                name: 'homepage',
                component: () => import('@/views/hotel/homepage')
            },
            //  上面是我添加的一条路由：酒店预订！
            {
                path: '/hotel/hotelList',
                name: 'hotelList',
                component: () => import('@/views/hotel/homepage')
            },
            {
                path: '/hotel/hotelDetail/:hotelId',
                name: 'hotelDetail',
                component: () => import('@/views/hotel/hotelDetail')
            },
            {
                path: '/user/info/:userId',
                name: 'userInfo',
                component: () => import('@/views/user/info')
            },
            {
                path: '/hotelManager/manageHotel',
                name: 'manageHotel',
                component: () => import('@/views/hotelManager/manageHotel')
            },
            {
                path: '/admin/manageUser',
                name: 'manageUser',
                component: () => import('@/views/admin/manageUser')
            },
        ]
    },
]
const createRouter = () => new VueRouter({
    // mode: 'history', // require service support
    scrollBehavior: () => ({y: 0}),
    routes
    //路由 加载路由表routes
})
const router = createRouter()

router.beforeEach((to, from, next) => {
    // JWT Token
    if (localStorage.getItem("token")) {
        if (to.fullPath === '/login') {
            next('/')
        }
        else {
            next()
        }
    } else {
        // 无Token
        if (to.fullPath === '/login') {
            next()
        } else {
            next('/login')
        }
    }
})

export function resetRouter() {
    const newRouter = createRouter()
    router.matcher = newRouter.matcher // reset router
}

export default router
//
// axios.interceptors.request.use(
//     config => {
//         if (localStorage.getItem("token")) {
//             config.headers.Authorization = `token ${localStorage.getItem("token")}`;
//         }
//         return config;
//     },
//     error => {
//         return Promise.reject()
//     }
// );
//
// axios.interceptors.response.use(
//     response => {
//         return response
//     },
//     error => {
//         console.log('axios:' + error.response.status);
//         switch (error.response.status) {
//             case 401:
//                 // 返回 401 清除token信息并跳转到登录页面
//                 store.commit('logout');
//                 // router.replace({
//                 //     path: 'login',
//                 //     query: {redirect: router.currentRoute.fullPath}
//                 // });
//         }
//         return Promise.reject(error.response.data);   // 返回接口返回的错误信息
//     }
//
// );
//
// Vue.prototype.$http = axios;
