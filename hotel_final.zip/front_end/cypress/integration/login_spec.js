/**
 * Created by wxy on 2020-07-03
 */

describe('page-test', function () {

    beforeEach('client-login', function () {
        cy.visit('/')
        cy.get('[placeholder="邮箱"]').type('123@qq.com').should('have.value', '123@qq.com')
        cy.get('[placeholder="密码"]').type('123456').should('have.value', '123456')
        cy.get('.login-button').click()
    });

    it('booking', function (){
        cy.get('.booking').click()
        cy.get('.select-city').click().type('{downarrow}{rightarrow}{rightarrow}{enter}')
        cy.get('[placeholder="房间数"]').type('1')
        cy.get('.ant-calendar-range-picker-input').first().click()
        cy.get('[placeholder="Start date"]').last().type('2020-07-03')
        cy.get('[placeholder="End date"]').last().type('2020-07-04')
        cy.get('.sp_line').click()
        cy.get('button').first().click()
        cy.wait(300)
        cy.get('button').last().click()
        //进入酒店详情页面
        cy.wait(300)
        cy.url().should('include', '/hotel/hotelDetail')
        cy.get('[data-row-key="2"] > :nth-child(3) > :nth-child(1) > .booking-button').click()
        cy.wait(100)
        cy.get('[placeholder="入住人姓名"]').type('testing')
        cy.get('[placeholder="手机号"]').type('123')
        cy.get('.ant-calendar-range-picker-input').first().click()
        cy.get('[placeholder="入住日期"]').last().type('2020-07-03')
        cy.get('[placeholder="退房日期"]').last().type('2020-07-04')
        cy.get('[placeholder="入住人姓名"]').click()
        cy.get('.peopleNum').type('{enter}')
        cy.get('#orderModal_haveChild > :nth-child(2) > :nth-child(2)').click()
        cy.get('.roomNum').last().type('{enter}')
        cy.get('div > .ant-btn-primary').click()
    });

    it('add-comment',function () {
        cy.get('.ant-menu > :nth-child(6)').click()
        cy.get('.ant-tabs-nav > :nth-child(1) > :nth-child(2) > span').click()
        cy.get('[data-row-key="0"] > :nth-child(9) > span[data-v-5d917ec8=""] > .ant-btn').click()
        cy.get('.ant-input').type("nb")
        cy.get('div > .ant-btn-primary').click()
    });
    it('check-credit',function () {
        cy.get('.ant-menu > :nth-child(6)').click()
        cy.get(':nth-child(3) > span').click()
    });

});
