module.exports = {
    devServer: {
        port: 8000,
        //下面配置一个开发时的请求表
        proxy:{
            '/mock':{
                target:'http://localhost:8000',
                changeOrigin: true,
                ws:true,

            },
            '/api': {
                target: 'http://localhost:8080',
                changeOrigin: true,
                pathRewrite: {     // pathRewrite表示路径重写，key表示一个正则，value表示别名
                    '^/api': ''   // 即用 '/api'表示'http://localhost:3000/api'
                }
            }
        }
    },
}