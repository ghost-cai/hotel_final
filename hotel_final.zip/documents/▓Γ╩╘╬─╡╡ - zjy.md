## 单元测试

### Coupon

#### getHotelAllCoupon 功能

- 描述：根据酒店id，获取所有优惠券

- 代码：

  ```java
  @Test
  void getHotelAllCoupon() {
    List<Coupon> hotelAllCoupon = couponService.getHotelAllCoupon(1);
    assertNotNull(hotelAllCoupon);
    for (Coupon c: hotelAllCoupon) {
      System.out.println(c);
    }
  }
  ```

- 结果1：获取到所有酒店id为1的优惠券

- 代码2：

  ```java
  @Test
  void getHotelAllCouponError() {
    List<Coupon> hotelAllCoupon = couponService.getHotelAllCoupon(-10);
    assertEquals(0, hotelAllCoupon.size());
  }
  ```

- 结果2：获取空列表



#### getMatchOrderCoupon 功能

- 描述：根据传入的订单信息，获取所有可用优惠券信息

- 代码：

  ```java
  @Test
  void getMatchOrderCoupon() {
    System.out.println("HELLO");
    OrderVO orderVO = new OrderVO();
    orderVO.setHotelId(1);
    orderVO.setRoomNum(4);
    orderVO.setPrice(1000.0);
    orderVO.setCheckInDate("2020-05-02");
    orderVO.setCheckOutDate("2020-05-03");
    List<Coupon> matchOrderCoupons = couponService.getMatchOrderCoupon(orderVO);
    System.out.println(matchOrderCoupons.size());
    for (Coupon c : matchOrderCoupons)
      System.out.println(c);
  
  }
  ```

- 结果：成功获取所有可用优惠券信息









## 集成测试

### Hotel

#### createHotel 接口

- 描述：创建酒店

- 前提条件：无

- 输入：

  - URL：POST /api/hotel/addHotel

  - JSON：

    ```json
    {
    	"name": "新的酒店",
    	"address": "江苏省南京市栖霞区仙林大道168号",
    	"biz_id": "js_nj_xianlin",
    	"hotelStar": "Four",
    	"description": "None",
    	"phoneNum": "19922222",
    	"managerId": "6"
    }
    ```

- 输入2：

  - URL：POST /api/hotel/addHotel

  - JSON：

    ```json
    {
    	"name": "新的酒店",
    	"address": "江苏省南京市栖霞区仙林大道168号",
    	"biz_id": "js_nj_xianlin",
    	"hotelStar": "Four",
    	"description": "None",
    	"phoneNum": "19922222",
    	"managerId": "100"
    }
    ```

- 输入3：

  - URL：POST /api/hotel/addHotel

  - JSON：

    ```json
    {
    	"name": "新的酒店",
    	"address": "江苏省南京市栖霞区仙林大道168号",
    	"biz_id": "js_nj_xianlinn",
    	"hotelStar": "Four",
    	"description": "None",
    	"phoneNum": "19922222",
    	"managerId": "6"
    }
    ```

| ID    | 输入  | 预期输出             | 实际输出             |
| ----- | ----- | -------------------- | -------------------- |
| 1     | 输入1 | 创建成功             | Success              |
| 2     | 输入2 | 管理员不存在或无权限 | 管理员不存在或无权限 |
| ==3== | 输入3 | 商圈不存在           | Success              |

#### retrieveAllHotels 接口

- 描述：获取所有酒店信息
- 前提条件：无

- 输入1：

  - URL：GET /api/hotel/all

  - 输出：

    ```json
    {
        "success": true,
        "message": null,
        "content": [
            {
                "id": 1,
                "name": "汉庭酒店",
                "address": null,
                "biz_id": "js_nj_xianlin",
                "hotelStar": "Four",
                "rate": 4.8,
                "description": "欢迎您入住",
                "phoneNum": "1829373819",
                "managerId": 6,
                "rooms": null,
                "bizRegion": "XiDan"
            },
            {
                "id": 2,
                "name": "儒家酒店",
                "address": "南京市鼓楼区珠江路268号",
                "biz_id": "js_nj_xinjiekou",
                "hotelStar": "Four",
                "rate": 4.8,
                "description": "欢迎您入住",
                "phoneNum": "1829373819",
                "managerId": 6,
                "rooms": null,
                "bizRegion": "XiDan"
            },
            {
                "id": 3,
                "name": "桂圆酒店",
                "address": "南京市栖霞区珠江路268号",
                "biz_id": "js_nj_xinjiekou",
                "hotelStar": "Four",
                "rate": 4.8,
                "description": "欢迎您入住",
                "phoneNum": "1829553719",
                "managerId": 7,
                "rooms": null,
                "bizRegion": "XiDan"
            },
            {
                "id": 4,
                "name": "111",
                "address": "111",
                "biz_id": "js_nj_xianlin",
                "hotelStar": "Four",
                "rate": 0.0,
                "description": "111",
                "phoneNum": "111",
                "managerId": 6,
                "rooms": null,
                "bizRegion": "xianlin"
            },
            {
                "id": 5,
                "name": "新的酒店",
                "address": "江苏省南京市栖霞区仙林大道168号",
                "biz_id": "js_nj_xianlin",
                "hotelStar": "Four",
                "rate": null,
                "description": "None",
                "phoneNum": "19922222",
                "managerId": 6,
                "rooms": null,
                "bizRegion": null
            }
        ]
    }
    ```

| ID   | 输入  | 预期输出     | 实际输出 |
| ---- | ----- | ------------ | -------- |
| 1    | 输入1 | 所有酒店信息 | Success  |

#### updateHotelBasicInfo 接口

- 描述：更新酒店基本信息

- 前提条件：所更新的酒店存在

- 输入1：

  - URL：POST /api/hotel/update

  - JSON：

    ```json
    {
    	"id": "5",
    	"name": "新的酒店",
    	"address": "江苏省南京市栖霞区仙林大道169号",
    	"biz_id": "js_nj_xianlin",
    	"hotelStar": "Four",
    	"description": "None",
    	"phoneNum": "19922222",
    	"managerId": "6"
    }
    ```

- 输入2：

  - URL：POST /api/hotel/update

  - JSON：

    ```json
    {
    	"id": "100",
    	"name": "新的酒店",
    	"address": "江苏省南京市栖霞区仙林大道169号",
    	"biz_id": "js_nj_xianlin",
    	"hotelStar": "Four",
    	"description": "None",
    	"phoneNum": "19922222",
    	"managerId": "6"
    }
    ```

| ID   | 输入  | 预期输出 | 实际输出 |
| ---- | ----- | -------- | -------- |
| 1    | 输入1 | Success  | Success  |
| 2    | 输入2 | 更新失败 | 更新失败 |

#### searchHotel 搜索酒店

- 描述：搜索酒店

- 前置条件：无

- 输入1：

  - URL：POST /api/hotel/hotel_search

  - JSON：

    ```json
    {
    	"hotelNameKeyWord": "汉庭",
    	"beginDate": "2020-05-21",
    	"endDate": "2020-05-23",
    	"bizId": "js_nj_xianlin",
    	"ordered": "0"
    }
    ```

  - 输出：

    ```json
    {
        "success": true,
        "message": null,
        "content": [
            {
                "id": 1,
                "name": "汉庭酒店",
                "address": null,
                "biz_id": "js_nj_xianlin",
                "hotelStar": "Four",
                "rate": 4.8,
                "description": "欢迎您入住",
                "phoneNum": "1829373819",
                "managerId": 6,
                "rooms": null,
                "bizRegion": "XiDan"
            }
        ]
    }
    ```



| ID   | 输入  | 预期输出         | 实际输出         |
| ---- | ----- | ---------------- | ---------------- |
| 1    | 输入1 | 搜索到的汉庭酒店 | 搜索到的汉庭酒店 |

### Comment

#### addComment 接口

- 描述：添加对订单的评论

- 前置条件：订单已存在

- 输入1：

  - URL: POST /api/comment/addComment

  - JSON：

    ```json
    {
    	"orderId": 17,
    	"rate": 4,
    	"commentDetail": "this_is_detail"
    }
    ```

- 输入2：

  - URL: POST /api/comment/addComment

  - JSON：

    ```json
    {
    	"orderId": 18,
    	"rate": 4,
    	"commentDetail": "this_is_detail"
    }
    ```

    

| ID   | 输入              | 预期输出 | 实际输出 |
| ---- | ----------------- | -------- | -------- |
| 1    | 输入1             | Success  | Success  |
| 2    | 输入2（无此订单） | Failure  | Faliure  |

#### queryByHotelId 接口

- 描述：根据酒店ID查询评论信息
- 前置条件：无
- 输入1：
  - URL：GET /api/comment/1/queryByHotelId

- 不需要对特殊情况进行讨论：返回空集即可

| ID   | 输入  | 预期输出     | 实际输出 |
| ---- | ----- | ------------ | -------- |
| 1    | 输入1 | 查询到的评论 | Success  |





### Location

#### getAllLocations 接口

- 描述：为前端的多级菜单提供locations信息

- 前置条件：无

- 输入1：

  - URL：GET /api/loc/all

  - 输出：

    ```json
    {
        "success": true,
        "message": null,
        "content": [
            {
                "value": "jiangsu",
                "label": "Jiangsu",
                "children": [
                    {
                        "value": "js_nanjing",
                        "label": "Nanjing",
                        "children": [
                            {
                                "value": "js_nj_xianlin",
                                "label": "Xianlin",
                                "children": []
                            },
                            {
                                "value": "js_nj_xinjiekou",
                                "label": "Xinjiekou",
                                "children": []
                            }
                        ]
                    },
                    {
                        "value": "js_suzhou",
                        "label": "Suzhou",
                        "children": []
                    }
                ]
            },
            {
                "value": "zhejiang",
                "label": "Zhejiang",
                "children": [
                    {
                        "value": "zj_hangzhou",
                        "label": "Hangzhou",
                        "children": [
                            {
                                "value": "zj_hz_xihu",
                                "label": "Xihu",
                                "children": []
                            }
                        ]
                    }
                ]
            }
        ]
    }
    ```
| ID   | 输入  | 预期输出           | 实际输出           |
| ---- | ----- | ------------------ | ------------------ |
| 1    | 输入1 | 当前数据库中的bizs | 当前数据库中的bizs |


​    

