## 已有API

### Admin     :   /api/admin


### admin :/api/admin

- post: /{id}/userInfo/update

  - 更新用户信息

    ```
    private String password;
    private String userName;
    private String phoneNumber;
    ```

- post: /users

  - 对用户列表进行检索

    ```
    >>>>>>>>
    {
    	"userType": "Client",
    	"email": "@qq.com",
    	"phoneNumber": "12345678919"
    }
    
    <<<<<<<<
    {
        "success": true,
        "message": null,
        "content": [
            {
                "id": 4,
                "email": "1012681@qq.com",
                "password": "123456",
                "userName": "测试一号",
                "phoneNumber": "12345678919",
                "credit": -698.0,
                "userType": "Client"
            }
        ]
    }
    ```

- post: /hotel/bindManager

  - 为某个酒店绑定管理员

    ```
    private int hotelId;
    private int mgrId;
    ```

- get: /{id}/hotelMgr/detail

  - 获取某id管理员管理的酒店

- get: /{id}/hotelMgr/setAsMgr

- post：/deleteAccount/{userId}

  - 删除账号

### Comment  :  /api/comment

- Post : /addComment
  - 增加一条comment
  - 参数@RequestBody CommentVO commentVO
- Get： /{id}/queryByCommentId
  - 删除一条comment 
- Get： /{id}/queryByHotelId
  - 查询comment 通过hotelid





### Coupon :   /api/coupon

- Post : /hotelTargetMoney

  - 增加满减优惠
  - 参数@RequestBody HotelTargetMoneyCouponVO hotelTargetMoneyCouponVO

- Post ： /hotelMultiRoom

  - 增加多间优惠
  - 参数@RequestBody HotelMultiRoomCouponVO multiRoomCouponVO

- Post： /hotelFestival

  - 增加节日优惠
  - 参数@RequestBody HotelFestivalCouponVO festivalCouponVO

- Post： /webAdminTargetMoney

  - 增加网站管理人员满减优惠
  - 参数@RequestBody WebAdminTargetMoneyCouponVO targetMoneyCouponVO

- Post： /webAdminMultiRoom

  - 增加网站管理人员多间优惠
  - 参数@RequestBody WebAdminMultiRoomCouponVO multiRoomCouponVO

- Post： /webAdminFestival

  - 增加网站管理人员节日优惠

  - 参数@RequestBody WebAdminFestivalCouponVO festivalCouponVO

- Get：/hotelAllCoupons

  - 获取所有优惠券
  - 参数@RequestParam Integer hotelId

- Get ：/orderMatchCoupons

  - 获取符合条件的优惠券
  - 参数
    - @RequestParam Integer userId,
      - @RequestParam Integer hotelId,
      - @RequestParam Double orderPrice,
      - @RequestParam Integer roomNum,
      - @RequestParam String checkIn,
      - @RequestParam String checkOut

  

### Hotel： /api/hotel

- Post：/addHotel
  - 增加酒店
  - 参数@RequestBody HotelVO hotelVO
- Get： /all
  - 获取所有酒店
- Post： /roomInfo
  - 添加房间信息
  - 参数@RequestBody HotelRoom hotelRoom
- get：/{hotelId}/detail
  - 获得酒店详细信息
  - 参数 在路由里面
- Post： /pos/detail
  - 通过位置来获得酒店信息
  - 参数@RequestBody PositionVO positionVO
- Post ：/update
  - 维护酒店基本信息
  - 参数@RequestBody HotelVO hotelVO
- Get  :/{userId}/managedOrders

  - 获得该管理员所属酒店的订单
  - 参数为管理员的userid

### order ：/api/order

- post：/addOrder
  - 增加订单
  - 参数(@RequestBody OrderVO orderVO

- get ：/getAllOrders
  - 获得所有订单

- get ：/{userid}/getUserOrders
  - 获得用户订单
  - 参数 在url里面
- get ：/{orderid}/annulOrder
  - 撤销订单
  - 参数在url里面
- get ：/{hotelId}/allOrders
  - 获取酒店全部订单
  - 参数在url里面
- get ：/{orderid}/detail
  - 获取订单详情
  - 参数在url里面
- get：/{orderid}/checkin
  - 执行订单
  - 参数在url里面
- get ：{orderid}/checkout
  - 退房
  - 参数在url里面
- get：{hotelId}/abnormalOrdersOfTheDay
  - 获取当日未执行的异常订单
  - 参数在url里面
- post ：{orderId}/appealAbnormalOrder
  - 申诉撤销订单
  - 参数@PathVariable Integer orderId



### user :/api/user

- post: /login
  - 登录
  - 参数@RequestBody UserForm userForm

- post :/register/individual
  - 注册到个人用户,注意路径改变
  - 参数@RequestBody UserVO userVO
- post:/register/enterprise
  - 注册到企业用户,传入格式见UserEntVO
  - 参数@RequestBody UserEntVO userEntVO
- get:/{id}/getUserInfo
  - 获取用户信息
  - 参数在url里面
- post: /{id}/userInfo/update
  - 更新用户信息
  - 参数id在url里面,另外@RequestBody UserInfoVO userInfoVO
- get :/{id}/credit
  - 获取信用记录
  - 参数在url里面
- Post：/{id}/investCredit
  - 信用充值
  - 参数@PathVariable int id,@RequestParam double investedMoney
    - 其中充值的信用值为money*100



### admin :/api/admin

- post: /{id}/userInfo/update

  - 更新用户信息

    ```
    private String password;
    private String userName;
    private String phoneNumber;
    ```

- post: /users

  - 对用户列表进行检索

    ```
    >>>>>>>>
    {
    	"userType": "Client",
    	"email": "@qq.com",
    	"phoneNumber": "12345678919"
    }
    
    <<<<<<<<
    {
        "success": true,
        "message": null,
        "content": [
            {
                "id": 4,
                "email": "1012681@qq.com",
                "password": "123456",
                "userName": "测试一号",
                "phoneNumber": "12345678919",
                "credit": -698.0,
                "userType": "Client"
            }
        ]
    }
    ```

- post: /hotel/bindManager

  - 为某个酒店绑定管理员

    ```
    private int hotelId;
    private int mgrId;
    ```

- get: /{id}/hotelMgr/detail

  - 获取某id管理员管理的酒店

- get: /{id}/hotelMgr/setAsMgr
  
  - 将某个人角色设置为管理员

### roomRepo: /api/roomRepo

- post: /getCurrPeriodRepo

  - 获取某个时间段的某个roomId的空闲客房数量

    ```
    >> IN
    {
    	"fromDate": "2020-05-21",
    	"toDate": "2020-05-24",
    	"roomId": 2
    }
    << OUT
    {
        "success": true,
        "message": null,
        "content": {
            "2020-05-23": 12,
            "2020-05-24": 0,
            "2020-05-21": 10,
            "2020-05-22": 11
        }
    }
    ```

- post: /setCurrPeriodRepo

  - 设置某个时间段某个roomId的空闲客房数量

    ```
    >> IN
    {
    	"fromDate": "2020-05-21",
    	"toDate": "2020-05-25",
    	"roomId": 3,
    	"valToSet": 20
    }
    << OUT
    {
        "success": true,
        "message": null,
        "content": true
    }
    ```
    

    



















