# doc-zjy

## I. 个人基本信息

### 1. 维护基本信息

```
POST /api/user/{id}/userInfo/update
- body: UserInfoVO
```

### 2. 浏览自己的订单（未执行、已执行、已撤销）

```
GET /api/user/{userid}/getUserOrders
```

- 可能需要分开

  根据orderState进行判断

### 3. 查看基本信息

```
GET /api/user/{id}/getUserInfo
```

### 4. 查看信用记录及信用记录变动情况

```
GET /api/user/{id}/credit
Response:
-- current_credit int
-- list: creditChange
	 -- time
	 -- orderId
	 -- action
	 -- changeVal
	 -- afterChange
	 -- userId
```

```sql
-- CreditInfo
CREATE TABLE `CreditInfo` (
  `mut_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` int(11) NOT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_val` int(11) NOT NULL,
  `after_change` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`mut_id`),
  KEY `CreditInfo_order_id_fk` (`order_id`),
  KEY `CreditInfo_user_id_fk` (`user_id`),
  CONSTRAINT `CreditInfo_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `OrderList` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `CreditInfo_user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
```

- 争议：po里面的action类型
- 

### 5. 查看自己预订的酒店 分别标记订单

```
GET /api/order/{userid}/getUserOrders
```



## II. 浏览酒店详细信息

### 1. 明确地址与商圈

```
POST /api/hotel/pos/detail
-- need: postionVO
```

### 2. 标记酒店是否已经被预订

```
GET /api/hotel/{userId}/hotelId
```

### 3. 单独查看某个酒店的详细信息

```
GET /api/hotel/{hotelId}/detail
```

### 4. 专门列表查看已经预定过的酒店

- 请结合ii.2/获取本人订单/获取该地址和商圈的所有酒店完成，辛苦！

## III. 搜索酒店信息

### 1. 明确地址商圈、通过酒店名称、房间、星级等信息

```
POST http://localhost:8080/api/hotel/hotel_search/detail
```

```
// POST http://localhost:8080/api/hotel/hotel_search/detail
{
    "position": {
        "address": "南京市鼓楼区珠江路268号",
        "bizRegion": "XiDan"
    },
    "stars": [
        "Four",
        "Five"
    ],
    "lowerRate": 4,
    "higherRate": 5,
    "roomDemandCnt": 8,
    "roomType": "Family"
}

// return
{
    "success": true,
    "message": null,
    "content": [
        {
            "id": 2,
            "name": "儒家酒店",
            "address": "南京市鼓楼区珠江路268号",
            "bizRegion": "XiDan",
            "hotelStar": "Four",
            "rate": 4.8,
            "description": "欢迎您入住",
            "phoneNum": "1829373819",
            "managerId": 2,
            "rooms": null
        }
    ]
}
```

## iv. 生成订单





## v. 评价，包括评分和评论

```
-- comment
CREATE TABLE `Comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `rate` double NOT NULL,
  `commentDetail` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Comment_order_id_fk` (`orderId`),
  CONSTRAINT `Comment_order_id_fk` FOREIGN KEY (`order_id`) REFERENCES `OrderList` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
```

## vi. 企业

- 对企业的注册实际上是新增了一个Enterprise表

  ```sql
  CREATE TABLE `Enterprise` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `entName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
    `inviteCode` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
    PRIMARY KEY (`id`)
  ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  ```

- 想法：用user表去连接Enterprise表，连接关系用belongsToEnt表示

  ```sql
  CREATE TABLE `belongsToEnt` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `userId` int(11) NOT NULL,
    `entId` int(11) NOT NULL,
    PRIMARY KEY (`id`),
    KEY `belongsToEnt_ent_id_fk` (`entId`),
    KEY `belongsToEnt_user_id_fk` (`userId`),
    CONSTRAINT `belongsToEnt_ent_id_fk` FOREIGN KEY (`entId`) REFERENCES `Enterprise` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `belongsToEnt_user_id_fk` FOREIGN KEY (`userId`) REFERENCES `User` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
  ) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  ```


# D. 网站管理人员

## i. 用户管理

### 1. 用户信息更改

```
-- POST /api/su/{id}/userInfo/update
```

### 2. 用户信息检索

```
-- POST /api/su/users
>>>>>>>>
{
	"userType": "Client",
	"email": "@qq.com",
	"phoneNumber": "12345678919"
}

<<<<<<<<
{
    "success": true,
    "message": null,
    "content": [
        {
            "id": 4,
            "email": "1012681@qq.com",
            "password": "123456",
            "userName": "测试一号",
            "phoneNumber": "12345678919",
            "credit": -698.0,
            "userType": "Client"
        }
    ]
}
```

### 3. 添加酒店

```
/api/hotel/addHotel
```

### 4. 为酒店选择工作人员

```
/api/su/hotel/bindManager
```

### 5. 查询所有酒店工作人员

- 使用Users查询

### 6. 查询某酒店工作人员的管理酒店信息

```
/api/su/{id}/hotelMgr/detail
```

### 7. 新增某账户为酒店工作人员角色

```
/api/su/{id}/hotelMgr/setAsMgr
```

