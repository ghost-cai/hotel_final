## 4. 结构视角

### 4.1 业务逻辑层的分解

#### 4.1.1 adminbl模块

1. 模块概述

   adminbl模块承担的需求参见需求规格说明文档功能需求及相关非功能需求

   adminbl模块的职责和接口参见软件系统结构描述文档

2. 整体结构

   根据体系结构的设计，我们使用分层的模式来构建本系统，将系统分为web展示层、restful api层、业务逻辑层、数据层。每一层之间为了增加灵活性，我们会添加接口。比如API Controller层和业务逻辑层之间，我们添加了bl.admin.AdminService接口；业务逻辑层与数据层之间添加了data.admin.AdminMapper、data.hotel.HotelMapper接口。这样，我们将依赖接口而非实体类，增加了系统的灵活性。

   User(PO)是作为用户持久化对象被添加到设计模型中的；HotelVO、UserForm是除数据持久化层之外交换数据使用的VO；HotelBindingVO服务于酒店管理员绑定服务。  

   adminbl模块的设计如图所示：

   ![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200603222046.png)

  <div style="text-align: center; font-weight:bold">图x adminbl模块各个类的设计</div>

   adminbl模块各个类的职责如下表所示：

  <div style="text-align: center; font-weight:bold">表x adminbl模块各个类的职责</div>

|       模块       |                  职责                  |
| :--------------: | :------------------------------------: |
| AdminServiceImpl | 负责实现酒店信息查询与维护所需要的服务 |
|      UserPO      |         用户信息的领域模型对象         |

3. 模块类内部的接口规范

   AdminServiceImpl的接口规范如表x所示

     <div style="text-align: center; font-weight:bold">表x AdminServiceImpl的接口规范</div>

   - 提供的服务（供接口）

     - AdminServiceImpl.addManager
       - 语法：public ResponseVO addManager(UserForm userForm)
       - 前置条件：无
       - 后置条件：添加该酒店管理员账号
     - AdminServiceImpl.getAllManagers
       - 语法：public List<User> getAllManagers()
       - 前置条件：无
       - 后置条件：返回list对象，包含所有酒店工作人员账号信息
     - AdminServiceImpl.getAllClients
       - 语法：public List<User> getAllClients()
       - 前置条件：无
       - 后置条件：返回list对象，包含所有客户账号信息
     - AdminServiceImpl.bindHotelMgr
       - 语法：public boolean bindHotelMgr(HotelBindingVO hotelBindingVO)
       - 前置条件：该酒店无已绑定的酒店工作人员
       - 后置条件：在该酒店信息中添加工作人员ID信息
     - AdminServiceImpl.selectManagedBy
       - 语法：public List<HotelVO> selectManagedBy(Integer mgrId)
       - 前置条件：获得酒店管理人员有效ID
       - 后置条件：返回某客户预定过的酒店id列表
   - 需要的服务（需接口）

     - AdminMapper.addManager(User user)

       - 添加酒店工作人员账号
   - adminMapper.getAllManagers()
       - 获取所有酒店工作人员列表
   - adminMapper.getAllClients()
       - 获取所有客户列表
     - 
       HotelMapper.bindNewHotelMgr(hotelBindingVO.getHotelId(), hotelBindingVO.getMgrId())
       - 为酒店绑定新管理人员
     - HotelMapper.selectManagedBy(mgrId)
     
     - 根据酒店管理人员id获取管理酒店列表

   

4. 业务逻辑层的动态模型

   图x表示了在酒店预订系统中，当管理人员为酒店绑定酒店工作人员时，网站业务逻辑处理相关对象之间的协作

   ![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200603222052.png)

     <div style="text-align: center; font-weight:bold">图x 绑定酒店工作人员的顺序图</div>

5. 业务逻辑层的设计原理

   利用委托式控制风格，每个界面需要访问的业务逻辑由各自的ServiceImpl委托给不同的领域对象。