## 4. 结构视角

### 4.1 业务逻辑层的分解

#### 4.1.1 commentbl模块

1. 模块概述

   commentbl模块承担的需求参见需求规格说明文档功能需求及相关非功能需求

   commentbl模块的职责和接口参见软件系统结构描述文档

2. 整体结构

   根据体系结构的设计，我们使用分层的模式来构建本系统，将系统分为web展示层、restful api层、业务逻辑层、数据层。每一层之间为了增加灵活性，我们会添加接口。比如API Controller层和业务逻辑层之间，我们添加了bl.comment.CommentService接口；业务逻辑层与数据层之间添加了data.comment.CommentMapper接口。这样，我们将依赖接口而非实体类，增加了系统的灵活性。

   CommentPO是作为评论信息持久化对象被添加到设计模型中的；CommentVO是除数据持久化层之外交换数据使用的VO。  

   commentbl模块的设计如图所示：

   ![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200604075344.png)

  <div style="text-align: center; font-weight:bold">图x commentbl模块各个类的设计</div>

  commentbl模块各个类的职责如下表所示：

  <div style="text-align: center; font-weight:bold">表x commentbl模块各个类的职责</div>

|        模块        |                  职责                  |
| :----------------: | :------------------------------------: |
| CommentServiceImpl | 负责实现酒店信息查询与维护所需要的服务 |
|     CommentPO      |       用户评论信息的领域模型对象       |

3. 模块类内部的接口规范

   CommentServiceImpl的接口规范如表x所示

     <div style="text-align: center; font-weight:bold">表x CommentServiceImpl的接口规范</div>

   - 提供的服务（供接口）

     - CommentServiceImpl.addComment
       - 语法：public Boolean addComment(CommentVO commentVO)
       - 前置条件：用户该订单状态为已退房或已入住
       - 后置条件：在该酒店评论列表中添加该评论
     - CommentServiceImpl.queryByCommentId
       - 语法：public CommentVO queryByCommentId(Integer id)
       - 前置条件：提供有效的评论id
       - 后置条件：返回id对应的评论
     - CommentServiceImpl.queryByHotelId
       - 语法：public List<CommentVO> queryByHotelId(Integer id)
       - 前置条件：提供有效的酒店id
       - 后置条件：返回list对象，包含该酒店所有的评论信息

   - 需要的服务（需接口）

     -  CommentMapper.addComment(CommentPO)

        -  添加新评论


     - CommentMapper.queryByCommentId(int)

       - 根据评论id查询评论信息

     - CommentMapper.queryByHotelId(int)

       - 根据酒店id查询评论信息


   

4. 业务逻辑层的动态模型

   图x表示了在酒店预订系统中，当客户添加评论时，网站业务逻辑处理相关对象之间的协作

   ![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200604075354.png)

     <div style="text-align: center; font-weight:bold">图x 添加评论的顺序图</div>

5. 业务逻辑层的设计原理

   利用委托式控制风格，每个界面需要访问的业务逻辑由各自的ServiceImpl委托给不同的领域对象。

