# 4.结构视角

### 4.1 业务逻辑层的分解

#### 4.1.1 userbl模块

1. 模块概述：

    userbl模块承担的需求参见需求规格说明文档功能需求及相关非功能需求

    userbl模块的职责和接口参见软件系统结构描述文档

2. 整体结构

    根据体系结构的设计，我们使用分层的模式来构建本系统，将系统分为web展示层、restful api层、业务逻辑层、数据层。每一层之间为了增加灵活性，我们会添加接口。比如API Controller层和业务逻辑层之间，我们添加了bl.user.AccountService接口；业务逻辑层与数据层之间添加了data.credit.CreditMapper、data.enterprise.EntMapper、data.user.AccountMapper接口。这样，我们将依赖接口而非实体类，增加了系统的灵活性。

    CreditInfo（PO)、User（PO)是作为用户信息、信用持久化对象被添加到设计模型中的；

    userbl模块的设计如图所示：
    
    ![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200604162145.png)

 userbl模块各个类的职责如下表所示：

  <div style="text-align: center; font-weight:bold">表x userbl模块各个类的职责</div>

|        模块        |                    职责                    |
| :----------------: | :----------------------------------------: |
| AccountServiceImpl | 负责实现用户信息查询与维护账户所需要的服务 |
|     CreditInfo     |         用户信用信息的领域模型对象         |
|        User        |           用户信息的领域模型对象           |

模块类内部的接口规范

AccountServiceImpl的接口规范如表x所示

  <div style="text-align: center; font-weight:bold">表x AccountServiceImpl的接口规范</div>

- 提供的服务（供接口）

    - AccountServiceImpl.registerAccount
        - 语法：public ResponseVO registerAccount(UserVO userVO) 
        - 前置条件：账号尚未被注册不存在
        - 后置条件：添加这个用户
    - AccountServiceImpl.login
        - 语法：public User login(UserForm userForm) 
        - 前置条件：无
        - 后置条件：登陆成功

    - AccountServiceImpl.getUserInfo
        - 语法：public User getUserInfo(int id) 
        - 前置条件：存在对应id的user
        - 后置条件：返回该用户信息
    - AccountServiceImpl.updateUserInfo
        - 语法：public ResponseVO updateUserInfo(int id, String password, String username, String phonenumber) 
        - 前置条件：存在对应id的user
        - 后置条件：更新对应id的user的信息
    - AccountServiceImpl. getUserCreditInfo
        - 语法：public ResponseVO getUserCreditInfo(int id) 
        - 前置条件：存在对应id的user
        - 后置条件：更新对应id的user的信用信息

    - AccountServiceImpl. investCredit
        - 语法：public ResponseVO investCredit(int id, double investedMoney) 
        - 前置条件：存在对应id的user
        - 后置条件：更新用户的信用值
    - AccountServiceImpl.setAsHtlMgr
        - 语法：public ResponseVO setAsHtlMgr(Integer id) 
        - 前置条件：存在对应id的user
        - 后置条件：将账户设置为酒店管理人员

    - AccountServiceImpl.registerEntUser
        - 语法：public ResponseVO registerEntUser(UserEntVO userEntVO) 
        - 前置条件：存在对应id的user
        - 后置条件：将账户设置为企业级用户
    - AccountServiceImpl.searchUsers
        - 语法：public ResponseVO searchUsers(UserVO userVO) 
        - 前置条件：无
        - 后置条件：返回查询结果
    - AccountServiceImpl.deleteUser
        - 语法：public ResponseVO deleteUser(Integer id) 
        - 前置条件：存在对应id的user
        - 后置条件：将用户删掉

- 需要的服务（需接口）
    - accountMapper.createNewAccount(user)
        - 新建一个用户账户
    - accountMapper.getAccountByName(userForm.getEmail())
        - 通过emal获取用户账户信息
    - accountMapper.getAccountById(id)
        - 通过id获取用户账户信息
    - accountMapper.updateAccount(id, password, username, phonenumber);
        - 更新相应用户信息
    -  creditMapper.getCreditInfoByUserId(id);
        - 通过id获取用户信用值
    - entMapper.validateEntUser(entVO)
        - 根据信息判断是否为企业用户

    - accountMapper.updateAccountCredit(id,newCredit)
        - 根据id更新用户信息
    -  creditMapper.addCreditInfo(creditInfo);
        - 增加用户信用值
    - accountMapper.updateAsMgr(id)
        - 根据id获取将用户绑定为酒店管理人员

    - accountMapper.deleteUser(id)
        - 根据id获取将用户删除

4.业务逻辑层的动态模型

图x表示了在酒店预订系统中，当用户更新自身信息时，user业务逻辑处理相关对象之间的协作

![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200604162151.png)

5.业务逻辑层的设计原理

利用委托式控制风格，每个界面需要访问的业务逻辑由各自的ServiceImpl委托给不同的领域对象。