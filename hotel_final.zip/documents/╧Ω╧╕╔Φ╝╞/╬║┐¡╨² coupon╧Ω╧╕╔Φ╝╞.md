# 4.结构视角

### 4.1 业务逻辑层的分解

#### 4.1.1 couponbl模块

1. 模块概述

    couponbl模块承担的需求参见需求规格说明文档功能需求及相关非功能需求

    couponbl模块的职责和接口参见软件系统结构描述文档

2. 整体结构

    根据体系结构的设计，我们使用分层的模式来构建本系统，将系统分为web展示层、restful api层、业务逻辑层、数据层。每一层之间为了增加灵活性，我们会添加接口。比如API Controller层和业务逻辑层之间，我们添加了bl.coupon.CouponMatchStrategy、bl.coupon.CouponService。接口；业务逻辑层与数据层之间添加了coupon.CouponMapper接口。这样，我们将依赖接口而非实体类，增加了系统的灵活性。

    Coupon（po）是作为优惠券持久化对象被添加到设计模型中的；OrderVO是除数据持久化层之外交换数据使用的VO；

    couponlbl模块的设计如图所示：

![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200604162131.png)

  <div style="text-align: center; font-weight:bold">表x couponbl模块各个类的职责</div>

|             模块              |                             职责                             |
| :---------------------------: | :----------------------------------------------------------: |
|       CouponServiceImpl       |      负责实现符合条件coupon查询与coupon添加所需要的服务      |
|  FestivalCouponStrategyImpl   |     负责实现判断某个订单是否满足节日特惠政策所需要的服务     |
|  MultiRoomCouponStrategyImpl  |     负责实现判断某个订单是否满足多间优惠政策所需要的服务     |
| TargetMoneyCouponStrategyImpl | 负责实现判断某个订单是否满足某种满减金额优惠策略所需要的服务 |
|    TimeCouponStrategyImpl     |   负责实现判断某个订单是否满足某种限时优惠策略所需要的服务   |
|            Coupon             |                     优惠券的领域模型对象                     |

模块类内部的接口规范

HotelServiceImpl的接口规范如表x所示

  <div style="text-align: center; font-weight:bold">表x CouponServiceImpl的接口规范</div>

- 提供的服务（供接口）
    - CouponServiceImpl.getMatchOrderCoupon
        - 语法：public List<Coupon> getMatchOrderCoupon(OrderVO orderVO) 
        - 前置条件：无
        - 后置条件：返回符合条件的coupon

    - CouponServiceImpl.getHotelAllCoupon
        - 语法：public List<Coupon> getHotelAllCoupon(Integer hotelId) 
        - 前置条件：该酒店存在
        - 后置条件：返回酒店所有的优惠券

    - CouponServiceImpl.getWebAdminAllCoupon
        - 语法：public List<Coupon> getWebAdminAllCoupon() 
        - 前置条件：无
        - 后置条件：返回所有优惠券

    - CouponServiceImpl.addHotelMultiRoomCoupon

        - 语法：public CouponVO addHotelMultiRoomCoupon(HotelMultiRoomCouponVO couponVO) 
        - 前置条件：酒店存在
        - 后置条件：添加这个优惠券到酒店

    - CouponServiceImpl.addHotelTargetMoneyCoupon

        - 语法：public CouponVO addHotelTargetMoneyCoupon(HotelTargetMoneyCouponVO couponVO) 
        - 前置条件：酒店存在
        - 后置条件：添加这个优惠券到酒店

    - CouponServiceImpl.addHotelFestivalCoupon

        - 语法：public CouponVO addHotelFestivalCoupon(HotelFestivalCouponVO couponVO) 
        - 前置条件：酒店存在
        - 后置条件：添加这个优惠券到酒店

        

- 需要的服务（需接口）
    -  CouponMatchStrategy.isMatch(OrderVO orderVO, Coupon coupon)
        - 判断该订单是否符合优惠券条件
    - couponMapper.selectByHotelId(int hotelId)
        - 根据id获取该酒店所有优惠券
    - couponMapper.insertCoupon(coupon)
        - 向数据库插入一条优惠券

  <div style="text-align: center; font-weight:bold">表x FestivalCouponStrategyImpl的接口规范</div>

- 提供的服务（供接口）
    - FestivalCouponStrategyImpl.isMatch
        - 语法：public boolean isMatch(OrderVO orderVO, Coupon coupon) 
        - 前置条件：无
        - 后置条件：判断订单是否符合该优惠券

  <div style="text-align: center; font-weight:bold">表x MultiRoomCouponStrategyImpl的接口规范</div>

- 提供的服务（供接口）
    - MultiRoomCouponStrategyImpl.isMatch
        - 语法：public boolean isMatch(OrderVO orderVO, Coupon coupon) 
        - 前置条件：无
        - 后置条件：判断订单是否符合该优惠券

  <div style="text-align: center; font-weight:bold">表x TargetMoneyCouponStrategyImpl的接口规范</div>

- 提供的服务（供接口）
    - TargetMoneyCouponStrategyImpl.isMatch
        - 语法：public boolean isMatch(OrderVO orderVO, Coupon coupon) 
        - 前置条件：无
        - 后置条件：判断订单是否符合该优惠券

  <div style="text-align: center; font-weight:bold">表x TimeCouponStrategyImpl的接口规范</div>

- 提供的服务（供接口）
    - TimeCouponStrategyImpl.isMatch
        - 语法：public boolean isMatch(OrderVO orderVO, Coupon coupon) 
        - 前置条件：无
        - 后置条件：判断订单是否符合该优惠券

业务逻辑层的动态模型

   图x表示了在酒店预订系统中，当酒店管理人员添加新优惠券时，coupon业务逻辑处理相关对象之间的协作

![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200604162136.png)