# 奚志恒  ORDER模块详细设计

ORDER模块

(1)模块描述

-  Order模块承担的需求见需求规格说明文档功能需求及相关非功能需求。
-  Order模块的职责及接口参见软件系统结构描述文档7.架构设计。

(2)整体结构

- 根据体系结构的设计，我们使用分层的模式来构建本系统，将系统分为web展示层、restful api层、业务逻辑层、数据层。每一层之间为了增加灵活性，我们会添加接口。restful api层和业务逻辑层之间添加bl.Order.OrderService接口。业务逻辑层和数据层之间添加data.order.OrderMapper接口。这样，我们将依赖于接口而非实体类，增加了系统的灵活性。
- Order模块的设计图如下所示:

![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200602110011.png)



- Order模块各个类的职责如下表所示:

  | 职责             | 模块               |
  | ---------------- | ------------------ |
  | OrderServiveImpl | 负责实现订单业务   |
  | Order            | 订单的领域模型对象 |

(3)模块内部类的接口规范

**OrderServiceImpl的接口规范**

- **提供的服务(供接口)**

  - OrderServiveImpl.addOrder

    - 语法

      - ```java
        public ResponseVO addOrder(OrderVO orderVO)
        ```

    - 前置条件:用户预订订单

    - 后置条件:记录并更新订单信息

  - OrderServiveImpl.getAllOrders

    - 语法

      - ```java
        public List<Order> getAllOrders()
        ```

    - 前置条件:无

    - 后置条件:返回所有订单的列表

  - OrderServiveImpl.getUserOrders

    - 语法

      - ```java
        public List<Order> getUserOrders(int userid)
        ```

    - 前置条件:用户id正确

    - 后置条件:返回该用户的订单列表

  - OrderServiveImpl.annulOrder

    - 语法:

      - ```java
        public ResponseVO annulOrder(int orderid)
        ```

    - 前置条件:订单id正确

    - 后置条件:撤销订单并更新订单信息

  - OrderServiveImpl.getHotelOrders

    - 语法:

      - ```java
        public List<Order> getHotelOrders(Integer hotelId)
        ```

    - 前置条件:传入正确酒店id

    - 后置条件:返回该酒店的订单列表

  - OrderServiveImpl.getOrderDetail

    - 语法

      - ```java
        public Order getOrderDetail(Integer orderid)
        ```

    - 前置条件:传入正确订单id

    - 后置条件:返回订单详细信息

  - OrderServiveImpl.checkInOrder

    - 语法

      - ```java
        public ResponseVO checkInOrder(int orderid)
        ```

    - 前置条件:用户入住,传入正确的订单id

    - 后置条件:执行订单并更新订单信息

  - OrderServiveImpl.checkAndUpdateStateOneOrder

    - 语法

      - ```java
        public void checkAndUpdateStateOneOrder(int orderid)
        ```

    - 前置条件:传入正确的订单id

    - 后置条件:检查订单是否异常并更新订单状态

  - OrderServiveImpl.checkOutOrder

    - 语法

      - ```java
        public ResponseVO checkOutOrder(int orderid)
        ```

    - 前置条件:用户退房,传入正确订单id

    - 后置条件:为用户退房,更新订单信息和库存信息

  - OrderServiveImpl.checkIfForceCheckOutOne

    - 语法

      - ```java
        public void checkIfForceCheckOutOne(int orderid)
        ```

    - 前置条件:传入正确的订单id

    - 后置条件:检查该订单是否应该强制退房

  - OrderServiveImpl.abnormalOrdersOfTheDay

    - 语法

      - ```java
        public ResponseVO abnormalOrdersOfTheDay(int hotelId)
        ```

    - 前置条件:传入正确的酒店id

    - 后置条件:返回当日异常订单列表

  - OrderServiveImpl.appealAbnormalOrder

    - 语法

      - ```java
        public ResponseVO appealAbnormalOrder(int orderId)
        ```

    - 前置条件:传入正确的异常订单id

    - 后置条件:更新订单信息

  - OrderServiveImpl.deleteOrder

    - 语法

      - ```java
        public ResponseVO deleteOrder(int orderId)
        ```

    - 前置条件:传入需要删除的正确的订单id

    - 后置条件:删除订单

  - OrderServiveImpl.getOrderedHotels

    - 语法

      - ```java
        public List<Integer> getOrderedHotels(int userId)
        ```

    - 前置条件:传入正确的用户id

    - 后置条件:返回该用户预定过的酒店id列表

  - OrderServiveImpl.getOrderedNumOfThisRoomType

    - 语法

      - ```java
        public Integer getOrderedNumOfThisRoomType(RoomType roomType, String date, Integer hotelId)
        ```

    - 前置条件:传入房间类型,日期,酒店id

    - 后置条件:返回该酒店某天该房型被预订的数目

- **需要的服务(需接口)**

| 服务名                                                       | 服务                                       |
| ------------------------------------------------------------ | ------------------------------------------ |
| RoomRepoService.getForPeriod(DatePeriodVO datePeriodVO)      | 获得某段时间内某酒店某一制定房型可用的数量 |
| RoomRepoService.updateAvailableOfRoomIdAndDates(Integer roomId, String startDateStr, String endDateStr, int offset) | 更新某段日期内某酒店某房型可用数量         |
| CreditMapper.addCreditInfo(CreditInfo creditInfo)            | 为Credit表添加一条记录                     |
| RoomMapper.selectRoomByHotelIdAndType2( Integer hotelId, String roomType) | 通过酒店id和房间类型获得房型id             |
| OrderMapper.addOrder(Order order)                            | 插入单一持久化对象,插入一条订单记录        |
| OrderMapper.getAllOrders()                                   | 获取所有订单                               |
| OrderMapper.getUserOrders(int userid)                        | 获取某个用户的订单列表                     |
| OrderMapper.annulOrder( int orderid)                         | 用户撤销订单,更新order表信息               |
| OrderMapper.getOrderById( int orderid)                       | 查询一条order记录                          |
| OrderMapper.getOrderedHotels( int userid)                    | 查询用户预定过的酒店                       |
| OrderMapper.checkInOrder( int orderid)                       | 执行订单,更新order表信息                   |
| OrderMapper.abnormalOrder( int orderid)                      | 订单异常,更新order表信息                   |
| OrderMapper.updateOrderCheckInDate(int orderid,  String checkInDate) | 更新订单入住时间                           |
| OrderMapper.checkOutOrder(int orderid)                       | 退房,更新order表信息                       |
| OrderMapper.updateOrderCheckOutDate( int orderid,  String checkOutDate) | 更新订单退房日期                           |
| OrderMapper.getabnormalOrdersOfTheDay( int hotelId)          | 获取当日异常订单                           |
| OrderMapper.appealAbnormalOrder( int orderid)                | 异常订单申诉,更新订单信息                  |
| OrderMapper.deleteOrder( int orderid)                        | 删除单一持久化对象,删除一条订单记录        |
| OrderMapper.getOrdersByHotelId( int hotelId)                 | 获取酒店订单                               |
| OrderMapper.getOrderedNumOfThisRoomType(RoomType roomType,            int hotelId) | 获取某酒店某房型预订订单数                 |

(4)业务逻辑层的动态模型

下图表明了互联网酒店预订系统中,当用户想要获取订单详细信息的过程中,系统业务逻辑处理的相关对象之间的协作 . 

![](https://cse2020-dune.oss-cn-shanghai.aliyuncs.com/20200602110015.png)

(5)业务逻辑层的设计原理

利用委托式控制风格，每个界面需要访问的业务逻辑由各自的BLServiceImpl委托给不同的领域对象。