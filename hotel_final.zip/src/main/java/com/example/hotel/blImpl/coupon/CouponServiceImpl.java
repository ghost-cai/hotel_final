package com.example.hotel.blImpl.coupon;

import com.example.hotel.bl.coupon.CouponService;
import com.example.hotel.bl.coupon.CouponMatchStrategy;
import com.example.hotel.data.coupon.CouponMapper;
import com.example.hotel.po.Coupon;
import com.example.hotel.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


@Service
public class CouponServiceImpl implements CouponService {


    private final  TargetMoneyCouponStrategyImpl targetMoneyCouponStrategy;
    private final  TimeCouponStrategyImpl timeCouponStrategy;
    private final  CouponMapper couponMapper;

    private static List<CouponMatchStrategy> strategyList = new ArrayList<>();

    @Autowired
    public CouponServiceImpl(TargetMoneyCouponStrategyImpl targetMoneyCouponStrategy,
                             TimeCouponStrategyImpl timeCouponStrategy,
                             MultiRoomCouponStrategyImpl multiRoomCouponStrategy,
                             FestivalCouponStrategyImpl festivalCouponStrategy,
                             CouponMapper couponMapper) {
        this.couponMapper = couponMapper;
        this.targetMoneyCouponStrategy = targetMoneyCouponStrategy;
        this.timeCouponStrategy = timeCouponStrategy;
        strategyList.add(targetMoneyCouponStrategy);
        strategyList.add(timeCouponStrategy);
    }


    /**
     * 选择合适的优惠券
     * @param orderVO 对应order
     * @return
     *
     * zjy: Add Coupons for web admin
     */

    @Override
    public List<Coupon> getMatchOrderCoupon(OrderVO orderVO) {
        List<Coupon> hotelCoupons = getHotelAllCoupon(orderVO.getHotelId());
        List<Coupon> availAbleCoupons = new ArrayList<>();

        // 优惠券只有酒店管理员可以控制
        // 不做系统级别的优惠券
        // 对所有酒店级别的优惠券遍历
        for (int i = 0; i < hotelCoupons.size(); i++) {
            for (CouponMatchStrategy strategy : strategyList) {
                if (strategy.isMatch(orderVO, hotelCoupons.get(i))) {
                    availAbleCoupons.add(hotelCoupons.get(i));
                }
            }
        }

        return availAbleCoupons;
    }

    @Override
    public List<Coupon> getHotelAllCoupon(Integer hotelId) {
        List<Coupon> hotelCoupons = couponMapper.selectByHotelId(hotelId);
        return hotelCoupons;
    }

    @Override
    public List<Coupon> getWebAdminAllCoupon() {
        List<Coupon> webAdminCoupons = couponMapper.selectByHotelId(-1);
        if (webAdminCoupons == null) webAdminCoupons = new ArrayList<>();
        return webAdminCoupons;
    }


    @Override
    public CouponVO addHotelTargetMoneyCoupon(HotelTargetMoneyCouponVO couponVO) {
        Coupon coupon = new Coupon();
        coupon.setCouponName(couponVO.getName());
        coupon.setDescription(couponVO.getDescription());
        coupon.setCouponType(couponVO.getType());

        // 其中一个是负的
        // DiscountMoney 折扣设置为负数(遗留问题)
        coupon.setDiscountMoney(couponVO.getDiscountMoney());
        coupon.setDiscount(-1);
        coupon.setTargetMoney(couponVO.getTargetMoney());

        coupon.setHotelId(couponVO.getHotelId());
        coupon.setDiscountMoney(couponVO.getDiscountMoney());
        coupon.setStatus(1);
        int result = couponMapper.insertCoupon(coupon);
        couponVO.setId(result);
        return couponVO;
    }

    @Override
    public CouponVO addHotelMultiRoomCoupon(HotelMultiRoomCouponVO couponVO) {
        Coupon coupon = new Coupon();
        coupon.setCouponName(couponVO.getName());
        coupon.setDescription(couponVO.getDescription());
        coupon.setCouponType(couponVO.getType());
        coupon.setHotelId(couponVO.getHotelId());

        // 其中一个是负的(多间优惠，折扣Money与折扣额度其中一个需要设置成负值)
        coupon.setDiscountMoney(couponVO.getDiscountMoney());
        coupon.setDiscount(couponVO.getDiscount());

        coupon.setStatus(1);

        int result = couponMapper.insertCoupon(coupon);
        couponVO.setId(result);
        return couponVO;
    }

    @Override
    public CouponVO addHotelFestivalCoupon(HotelFestivalCouponVO couponVO) {
        // 酒店限时优惠
        Coupon coupon = new Coupon();
        coupon.setCouponName(couponVO.getName());
        coupon.setDescription(couponVO.getDescription());
        coupon.setCouponType(couponVO.getType());
        coupon.setHotelId(couponVO.getHotelId());

        // 其中一个是负的(折扣Money与折扣额度其中一个需要设置成负值)
        coupon.setDiscountMoney(couponVO.getDiscountMoney());
        coupon.setDiscount(couponVO.getDiscount());
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime startT = LocalDateTime.parse(couponVO.getStartDate()+" 00:00:00",formatter);
        LocalDateTime endT = LocalDateTime.parse(couponVO.getEndDate()+" 00:00:00",formatter);
        coupon.setStartTime(startT);
        coupon.setEndTime(endT);

        coupon.setStatus(1);
        coupon.setTargetMoney(couponVO.getTargetMoney());
        int result = couponMapper.insertCoupon(coupon);
        couponVO.setId(result);
        return couponVO;
    }


}
