package com.example.hotel.blImpl.coupon;

import com.example.hotel.bl.coupon.CouponMatchStrategy;
import com.example.hotel.po.Coupon;
import com.example.hotel.vo.OrderVO;
import org.springframework.stereotype.Service;

@Service
public class MultiRoomCouponStrategyImpl implements CouponMatchStrategy {


    /**
     * 判断某个订单是否满足 多间优惠 政策
     * 多间指三间或以上
     *
     * @param orderVO
     * @param coupon
     * @return isMatch
     */
    @Override
    public boolean isMatch(OrderVO orderVO, Coupon coupon) {

        // 酒店发放的优惠券，需要判断酒店id
        // 平台发放的优惠券，默认id = -1
        return coupon.getCouponType() == 2 &&
                orderVO.getRoomNum() >= 3 &&
                (coupon.getHotelId() < 0 || coupon.getHotelId().equals(orderVO.getHotelId()));
    }
}
