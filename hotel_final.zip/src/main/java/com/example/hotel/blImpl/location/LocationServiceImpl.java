package com.example.hotel.blImpl.location;

import com.example.hotel.bl.location.LocationService;
import com.example.hotel.data.location.LocationMapper;
import com.example.hotel.po.BizRegion;
import com.example.hotel.po.City;
import com.example.hotel.po.Location;
import com.example.hotel.po.Province;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class LocationServiceImpl implements LocationService {
    @Autowired
    LocationMapper locationMapper;

    @Override
    public List<Location> getAllLocations() {
        List<Location> locations = new ArrayList<>();

        List<Province> allProvinces = locationMapper.getAllProvinces();
        for (Province p : allProvinces) {
            Location pl = new Location();
            pl.setValue(p.getId()); pl.setLabel(p.getName());
            locations.add(pl);

            List<City> allCityByProvince = locationMapper.getAllCityByProvince(p);
            for (City c : allCityByProvince) {
                Location cl = new Location();
                cl.setValue(c.getId()); cl.setLabel(c.getName());
                pl.addAChild(cl);

                List<BizRegion> allBizByCity = locationMapper.getAllBizByCity(c);
                for (BizRegion b : allBizByCity) {
                    Location bl = new Location();
                    bl.setValue(b.getId()); bl.setLabel(b.getName());
                    cl.addAChild(bl);
                }
            }
        }
        return locations;
    }
}
