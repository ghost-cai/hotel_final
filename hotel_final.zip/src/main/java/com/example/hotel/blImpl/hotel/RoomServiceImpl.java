package com.example.hotel.blImpl.hotel;

import com.example.hotel.bl.hotel.RoomService;
import com.example.hotel.data.hotel.RoomMapper;
import com.example.hotel.enums.RoomType;
import com.example.hotel.po.HotelRoom;
import com.example.hotel.vo.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoomServiceImpl implements RoomService {

    @Autowired
    private RoomMapper roomMapper;

    @Override
    public List<HotelRoom> retrieveHotelRoomInfo(Integer hotelId) {
        return roomMapper.selectRoomsByHotelId(hotelId);
    }

    @Override
    public void insertRoomInfo(HotelRoom hotelRoom) {
        roomMapper.insertRoom(hotelRoom);
    }

    @Override
    public void updateRoomInfo(Integer hotelId, String roomType, Integer rooms) {
        roomMapper.updateRoomInfo(hotelId,roomType,rooms);
    }

    @Override
    public int getRoomCurNum(Integer hotelId, String roomType) {
        return roomMapper.getRoomCurNum(hotelId,roomType);
    }

    @Override
    public ResponseVO setRoomPriceByRoomId(int roomId, double price) {
        int rowNum = roomMapper.setRoomPriceByRoomId(roomId,price);
        if(rowNum>0){
            return ResponseVO.buildSuccess(true);
        }
        return ResponseVO.buildFailure("该房型不存在");
    }

    @Override
    public HotelRoom getRoomById(Integer roomId) {
        return roomMapper.selectRoomById(roomId);
    }

    @Override
    public boolean getRoomIsExisted(HotelRoom hotelRoom) {
        //判断是否出现
        RoomType roomType = hotelRoom.getRoomType();
        Integer hotelId  =hotelRoom.getHotelId();
        if(roomMapper.getRoomIsExisted2(hotelId,roomType)>0){
            return true;
        }
        return false;
    }

    @Override
    public HotelRoom selectRoomByHotelIdAndType(Integer hotelId, String roomType) {
        return roomMapper.selectRoomByHotelIdAndType2(hotelId,roomType);
    }
}
