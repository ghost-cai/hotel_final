package com.example.hotel.blImpl.coupon;

import com.example.hotel.bl.coupon.CouponMatchStrategy;
import com.example.hotel.po.Coupon;
import com.example.hotel.vo.OrderVO;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class FestivalCouponStrategyImpl implements CouponMatchStrategy {


    /**
     * 判断某个订单是否满足 节日特惠 政策
     * 所谓节日特惠判断依据为是否在节日周期内
     * 1特惠 2多间特惠 3满减优惠 4节日优惠
     *
     * @param orderVO
     * @param coupon
     * @return isMatch
     * 修改：xzh
     */
    @Override
    public boolean isMatch(OrderVO orderVO, Coupon coupon) {
        if (coupon.getCouponType() != 4 ||
                !(coupon.getHotelId() < 0 || coupon.getHotelId().equals(orderVO.getHotelId())))
            return false;

        LocalDateTime ckInDate;
        LocalDateTime ckOutDate;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        ckInDate = LocalDateTime.parse(orderVO.getCheckInDate() + " 00:00:00", formatter);
        ckOutDate = LocalDateTime.parse(orderVO.getCheckOutDate() + " 00:00:00", formatter);

        boolean isProperTime = ckInDate.isAfter(coupon.getStartTime()) && ckOutDate.isBefore(coupon.getEndTime());

        // 酒店发放的优惠券，需要判断酒店id
        // 平台发放的优惠券，默认id = -1
        return coupon.getCouponType() == 4 && isProperTime ;

    }
}
