package com.example.hotel.blImpl.comment;


import com.example.hotel.bl.comment.CommentService;
import com.example.hotel.data.comment.CommentMapper;
import com.example.hotel.po.CommentPO;
import com.example.hotel.vo.CommentVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    CommentMapper commentMapper;

    @Override
    public Boolean addComment(CommentVO commentVO) {
        boolean isSucceed = true;
        int lines = 0;
        try {
            lines = commentMapper.addComment(new CommentPO(commentVO));
        } catch (Exception e) {
            isSucceed = false;
        } finally {
            isSucceed = isSucceed && lines > 0;
        }
        return isSucceed;
    }

    @Override
    public CommentVO queryByCommentId(Integer id) {
        CommentPO commentPO = commentMapper.queryByCommentId(id);
        if (commentPO != null) return new CommentVO(commentPO);
        return null;
    }

    @Override
    public List<CommentVO> queryByHotelId(Integer id) {
        List<CommentPO> commentPOS = commentMapper.queryByHotelId(id);
        if (commentPOS.size() == 0) return new ArrayList<CommentVO>();

        ArrayList<CommentVO> commentVOS = new ArrayList<>();
        commentPOS.forEach(commentPO -> commentVOS.add(new CommentVO(commentPO)));
        return commentVOS;
    }
}
