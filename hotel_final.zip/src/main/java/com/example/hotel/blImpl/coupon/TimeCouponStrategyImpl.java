package com.example.hotel.blImpl.coupon;

import com.example.hotel.bl.coupon.CouponMatchStrategy;
import com.example.hotel.po.Coupon;
import com.example.hotel.vo.OrderVO;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class TimeCouponStrategyImpl implements CouponMatchStrategy {


    /**
     * 判断某个订单是否满足某种限时优惠策略
     * @param orderVO
     * @return
     * 修改：xzh
     */
    @Override
    public boolean isMatch(OrderVO orderVO, Coupon coupon) {
        if ((coupon.getCouponType() != 4&&coupon.getCouponType()!=5) ||
                !(coupon.getHotelId() < 0 || coupon.getHotelId().equals(orderVO.getHotelId())))
            return false;
        LocalDateTime ckInDate;
        LocalDateTime ckOutDate;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        ckInDate = LocalDateTime.parse(orderVO.getCheckInDate() + " 00:00:00", formatter);
        ckOutDate = LocalDateTime.parse(orderVO.getCheckOutDate() + " 00:00:00", formatter);
        boolean isProperTime = ckInDate.isAfter(coupon.getStartTime()) && ckOutDate.isBefore(coupon.getEndTime());

        // 酒店发放的优惠券，需要判断酒店id
        // 平台发放的优惠券，默认id = -1
        // 遗留问题，不做改变
        return isProperTime ;

    }
}
