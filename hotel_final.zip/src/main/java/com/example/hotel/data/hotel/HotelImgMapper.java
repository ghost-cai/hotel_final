package com.example.hotel.data.hotel;


import com.example.hotel.vo.HotelImgVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
/**
 * @Author: zjy,xzh
 * @Date: 6-15
 */
@Mapper
@Repository
public interface HotelImgMapper {
    int insertPic(HotelImgVO hotelImgVO);
    int updatePic(HotelImgVO hotelImgVO);
    HotelImgVO getPic(@Param("hotelId") Integer hotelId);

}
