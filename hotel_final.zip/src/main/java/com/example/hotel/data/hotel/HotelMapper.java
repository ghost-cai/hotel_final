package com.example.hotel.data.hotel;

import com.example.hotel.po.Hotel;
import com.example.hotel.vo.HotelSearchVO;
import com.example.hotel.vo.HotelVO;
import com.example.hotel.vo.PositionVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * @Author: zjy,xzh
 * @Date: 6-9
 */
@Mapper
@Repository
public interface HotelMapper {

    int insertHotel(Hotel hotel);

    List<HotelVO> selectAllHotel();

    HotelVO selectById(@Param("id") Integer id);

//    List<HotelVO> managedHotels(@Param("userId") Integer userId);

    List<HotelVO> selectByPos(PositionVO position);

    List<Integer> selectOrderedHotelIds(@Param("userId") Integer userId);

    List<HotelVO> searchHotel(HotelSearchVO searchVO);
    //酒店工作人员 B.i
    //xzh
    int updateHotelBasicInfo(Hotel hotel);

    int bindNewHotelMgr(@Param("hotelId") Integer hotelId, @Param("mgrId") Integer mgr);

    List<HotelVO> selectManagedBy(@Param("mgrId") Integer mgrId);
}
