package com.example.hotel.data.order;

import com.example.hotel.enums.RoomType;
import com.example.hotel.po.Order;
import com.example.hotel.vo.OrderVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * @Author: chenyizong,xzh,zjy
 * @Date: 2020-06-05
 */
@Mapper
@Repository
public interface OrderMapper {

    int addOrder(Order order);

    List<Order> getAllOrders();

    List<Order> getUserOrders(@Param("userid") int userid);

    int annulOrder(@Param("orderid") int orderid);

    Order getOrderById(@Param("orderid") int orderid);

    List<Integer> getOrderedHotels(@Param("userid") int userid);

    //xzh
    //B.vi 订单执行chekin
    int checkInOrder(@Param("orderid") int orderid);


    //xzh
    //B.vi
    int abnormalOrder(@Param("orderid") int orderid);

    //xzh
    //B.iv
    int updateOrderCheckInDate(@Param("orderid") int orderid,
                               @Param("checkInDate") String checkInDate);

    //xzh
    //B,iv
    int checkOutOrder(@Param("orderid") int orderid);

    //xzh
    //B.iv
    int updateOrderCheckOutDate(@Param("orderid") int orderid,
                               @Param("checkOutDate") String checkOutDate);

    //xzh
    //C.ii.1
    //浏览每日未执行订单情况
    List<Order> getabnormalOrdersOfTheDay(@Param("hotelId") int hotelId);

    //xzh
    //C.ii.2
    //线下申诉异常订单
    int appealAbnormalOrder(@Param("orderid") int orderid);

    int deleteOrder(@Param("orderid") int orderid);

    List<Order> getOrdersByHotelId(@Param("hotelId") int hotelId);

    List<Order> getOrderedNumOfThisRoomType(@Param("roomType") RoomType roomType,
                                        @Param("hotelId") int hotelId);

}
