package com.example.hotel.data.security;

import com.example.hotel.vo.Permission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * @Author: zjy,xzh
 * @Date: 6-18
 */
@Mapper
@Repository
public interface PermissionMapper {

    List<Permission> queryPermissionsById(@Param("userId") int userId);

}
