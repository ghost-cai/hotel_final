package com.example.hotel.data.hotel;

import com.example.hotel.po.DatePeriodPO;
import com.example.hotel.po.HotelDateCntPO;
import com.example.hotel.po.RoomRepoPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * @Author: zjy,xzh
 * @Date: 6-8
 */
@Mapper
@Repository
public interface RoomRepoMapper {

    int addRoomOfDate(RoomRepoPO roomRepo);
    int setRoomOfDate(RoomRepoPO roomRepo);
    List<RoomRepoPO> searchRoom(RoomRepoPO roomRepoPO);

    List<HotelDateCntPO> getRoomCntOfHotelOfDates(@Param("hotelId") Integer hotelId, @Param("dates") List<String> dates);

    int getAvailableOfRoomIdAndDate(@Param("roomId") Integer roomId,@Param("date") String date);
    int setAvailableOfRoomIdAndDate(@Param("roomId") Integer roomId,@Param("date") String date,@Param("newValue") int newValue);




}
