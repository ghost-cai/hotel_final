package com.example.hotel.data.enterprise;

import com.example.hotel.vo.EntVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
/**
 * @Author: zjy,xzh
 * @Date: 6-9
 */
@Mapper
@Repository
public interface EntMapper {
    int validateEntUser(EntVO entVO);
    int associateUserWithEnt(@Param("userId") Integer userId, @Param("entId") Integer entId);
}
