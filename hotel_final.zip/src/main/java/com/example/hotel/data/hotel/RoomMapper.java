package com.example.hotel.data.hotel;

import com.example.hotel.enums.RoomType;
import com.example.hotel.po.Hotel;
import com.example.hotel.po.HotelRoom;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * @Author: zjy,xzh
 * @Date: 6-10
 */
@Mapper
@Repository
public interface RoomMapper {

    int updateRoomInfo(@Param("hotelId") Integer hotelId, @Param("roomType") String roomType, @Param("curNum") Integer curNum);

    int insertRoom(HotelRoom hotelRoom);

    List<HotelRoom> selectRoomsByHotelId(@Param("hotelId") Integer hotelId);

    HotelRoom selectRoomById(@Param("roomId") Integer roomId);
    int getRoomIsExisted(HotelRoom hotelRoom);
    int getRoomIsExisted2(@Param("hotelId") Integer hotelId, @Param("roomType") RoomType roomType);
    int getRoomCurNum(@Param("hotelId") Integer hotelId, @Param("roomType") String roomType);

    HotelRoom selectRoomByHotelIdAndType(@Param("hotelId") Integer hotelId, @Param("roomType") RoomType roomType);

    HotelRoom selectRoomByHotelIdAndType2(@Param("hotelId") Integer hotelId, @Param("roomType") String roomType);

    int setRoomPriceByRoomId(@Param("roomId") Integer roomId,@Param("price") double price);


}
