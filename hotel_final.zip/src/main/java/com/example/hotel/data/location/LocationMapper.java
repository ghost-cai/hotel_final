package com.example.hotel.data.location;

import com.example.hotel.po.BizRegion;
import com.example.hotel.po.City;
import com.example.hotel.po.Province;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: zjy,xzh
 * @Date: 6-6
 */
@Mapper
@Repository
public interface LocationMapper {
    List<Province> getAllProvinces();

    List<City> getAllCityByProvince(Province province);

    List<BizRegion> getAllBizByCity(City city);
}
