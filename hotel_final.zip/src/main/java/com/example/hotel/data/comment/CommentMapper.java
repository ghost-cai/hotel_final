package com.example.hotel.data.comment;

import com.example.hotel.po.CommentPO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Author: zjy,xzh
 * @Date: 6-1
 */
@Mapper
@Repository
public interface CommentMapper {
    int addComment(CommentPO commentPO);
    CommentPO queryByCommentId(@Param("id") int id);
    List<CommentPO> queryByHotelId(@Param("hotelId") int id);
}
