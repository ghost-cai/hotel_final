package com.example.hotel.data.user;

import com.example.hotel.vo.HotelImgVO;
import com.example.hotel.vo.UserImgVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
/**
 * @Author: zjy,xzh
 * @Date: 6-8
 */
@Mapper
@Repository
public interface UserImgMapper {
    int insertPic(UserImgVO userImgVO);
    int updatePic(UserImgVO userImgVO);
    UserImgVO getPic(@Param("userId") Integer userId);
}
