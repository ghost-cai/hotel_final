package com.example.hotel.data.credit;

import com.example.hotel.po.CreditInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
/**
 * @Author: zjy,xzh
 * @Date: 6-5
 */
@Mapper
@Repository
public interface CreditMapper {
    List<CreditInfo> getCreditInfoByUserId(@Param("id") int id);

    int addCreditInfo(CreditInfo creditInfo);

}
