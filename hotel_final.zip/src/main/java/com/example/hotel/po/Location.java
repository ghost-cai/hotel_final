package com.example.hotel.po;

import java.util.ArrayList;
import java.util.List;

public class Location {
    private String value;
    private String label;
    private List<Location> children = new ArrayList<>();

    public void addAChild(Location l) {
        children.add(l);
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<Location> getChildren() {
        return children;
    }

    public void setChildren(List<Location> children) {
        this.children = children;
    }
}
