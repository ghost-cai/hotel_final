package com.example.hotel.po;

import com.example.hotel.enums.CreditAction;

import java.util.Date;
//TODO  action感觉应该是string类型
public class CreditInfo {
    private String time;
    private int orderId;
    private CreditAction action;
    private double changeVal;
    private double afterChange;
    private int userId;
    public int getUserId() {
        return userId;
    }
    public void setUserId(int userId){this.userId=userId;}

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public CreditAction getAction() {
        return action;
    }

    public void setAction(CreditAction action) {
        this.action = action;
    }

    public double getChangeVal() {
        return changeVal;
    }

    public void setChangeVal(double changeVal) {
        this.changeVal = changeVal;
    }

    public double getAfterChange() {
        return afterChange;
    }

    public void setAfterChange(double afterChange) {
        this.afterChange = afterChange;
    }
}
