package com.example.hotel.po;

import com.example.hotel.enums.RoomType;

public class RoomTypeDetailVO {
    private String date;
    private Integer availableNum;
    private Integer reservedNum;
    public RoomTypeDetailVO(String date,Integer availableNum,Integer reservedNum){
        this.date=date;
        this.availableNum=availableNum;
        this.reservedNum=reservedNum;
    }
    public RoomTypeDetailVO(){}

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getAvailableNum() {
        return availableNum;
    }

    public void setAvailableNum(Integer availableNum) {
        this.availableNum = availableNum;
    }

    public Integer getReservedNum() {
        return reservedNum;
    }

    public void setReservedNum(Integer reservedNum) {
        this.reservedNum = reservedNum;
    }

}
