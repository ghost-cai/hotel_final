package com.example.hotel.po;

import com.example.hotel.vo.CommentVO;

import java.util.Objects;

public class CommentPO {
    private Integer id;
    private String commentDetail;
    private Integer orderId;
    private Double rate;

    public CommentPO() {
    }

    public CommentPO(CommentVO commentVO) {
        this.id = commentVO.getId();
        this.commentDetail = commentVO.getCommentDetail();
        this.orderId = commentVO.getOrderId();
        this.rate = commentVO.getRate();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCommentDetail() {
        return commentDetail;
    }

    public void setCommentDetail(String commentDetail) {
        this.commentDetail = commentDetail;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "CommentPO{" +
                "id=" + id +
                ", commentDetail='" + commentDetail + '\'' +
                ", orderId=" + orderId +
                ", rate=" + rate +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CommentPO commentPO = (CommentPO) o;
        return
                Objects.equals(commentDetail, commentPO.commentDetail) &&
                Objects.equals(orderId, commentPO.orderId) &&
                Objects.equals(rate, commentPO.rate);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, commentDetail, orderId, rate);
    }
}
