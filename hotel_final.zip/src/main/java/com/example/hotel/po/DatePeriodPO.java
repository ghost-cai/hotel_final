package com.example.hotel.po;

public class DatePeriodPO {
    private String fromDate;
    private String toDate;
    private Integer setVal;

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public Integer getSetVal() {
        return setVal;
    }

    public void setSetVal(Integer setVal) {
        this.setVal = setVal;
    }
}
