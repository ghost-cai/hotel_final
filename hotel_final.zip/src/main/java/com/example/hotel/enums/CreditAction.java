package com.example.hotel.enums;
//枚举类
public enum CreditAction {
    OrderExec("订单执行"),
    OrderErr("订单异常"),
    OrderRetreat("订单撤销"),
    AddFrc("充值");
    private String value;

    CreditAction(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return value;
    }
}
