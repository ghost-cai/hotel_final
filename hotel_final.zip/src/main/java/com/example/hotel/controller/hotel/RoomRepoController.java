package com.example.hotel.controller.hotel;

import com.example.hotel.bl.hotel.RoomRepoService;
import com.example.hotel.vo.DatePeriodVO;
import com.example.hotel.vo.ResponseVO;
import com.example.hotel.vo.RoomTypeUpdateVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: zjy,xzh
 * @Date: 6-2
 */
@RestController
@RequestMapping("/api/roomRepo")
public class RoomRepoController {

    @Autowired
    private RoomRepoService roomRepoService;

    @PostMapping("/getCurrPeriodRepo")
    public ResponseVO getCurrRepo(@RequestBody DatePeriodVO datePeriodVO) {
        return ResponseVO.buildSuccess(roomRepoService.getForPeriodList(datePeriodVO));
    }

    @PostMapping("/setCurrPeriodRepo")
    public ResponseVO setCurrRepo(@RequestBody DatePeriodVO datePeriodVO ) {
        return ResponseVO.buildSuccess(roomRepoService.setForPeriod(datePeriodVO));
    }

    @PostMapping("/roomTypeDetail")
    public ResponseVO roomTypeDetail(@RequestBody DatePeriodVO datePeriodVO){
        return ResponseVO.buildSuccess(roomRepoService.getCompleteInfoOfPeriod(datePeriodVO));
    }


    @PostMapping("/SetAvailableNumOfThisRoomType")
    public ResponseVO SetAvailableNumOfThisRoomType(@RequestBody RoomTypeUpdateVO roomTypeUpdateVO){
        return roomRepoService.SetAvailableRoomNum(roomTypeUpdateVO);
    }



}
