package com.example.hotel.controller.admin;

import com.example.hotel.bl.admin.AdminService;
import com.example.hotel.bl.user.AccountService;
import com.example.hotel.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author: chenyizong
 * @Date: 2020-03-04
 */
@RestController()
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired
    AdminService adminService;

    @PostMapping("/addManager")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO addManager(@RequestBody UserForm userForm){
        return adminService.addManager(userForm);
    }

    @PostMapping("/getAllManagers")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO getAllManagers(){
        return ResponseVO.buildSuccess(adminService.getAllManagers());
    }

    @PostMapping("/getAllClients")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO getAllClients(){return ResponseVO.buildSuccess(adminService.getAllClients());}

    @Autowired
    AccountService accountService;

    /**
     * 本api用于检索
     * 以列表形式返回符合条件的用户信息
     * @return
     */
    @PostMapping("/users")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO searchUsers(@RequestBody UserVO userVO) {
        return accountService.searchUsers(userVO);
    }

    @PostMapping("/{id}/userInfo/update")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO updateInfo(@RequestBody UserInfoVO userInfoVO, @PathVariable int id){
        return accountService.updateUserInfo(id,userInfoVO.getPassword(),userInfoVO.getUserName(),userInfoVO.getPhoneNumber());
    }

    @PostMapping("/hotel/bindManager")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO bindMgr(@RequestBody HotelBindingVO hotelBindingVO) {
        if (adminService.bindHotelMgr(hotelBindingVO)) return ResponseVO.buildSuccess();
        return ResponseVO.buildFailure("绑定失败");
    }

    @GetMapping("/{id}/hotelMgr/detail")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO queryManagedHotel(@PathVariable("id") Integer id) {
        List<HotelVO> hotelVOS = adminService.selectManagedBy(id);
        return ResponseVO.buildSuccess(hotelVOS);
    }

    @GetMapping("/{id}/hotelMgr/setAsMgr")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO setHotelMgr(@PathVariable Integer id) {
        return accountService.setAsHtlMgr(id);
    }

    @PostMapping("/deleteAccount/{userId}")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO deleteUser(@PathVariable Integer userId){return accountService.deleteUser(userId);}
}
