package com.example.hotel.controller.comment;

import com.example.hotel.bl.comment.CommentService;
import com.example.hotel.vo.CommentVO;
import com.example.hotel.vo.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * @author zhujinyu
 * @Date 2020-05-19
 */

@RestController()
@RequestMapping("/api/comment")
public class CommentController {

    @Autowired
    CommentService commentService;

    // 增加一条Comment
    @PostMapping("/addComment")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO addComment(@RequestBody CommentVO commentVO) {
        if (commentService.addComment(commentVO)) return ResponseVO.buildSuccess();
        else return ResponseVO.buildFailure("评论添加失败");
    }

    // 删除一条Comment id
    @GetMapping("/{id}/queryByCommentId")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO queryById(@PathVariable Integer id) {
        CommentVO commentVO = commentService.queryByCommentId(id);
        return ResponseVO.buildSuccess(commentVO);
    }

    // 查询By HotelId
    @GetMapping("/{id}/queryByHotelId")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO queryByHotelId(@PathVariable Integer id) {
        return ResponseVO.buildSuccess(commentService.queryByHotelId(id));
    }

}
