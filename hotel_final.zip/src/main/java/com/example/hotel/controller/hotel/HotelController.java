package com.example.hotel.controller.hotel;

import com.example.hotel.bl.hotel.HotelService;
import com.example.hotel.bl.hotel.RoomRepoService;
import com.example.hotel.bl.hotel.RoomService;
import com.example.hotel.po.HotelRoom;
import com.example.hotel.util.ServiceException;
import com.example.hotel.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
/**
 * @Author: zjy,xzh
 * @Date: 6-1
 */
@RestController
@RequestMapping("/api/hotel")
public class HotelController {

    @Autowired
    private HotelService hotelService;
    @Autowired
    private RoomService roomService;
    @Autowired
    private RoomRepoService roomRepoService;


    @PostMapping("/addHotel")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO createHotel(@RequestBody HotelVO hotelVO) throws ServiceException {
        hotelService.addHotel(hotelVO);
        return ResponseVO.buildSuccess(true);
    }

    @GetMapping("/all")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO retrieveAllHotels(){
        return ResponseVO.buildSuccess(hotelService.retrieveHotels());
    }



    @GetMapping("/{hotelId}/detail")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO retrieveHotelDetail(@PathVariable Integer hotelId) {
        return ResponseVO.buildSuccess(hotelService.retrieveHotelDetails(hotelId));
    }

    @PostMapping("/pos/detail")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO retrieveHotelDetailByPosition(@RequestBody PositionVO positionVO) {
        return ResponseVO.buildSuccess(hotelService.retrieveHotelDetailsByPos(positionVO));
    }

    @PostMapping("/update")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO updateHotelBasicInfo(@RequestBody HotelVO hotelVO) throws ServiceException {
        return hotelService.updateHotelBasicInfo(hotelVO);

    }

    @GetMapping("/{userId}/hotelId")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO retrieveHotelIdByUserId(@PathVariable Integer userId) {
        return ResponseVO.buildSuccess(hotelService.retrieveHotelIdByUser(userId));
    }

    @PostMapping("/hotel_search/detail")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO searchHotel(@RequestBody HotelSearchVO searchVO) {
        return ResponseVO.buildSuccess(hotelService.searchHotel(searchVO));
    }


    //管理订单 只能管理 该管理员所属酒店的订单
    // TODO: 遗留问题，需要转移到Order中
    @GetMapping("/{userId}/managedOrders")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO managedOrders(@PathVariable Integer userId){
        return ResponseVO.buildSuccess(hotelService.managedOrders(userId));
    }

    //5.25
    @GetMapping("/{hotelId}/retrieveHotelRoomInfo")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO retrieveHotelRoomInfo(@PathVariable Integer hotelId){
        return ResponseVO.buildSuccess(roomService.retrieveHotelRoomInfo(hotelId));
    }

    @PostMapping("/roomInfo")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO addRoomInfo(@RequestBody HotelRoom hotelRoom) {
        if (roomService.getRoomIsExisted(hotelRoom)) return ResponseVO.buildFailure("该类型房间已存在");
        roomService.insertRoomInfo(hotelRoom);
        return ResponseVO.buildSuccess(true);
    }

    @PostMapping("/roomTypeDetail")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO roomTypeDetail(@RequestBody DatePeriodVO datePeriodVO){

        System.out.println(datePeriodVO);
        return ResponseVO.buildSuccess(roomRepoService.getCompleteInfoOfPeriod(datePeriodVO));


    }

    @PostMapping("/setRoomPriceByRoomId/{roomId}")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO setRoomPriceByRoomId(@PathVariable Integer roomId,@RequestParam double price){
        return roomService.setRoomPriceByRoomId(roomId,price);

    }

    @PostMapping("/uploadImg/{hotelId}")
    public ResponseVO savePic(@RequestParam("file")MultipartFile file,@PathVariable Integer hotelId){
        return hotelService.savePic(file,hotelId);

    }
    @GetMapping("/getImg/{hotelId}")
    public ResponseVO getPic(@PathVariable Integer hotelId){
        return hotelService.getPic(hotelId);
    }


}

