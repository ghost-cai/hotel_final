package com.example.hotel.controller.order;

import com.example.hotel.bl.order.OrderService;
import com.example.hotel.vo.OrderVO;
import com.example.hotel.vo.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: chenyizong,zjy,xzh
 * @Date: 2020-02-29,6-10
 */

@RestController()
@RequestMapping("/api/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/addOrder")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO reserveHotel(@RequestBody OrderVO orderVO){
        return orderService.addOrder(orderVO);
    }

    @GetMapping("/getAllOrders")
    @PreAuthorize("hasPermission('admin','normal')")
    public ResponseVO retrieveAllOrders(){
        return ResponseVO.buildSuccess(orderService.getAllOrders());
    }

    @GetMapping("/{userid}/getUserOrders")
    @PreAuthorize("hasPermission('client','normal')")
    public  ResponseVO retrieveUserOrders(@PathVariable int userid){
        return ResponseVO.buildSuccess(orderService.getUserOrders(userid));
    }
    @GetMapping("/{orderid}/annulOrder")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO annulOrder(@PathVariable int orderid){

        return orderService.annulOrder(orderid);
    }

    @GetMapping("/{hotelId}/allOrders")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO retrieveHotelOrders(@PathVariable Integer hotelId) {
        return ResponseVO.buildSuccess(orderService.getHotelOrders(hotelId));
    }

    //xzh
    //B.v 浏览订单 订单详情
    @GetMapping("/{orderid}/detail")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO getOrderDetail(@PathVariable Integer orderid){
        return ResponseVO.buildSuccess(orderService.getOrderDetail(orderid));
    }

    //xzh
    //B.vi 订单执行chekin
    @GetMapping("/{orderid}/checkin")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO checkInOrder(@PathVariable Integer orderid){
        return orderService.checkInOrder(orderid);
    }

    //xzh
    //B.iv 退房checkout
    @GetMapping("{orderid}/checkout")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO checkOutOrder(@PathVariable Integer orderid){
        return orderService.checkOutOrder(orderid);
    }
    //xzh
    //C.ii.1
    //浏览每日未执行订单情况，当天的
    @GetMapping("{hotelId}/abnormalOrdersOfTheDay")
    @PreAuthorize("hasPermission('htlmgr','normal')")
    public ResponseVO abnormalOrdersOfTheDay(@PathVariable Integer hotelId){
        return orderService.abnormalOrdersOfTheDay(hotelId);
    }


    //xzh
    //C.ii.2
    @PostMapping("{orderId}/appealAbnormalOrder")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO appealAbnormalOrder(@PathVariable Integer orderId){
        return orderService.appealAbnormalOrder(orderId);
    }

    //xzh
    //删除订单
    @PostMapping("{orderId}/deleteOrder")
    @PreAuthorize("hasPermission('client','normal')")
    public ResponseVO deleteOrder(@PathVariable Integer orderId){
        return orderService.deleteOrder(orderId);
    }

}
