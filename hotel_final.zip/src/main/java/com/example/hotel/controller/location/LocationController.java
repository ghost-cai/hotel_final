package com.example.hotel.controller.location;

import com.example.hotel.bl.location.LocationService;
import com.example.hotel.po.Location;
import com.example.hotel.vo.ResponseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * @Author: zjy,xzh
 * @Date: 6-10
 */
@RestController
@RequestMapping("/api/loc")
public class LocationController {

    @Autowired
    LocationService locationService;

    @GetMapping("/all")
    public ResponseVO getAllLocations() {
        return ResponseVO.buildSuccess(locationService.getAllLocations());
    }
}
