package com.example.hotel.config;

import com.example.hotel.bl.security.TokenService;
import com.example.hotel.bl.user.AccountService;
import com.example.hotel.filter.TokenFilter;
import com.example.hotel.po.User;
import com.example.hotel.util.RequestUtils;
import com.example.hotel.util.ResponseUtils;
import com.example.hotel.vo.LoginUser;
import com.example.hotel.vo.ResponseVO;
import com.example.hotel.vo.Token;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;

/**
 * @Author zjy
 * @Date 6-3
 */
@Configuration
public class SecurityHandlerConfig {
    @Autowired
    TokenService tokenService;

    @Autowired
    AccountService accountService;

    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler() {
        return (httpServletRequest, httpServletResponse, authentication) -> {
            // LoginUser
            LoginUser loginUser = (LoginUser) authentication.getPrincipal();
            // Token
            Token token = tokenService.saveToken(loginUser);
            // ResponseJson
            loginUser.setToken(token.getToken());
            ResponseUtils.responseJson(httpServletResponse, HttpStatus.OK.value(), ResponseVO.buildSuccess(loginUser));
            httpServletResponse.setHeader("Access-Control-Allow-Origin", httpServletRequest.getHeader("Origin"));
        };
    }

    @Bean
    public AuthenticationFailureHandler authenticationFailureHandler() {
        return (httpServletRequest, httpServletResponse, e) -> {
            String msg = null;
            httpServletResponse.setHeader("Access-Control-Allow-Origin", httpServletRequest.getHeader("Origin"));
            // 密码错误 SpringSecurity 帮忙做到了
            if (e instanceof BadCredentialsException) {
                msg = "用户名或密码错误";
            } else msg = "服务器内部错误";

            ResponseVO responseVO = ResponseVO.buildFailure(msg);
            ResponseUtils.responseJson(httpServletResponse, HttpStatus.UNAUTHORIZED.value(), responseVO);
        };
    }

    @Bean
    public AuthenticationEntryPoint authenticationEntryPoint() {
        return (httpServletRequest, httpServletResponse, e) -> {
            httpServletResponse.setHeader("Access-Control-Allow-Origin", httpServletRequest.getHeader("Origin"));
            ResponseVO responseVO = ResponseVO.buildFailure("请先登录");
            ResponseUtils.responseJson(httpServletResponse, HttpStatus.UNAUTHORIZED.value(), responseVO);
        };
    }

    @Bean
    public LogoutSuccessHandler logoutSuccessHandler() {
        return (httpServletRequest, httpServletResponse, authentication) -> {
            System.out.println("logout ");
            ResponseVO responseVO = ResponseVO.buildSuccess("退出成功");
            // TODO tokenGetter
            String token = TokenFilter.getToken(httpServletRequest);
            tokenService.deleteToken(token);
            ResponseUtils.responseJson(httpServletResponse, HttpStatus.OK.value(), responseVO);
        };
    }
}
