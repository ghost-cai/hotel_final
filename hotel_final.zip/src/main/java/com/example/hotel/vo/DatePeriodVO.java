package com.example.hotel.vo;

public class DatePeriodVO {
    private String fromDate;
    private String toDate;
    private Integer roomId;
    private Integer valToSet;

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public Integer getRoomId() {
        return roomId;
    }

    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }

    public Integer getValToSet() {
        return valToSet;
    }

    public void setValToSet(Integer valToSet) {
        this.valToSet = valToSet;
    }

    @Override
    public String toString() {
        return "DatePeriodVO{" +
                "fromDate='" + fromDate + '\'' +
                ", toDate='" + toDate + '\'' +
                ", roomId=" + roomId +
                ", valToSet=" + valToSet +
                '}';
    }
}
