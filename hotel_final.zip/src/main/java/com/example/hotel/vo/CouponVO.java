package com.example.hotel.vo;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;

public class CouponVO {
    private Integer id;
    private String description;
    private Integer status;
    private String name;
    private Integer type;
    private boolean hasCouponTime;

//    @JsonFormat(pattern = "yyyy-MM-dd")
    private String startDate;

//    @JsonFormat(pattern = "yyyy-MM-dd")
    private String endDate;
    public boolean isHasCouponTime() {
        return hasCouponTime;
    }

    public void setHasCouponTime(boolean hasCouponTime) {
        this.hasCouponTime = hasCouponTime;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
