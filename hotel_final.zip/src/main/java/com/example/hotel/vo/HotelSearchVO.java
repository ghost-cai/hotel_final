package com.example.hotel.vo;

import java.util.List;

public class HotelSearchVO {
    // TODO: lowerPrice upperPrice
    private String hotelNameKeyWord;
    private List<String> stars;
    private Double lowerRate;
    private Double higherRate;
    private Integer roomDemandCnt;
    private String roomType;
    private String beginDate;
    private String endDate;
    private String bizId;
    private Double lowerPrice;
    private Double upperPrice;
    private Integer userId;
    private Integer ordered;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getOrdered() {
        return ordered;
    }

    public void setOrdered(Integer ordered) {
        this.ordered = ordered;
    }

    public String getHotelNameKeyWord() {
        if (hotelNameKeyWord != null)
            return "%" + hotelNameKeyWord + "%";
        else return null;
    }

    public void setHotelNameKeyWord(String hotelNameKeyWord) {
        this.hotelNameKeyWord = hotelNameKeyWord;
    }

    public List<String> getStars() {
        return stars;
    }

    public void setStars(List<String> stars) {
        this.stars = stars;
    }

    public Double getLowerRate() {
        return lowerRate;
    }

    public void setLowerRate(double lowerRate) {
        this.lowerRate = lowerRate;
    }

    public Double getHigherRate() {
        return higherRate;
    }

    public void setHigherRate(double higherRate) {
        this.higherRate = higherRate;
    }

    public Integer getRoomDemandCnt() {
        return roomDemandCnt;
    }

    public void setRoomDemandCnt(Integer roomDemandCnt) {
        this.roomDemandCnt = roomDemandCnt;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getBizId() {
        return bizId;
    }

    public void setBizId(String bizId) {
        this.bizId = bizId;
    }

    public void setLowerRate(Double lowerRate) {
        this.lowerRate = lowerRate;
    }

    public void setHigherRate(Double higherRate) {
        this.higherRate = higherRate;
    }

    public Double getLowerPrice() {
        return lowerPrice;
    }

    public void setLowerPrice(Double lowerPrice) {
        this.lowerPrice = lowerPrice;
    }

    public Double getUpperPrice() {
        return upperPrice;
    }

    public void setUpperPrice(Double upperPrice) {
        this.upperPrice = upperPrice;
    }

    @Override
    public String toString() {
        return "HotelSearchVO{" +
                "hotelNameKeyWord='" + hotelNameKeyWord + '\'' +
                ", stars=" + stars +
                ", lowerRate=" + lowerRate +
                ", higherRate=" + higherRate +
                ", roomDemandCnt=" + roomDemandCnt +
                ", roomType='" + roomType + '\'' +
                ", beginDate='" + beginDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", bizId='" + bizId + '\'' +
                ", lowerPrice=" + lowerPrice +
                ", upperPrice=" + upperPrice +
                ", userId=" + userId +
                ", ordered=" + ordered +
                '}';
    }
}
