package com.example.hotel.vo;

import com.example.hotel.po.CommentPO;

public class CommentVO {
    private Integer id;
    private String commentDetail;
    private Integer orderId;
    private Double rate;

    public CommentVO() {
    }

    public CommentVO(CommentPO commentPO) {
        this.id = commentPO.getId();
        this.commentDetail = commentPO.getCommentDetail();
        this.orderId = commentPO.getOrderId();
        this.rate = commentPO.getRate();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCommentDetail() {
        return commentDetail;
    }

    public void setCommentDetail(String commentDetail) {
        this.commentDetail = commentDetail;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "CommentVO{" +
                "id=" + id +
                ", commentDetail='" + commentDetail + '\'' +
                ", orderId=" + orderId +
                ", rate=" + rate +
                '}';
    }
}
