package com.example.hotel.vo;

/**
 * 酒店满减金额优惠 eg 满300减100
 */
public class WebAdminMultiRoomCouponVO extends CouponVO {


    private Integer discountMoney;
    private Double discount;

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Integer getDiscountMoney() {
        return discountMoney;
    }

    public void setDiscountMoney(Integer discountMoney) {
        this.discountMoney = discountMoney;
    }

}
