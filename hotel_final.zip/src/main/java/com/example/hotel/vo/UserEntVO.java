package com.example.hotel.vo;

/**
 * {
 *     userVO: {
 *         id: "userId"
 *     },
 *     entVO: {
 *         id: "entId",
 *         inviteCode: "inviteCode"
 *     }
 * }
 */
public class UserEntVO {

    private UserVO userVO;
    private EntVO entVO;

    public UserVO getUserVO() {
        return userVO;
    }

    public void setUserVO(UserVO userVO) {
        this.userVO = userVO;
    }

    public EntVO getEntVO() {
        return entVO;
    }

    public void setEntVO(EntVO entVO) {
        this.entVO = entVO;
    }
}
