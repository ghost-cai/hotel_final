package com.example.hotel.vo;

public class DateRoomRepoVO {
    private String date;
    private int emptyRoomCnt;
    private int nonUsedRoomCnt;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getEmptyRoomCnt() {
        return emptyRoomCnt;
    }

    public void setEmptyRoomCnt(int emptyRoomCnt) {
        this.emptyRoomCnt = emptyRoomCnt;
    }

    public int getNonUsedRoomCnt() {
        return nonUsedRoomCnt;
    }

    public void setNonUsedRoomCnt(int nonUsedRoomCnt) {
        this.nonUsedRoomCnt = nonUsedRoomCnt;
    }
}
