package com.example.hotel.TimerTask;

import com.example.hotel.bl.order.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import java.time.LocalDateTime;
import java.util.Observable;
import java.util.Observer;


/**
 * @Author xzh
 * @Date 5-15
 */
@Configuration      //1.主要用于标记配置类，兼备Component的效果。
@EnableScheduling   // 2.开启定时任务
public class SaticScheduleTask extends Observable {

    @Autowired
    //定时刷新OrderSevice 所有的操作
    public SaticScheduleTask(OrderService orderService) {
        addObserver(orderService);
    }

    //3.添加定时任务
    @Scheduled(cron = "0/1 * * * * ?")//1秒
    //或直接指定时间间隔，例如：5秒
    //@Scheduled(fixedRate=5000)
    private void configureTasks() {
        notifyObservers();
    }

}