package com.example.hotel.bl.comment;

import com.example.hotel.vo.CommentVO;

import java.util.List;

/**
 * @Author: xzh, zjy
 * @Date: 2020-05-13
 */
public interface CommentService {

    /**
     * 增加一条评论
     * @param commentVO 评论信息
     * @return 是否添加成功
     */
    Boolean addComment(CommentVO commentVO);

    /**
     * 根据评论id查询评论信息
     * @param id 评论id
     * @return 评论信息
     */
    CommentVO queryByCommentId(Integer id);

    /**
     * 查询某个酒店的全部评论信息
     * @param id 酒店id
     * @return list 评论信息
     */
    List<CommentVO> queryByHotelId(Integer id);

}
