package com.example.hotel.bl.hotel;

import com.example.hotel.po.RoomTypeDetailVO;
import com.example.hotel.vo.DatePeriodVO;
import com.example.hotel.vo.DateRoomRepoVO;
import com.example.hotel.vo.ResponseVO;
import com.example.hotel.vo.RoomTypeUpdateVO;

import java.util.List;
import java.util.Map;

/**
 * 按日存放、管理房间库存
 *
 * @Author: zjy, xzh
 * @Date: 2020-05-13
 */
public interface RoomRepoService {

    /**
     * 根据时间段获取某房型库存信息
     *
     * @param datePeriodVO
     * @return
     * @deprecated 待修改 可用getForPeriodList代替
     */
    Map<String, Integer> getForPeriod(DatePeriodVO datePeriodVO);

    /**
     * 根据时间段获取某房型库存信息
     *
     * @param datePeriodVO
     * @return list形式
     */
    List<DateRoomRepoVO> getForPeriodList(DatePeriodVO datePeriodVO);

    /**
     * 设置某时间段内某房型库存信息
     *
     * @param datePeriodVO
     * @return
     */
    Boolean setForPeriod(DatePeriodVO datePeriodVO);

    /**
     * 获取某时间段内可供销售的某房型数量（总量）
     * 服务于搜索
     *
     * @return
     */
    Integer getSumOfAvailableNumOfPeriod(Integer hotelId, String fromDate, String endDate);

    /**
     * 获取某时间段内某房型的各自的详细信息
     * 包括已售出数量、库存量
     *
     * @param datePeriodVO
     * @return
     */
    List<RoomTypeDetailVO> getCompleteInfoOfPeriod(DatePeriodVO datePeriodVO);

    /**
     * 设置库存量
     *
     * @param roomTypeUpdateVO
     * @return
     */
    ResponseVO SetAvailableRoomNum(RoomTypeUpdateVO roomTypeUpdateVO);

    /**
     * 获取某天某房型的库存量
     *
     * @param roomId
     * @param date
     * @return
     */
    int getAvailableOfRoomIdAndDate(Integer roomId, String date);

    /**
     * 设置某天某房型的库存量
     *
     * @param roomId
     * @param date
     * @param newValue
     * @return
     */
    int setAvailableOfRoomIdAndDate(Integer roomId, String date, int newValue);

    /**
     * 增加或减少某时间段内的库存
     * 服务于Order
     *
     * @param roomId
     * @param startDateStr
     * @param endDateStr
     * @param offset
     */
    void updateAvailableOfRoomIdAndDates(Integer roomId, String startDateStr, String endDateStr, int offset);
}