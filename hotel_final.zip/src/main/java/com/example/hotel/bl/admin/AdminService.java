package com.example.hotel.bl.admin;
//接口
import com.example.hotel.po.User;
import com.example.hotel.vo.HotelBindingVO;
import com.example.hotel.vo.HotelVO;
import com.example.hotel.vo.ResponseVO;
import com.example.hotel.vo.UserForm;

import java.util.List;

/**
 * @Author: xzh, zjy, TA
 * @Date: 2020-05-13
 */
public interface AdminService {

    /**
     * 添加酒店管理人员账号
     *
     * @param userForm 酒店管理人员账号信息
     * @return responseVO
     */
    ResponseVO addManager(UserForm userForm);

    /**
     * 获得所有酒店管理人员信息
     *
     * @return list
     */
    List<User> getAllManagers();

    /**
     * 获得酒店所有客户信息
     *
     * @return list
     */
    List<User> getAllClients();

    /**
     * 为酒店绑定管理者
     *
     * @param hotelBindingVO 管理者绑定信息
     * @return bool
     */
    boolean bindHotelMgr(HotelBindingVO hotelBindingVO);

    /**
     * 获取某管理员所管理的所有酒店信息
     *
     * @param mgrId 酒店管理员id
     * @return list of hotels
     */
    List<HotelVO> selectManagedBy(Integer mgrId);


}
