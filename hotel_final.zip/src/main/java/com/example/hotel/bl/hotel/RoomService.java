package com.example.hotel.bl.hotel;

import com.example.hotel.po.HotelRoom;
import com.example.hotel.vo.ResponseVO;

import java.util.List;

/**
 * @Author: xzh, zjy
 * @Date: 2020-05-13
 */
public interface RoomService {

    /**
     * 获取某个酒店的全部房间信息
     *
     * @param hotelId
     * @return
     */
    List<HotelRoom> retrieveHotelRoomInfo(Integer hotelId);

    /**
     * 添加酒店客房信息
     *
     * @param hotelRoom
     */
    void insertRoomInfo(HotelRoom hotelRoom);

    /**
     * 预订酒店后更新客房房间数量
     *
     * @param hotelId
     * @param roomType
     * @param rooms
     */
    void updateRoomInfo(Integer hotelId, String roomType, Integer rooms);

    /**
     * 获取酒店指定房间剩余数量
     *
     * @param hotelId
     * @param roomType
     * @return
     */
    int getRoomCurNum(Integer hotelId, String roomType);

    /**
     * 设置房间价格
     *
     * @param roomId
     * @param price
     * @return
     */
    ResponseVO setRoomPriceByRoomId(int roomId, double price);

    /**
     * 根据房间id获取房间信息
     *
     * @param roomId
     * @return
     */
    HotelRoom getRoomById(Integer roomId);

    /**
     * 判定某房间信息是否存在
     * 不允许同酒店有两个或以上同种房间
     *
     * @param hotelRoom
     * @return
     */
    boolean getRoomIsExisted(HotelRoom hotelRoom);

    /**
     * 根据酒店id与房间类型获取房间详细信息
     *
     * @param hotelId
     * @param roomType
     * @return
     */
    HotelRoom selectRoomByHotelIdAndType(Integer hotelId, String roomType);
}
