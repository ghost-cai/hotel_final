package com.example.hotel.bl.hotel;

import com.example.hotel.po.Order;
import com.example.hotel.util.ServiceException;
import com.example.hotel.vo.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @Author: zjy, xzh
 * @Date: 2020-05-13
 */
public interface HotelService {

    /**
     * 添加酒店
     * @param hotelVO
     * @throws
     */
    void addHotel(HotelVO hotelVO) throws ServiceException;


    /**
     * 预订酒店修改剩余客房信息
     * @param hotelId
     * @param roomType
     * @param rooms
     */
    void updateRoomInfo(Integer hotelId, String roomType, Integer rooms);

    /**
     * 列表获取酒店信息
     * @return
     */
    List<HotelWithImgVO> retrieveHotels();

    /**
     * 获取某家酒店详细信息
     * @param hotelId
     * @return
     */
    HotelVO retrieveHotelDetails(Integer hotelId);

    /**
     * 查看酒店剩余某种房间数量
     * zjy
     * @param hotelId
     * @param roomType
     * @return
     */
    int getRoomCurNum(Integer hotelId, String roomType);

    /**
     * 根据酒店地理位置与商圈查找酒店
     * @param positionVO
     * @return
     */
    List<HotelVO> retrieveHotelDetailsByPos(PositionVO positionVO);

    /**
     * 根据用户信息获取已预订的酒店id
     * @return
     */
    List<Integer> retrieveHotelIdByUser(Integer userId);

    /**
     * 更新酒店基本信息
     * @param hotelVO
     * @return
     * @throws ServiceException
     */
    ResponseVO updateHotelBasicInfo(HotelVO hotelVO) throws ServiceException;

    /**
     * 根据搜索信息返回酒店信息
     * @param searchVO
     * @return
     */
    List<HotelWithImgVO> searchHotel(HotelSearchVO searchVO);

    /**
     * 获取某管理员管理的所有订单
     * @param managerId
     * @return
     */
    List<Order> managedOrders(int managerId);

    /**
     * 为酒店添加图片
     * @param file
     * @param hotelId
     * @return
     */
    ResponseVO savePic(MultipartFile file,Integer hotelId);

    /**
     * 获取酒店的图片
     * @param hotelId
     * @return
     */
    ResponseVO getPic(Integer hotelId);

    /**
     * 为酒店绑定管理员
     * @param hotelBindingVO
     * @return
     */
    boolean bindHotelMgr(HotelBindingVO hotelBindingVO);

    /**
     * 获取所有被mgrId对应的管理员管理的酒店
     * @param mgrId
     * @return
     */
    List<HotelVO> selectManagedBy(Integer mgrId);

}
