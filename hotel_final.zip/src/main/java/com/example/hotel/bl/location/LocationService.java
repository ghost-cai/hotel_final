package com.example.hotel.bl.location;

import com.example.hotel.po.Location;

import java.util.List;

/**
 * 提供系统允许的所有位置信息
 * 位置信息在数据库中直接设置，不提供增加/删除/修改位置信息的服务
 *
 * @Author: zjy
 * @Date: 2020-05-20
 */
public interface LocationService {
    /**
     * 获取所有位置信息
     *
     * @return
     */
    List<Location> getAllLocations();
}
