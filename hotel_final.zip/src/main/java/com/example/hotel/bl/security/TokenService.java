package com.example.hotel.bl.security;

import com.example.hotel.vo.LoginUser;
import com.example.hotel.vo.Token;

/**
 * @Author: zjy
 * @Date: 2020-06-20
 */
public interface TokenService {
    /**
     * 用户名密码验证成功后,保存令牌
     *
     * @return Token
     */
    Token saveToken(LoginUser loginUser);

    /**
     * 更新当前用户
     */
    void refresh(LoginUser loginUser);

    /**
     * 根据token获取用户
     *
     * @return 获取到的用户
     */
    LoginUser getLoginUser(String token);

    /**
     * 删除令牌
     *
     * @return 删除成功或失败
     */
    boolean deleteToken(String token);
}
