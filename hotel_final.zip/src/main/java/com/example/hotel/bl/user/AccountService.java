package com.example.hotel.bl.user;

import com.example.hotel.po.User;
import com.example.hotel.vo.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author zjy, xzh
 * @date 2020/05/13
 */
public interface AccountService {

    /**
     * 注册账号
     *
     * @param userVO user信息
     * @return ResponseVO
     */
    ResponseVO registerAccount(UserVO userVO);

    /**
     * 用户登录
     *
     * @param userForm user信息
     * @return 验证后的User信息
     * @deprecated 已经使用SpringSecurity重新实现此功能
     */
    User login(UserForm userForm);

    /**
     * 根据email查询用户
     *
     * @return 用户信息
     */
    User getUserInfo(String email);

    /**
     * 根据id查询用户
     *
     * @return 用户信息
     */
    User getUserInfo(int id);

    /**
     * 更新用户个人信息
     *
     * @return ResponseVO
     */
    ResponseVO updateUserInfo(int id, String password, String username, String phonenumber);

    /**
     * 获取用户信用信息
     *
     * @return 包含有信用信息
     */
    ResponseVO getUserCreditInfo(int id);

    /**
     * 注册企业用户
     *
     * @param userEntVO 用户+企业信息VO
     * @return ResponseVO
     */
    ResponseVO registerEntUser(UserEntVO userEntVO);

    /**
     * 信用充值 xzh
     *
     * @param investedMoney 充值金额为其100倍
     * @return ResponseVO
     */
    public ResponseVO investCredit(int id, double investedMoney);

    /**
     * 检索users
     *
     * @return ResponseVO
     */
    ResponseVO searchUsers(UserVO userVO);

    /**
     * 将某人角色设置为酒店管理员
     *
     * @return ResponseVO
     */
    ResponseVO setAsHtlMgr(Integer id);

    /**
     * 删除某用户
     *
     * @return ResponseVO
     */
    ResponseVO deleteUser(Integer id);

    /**
     * 为用户设置头像
     *
     * @return ResponseVO
     */
    ResponseVO savePic(MultipartFile file, Integer userId);

    /**
     * 获取用户头像
     *
     * @return 包含头像File
     */
    ResponseVO getPic(Integer userId);

    /**
     * 根据id信息获取Email
     * 适用于Security模块
     * 注意：Security模块中所有的username均指用于登录的EMail
     *
     * @return id
     */
    Integer getIdByEmail(String email);

    /**
     * 更新用户的信用值
     *
     * @return 更新后的信用值
     */
    Integer updateAccountCredit(Integer userid, double newCredit);
}
