package com.example.hotel.bl.coupon;

import com.example.hotel.po.Coupon;

import com.example.hotel.vo.OrderVO;

/**
 * @Author: TA
 */
public interface CouponMatchStrategy {

    /**
     * 匹配Order与Coupon
     *
     * @param orderVO
     * @param coupon
     * @return
     */
    boolean isMatch(OrderVO orderVO, Coupon coupon);

}
