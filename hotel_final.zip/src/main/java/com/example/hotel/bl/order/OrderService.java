package com.example.hotel.bl.order;

import com.example.hotel.enums.RoomType;
import com.example.hotel.po.Order;
import com.example.hotel.vo.OrderVO;
import com.example.hotel.vo.ResponseVO;

import java.util.List;
import java.util.Observer;

/**
 * @Author: zjy, xzh
 * @Date: 2020-05-13
 */
public interface OrderService extends Observer {

    /**
     * 预订酒店
     *
     * @param orderVO
     * @return
     */
    ResponseVO addOrder(OrderVO orderVO);

    /**
     * 获得所有订单信息
     *
     * @return
     */
    List<Order> getAllOrders();

    /**
     * 获得指定用户的所有订单信息
     *
     * @param userid
     * @return
     */
    List<Order> getUserOrders(int userid);

    /**
     * 撤销订单
     *
     * @param orderid
     * @return
     */
    ResponseVO annulOrder(int orderid);

    /**
     * 查看酒店的所有订单
     *
     * @param hotelId
     * @return
     */
    List<Order> getHotelOrders(Integer hotelId);


    /**
     * 浏览订单
     * 未用VO
     *
     * @param orderid
     * @return
     */
    Order getOrderDetail(Integer orderid);


    /**
     * 订单执行
     *
     * @param orderid
     * @return
     */
    ResponseVO checkInOrder(int orderid);

    /**
     * 查看一个订单是否异常
     *
     * @param orderid
     */
    void checkAndUpdateStateOneOrder(int orderid);

    /**
     * 看所有订单是否异常
     */
    void checkAndUpdateState();

    /**
     * 退房
     *
     * @param orderid
     * @return
     */
    ResponseVO checkOutOrder(int orderid);


    /**
     * 一个订单是否需要自动强制退房
     *
     * @param orderid
     */
    void checkIfForceCheckOutOne(int orderid);

    /**
     * 检查订单需要自动强制退房的情况
     */
    void checkIfForceCheckOut();

    /**
     * 浏览每日异常订单情况
     *
     * @param hotelId
     * @return
     */
    ResponseVO abnormalOrdersOfTheDay(int hotelId);

    /**
     * 获取某管理员管理的所有订单
     *
     * @param managerId
     * @return
     */
    List<Order> managedOrders(int managerId);

    /**
     * 线下申诉订单
     *
     * @param orderId
     * @return
     */
    ResponseVO appealAbnormalOrder(int orderId);

    /**
     * 删除某订单信息
     *
     * @param orderId
     * @return 删除是否成功
     */
    ResponseVO deleteOrder(int orderId);

    /**
     * 根据userid，获取其预定过的所有酒店的id
     * 用于酒店搜索中
     *
     * @param userId
     * @return
     */
    List<Integer> getOrderedHotels(int userId);

    /**
     * 获取某个房间某天的已预订数目
     *
     * @param roomType
     * @param date
     * @param hotelId
     * @return
     */
    Integer getOrderedNumOfThisRoomType(RoomType roomType, String date, Integer hotelId);

    /**
     * 根据酒店ID获得该酒店的订单
     *
     * @param hotelId
     * @return
     */
    List<Order> getOrdersByHotelId(Integer hotelId);

}
