package com.example.hotel.util;
//工具
import javax.servlet.http.HttpServletRequest;

public class RequestUtils {
    public static String getHeader(HttpServletRequest request, String key) {
        return request.getHeader(key);
    }
}
