package com.example.hotel.bl.comment;

import com.example.hotel.data.comment.CommentMapper;
import com.example.hotel.po.CommentPO;
import com.example.hotel.vo.CommentVO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest
class CommentServiceTest {

    @Autowired
    CommentService commentService;

    @MockBean
    CommentMapper commentMapper;

    @Test
    void addComment() {
        Integer orderId = 15;
        CommentVO commentVO = new CommentVO();
        commentVO.setOrderId(orderId);
        commentVO.setCommentDetail("Very Good");
        commentVO.setRate(4.9);

        Mockito.when(commentMapper.addComment(new CommentPO(commentVO)))
                .thenReturn(1);

        assertTrue(commentService.addComment(commentVO));
    }


    @Test
    void queryByHotelId() {
        Integer orderid = 15;
        CommentPO commentPO = new CommentPO();
        commentPO.setOrderId(orderid);
        commentPO.setRate(4.9);
        commentPO.setCommentDetail("Very Good");
        commentPO.setId(1);

        Mockito.when(commentMapper.queryByHotelId(1))
                .thenReturn(Collections.singletonList(commentPO));

        Mockito.when(commentMapper.queryByHotelId(2))
                .thenReturn(Collections.emptyList());

        List<CommentVO> result = commentService.queryByHotelId(1);
        Assertions.assertThat(result.size()).isEqualTo(1);
        Assertions.assertThat(result.get(0).getCommentDetail()).isEqualTo("Very Good");

        result = commentService.queryByHotelId(2);
        Assertions.assertThat(result.size()).isEqualTo(0);
    }
}