package com.example.hotel.bl.user;

import com.example.hotel.data.user.AccountMapper;
import com.example.hotel.enums.UserType;
import com.example.hotel.po.User;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
class AccountServiceTest {

    @Autowired
    AccountMapper accountMapper;
    @Autowired
    AccountService accountService;
    @Test
    void investCredit() {
        //给123@qq.com充值十块钱
        int userId = 5;
        int investedMoney = 10;

        User user = accountMapper.getAccountById(userId);
        double originalCredit = user.getCredit();
        double added = investedMoney*100;
        double newCredit =added+originalCredit;
        //充值
        accountService.investCredit(userId,investedMoney);
        double retrievedCredit = accountMapper.getAccountById(userId).getCredit();
        //assert
        assertEquals(newCredit,retrievedCredit);

    }

    @Test
    void setAsHtlMgr() {
        //将Client设置为酒店管理员
        int userId= 8;
        User user = accountMapper.getAccountById(8);
        assertEquals(UserType.Client,user.getUserType());

        accountService.setAsHtlMgr(userId);
        assertEquals(UserType.HotelManager,accountMapper.getAccountById(userId).getUserType());
    }


}