package com.example.hotel.bl.coupon;

import com.example.hotel.data.coupon.CouponMapper;
import com.example.hotel.po.Coupon;
import com.example.hotel.po.Order;
import com.example.hotel.vo.OrderVO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

import java.util.Collections;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
class CouponServiceTest {

    @Autowired
    CouponService couponService;

    @MockBean
    CouponMapper couponMapper;

    @Test
    void getMatchOrderCoupon() {
        OrderVO orderVO = new OrderVO();
        orderVO.setHotelId(1);
        orderVO.setRoomNum(4);
        orderVO.setPrice(1000.0);
        orderVO.setCheckInDate("2020-05-02");
        orderVO.setCheckOutDate("2020-05-03");

        // 测试满减优惠
        Coupon coupon = new Coupon();
        coupon.setDescription("NEW COUPON");
        coupon.setHotelId(1);
        coupon.setCouponType(3);
        coupon.setTargetMoney(500);
        coupon.setDiscountMoney(100);
        coupon.setId(1);

        Mockito.when(couponMapper.selectByHotelId(1))
                .thenReturn(Collections.singletonList(coupon));

        List<Coupon> matchOrderCoupons = couponService.getMatchOrderCoupon(orderVO);
        Assertions.assertThat(matchOrderCoupons.get(0).getDescription())
                .isEqualTo("NEW COUPON");

    }


}