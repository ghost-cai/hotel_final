package com.example.hotel.bl.order;

import com.example.hotel.data.order.OrderMapper;
import com.example.hotel.po.Order;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.jupiter.api.Assertions.*;
@RunWith(SpringRunner.class)
@SpringBootTest
class OrderServiceTest {
    @Autowired
    OrderService orderService;
    @Autowired
    OrderMapper orderMapper;

    @Test
    void checkInOrder() {
        int orderid=14;
        //之前先设置已预订
        orderService.checkInOrder(orderid);
        Order order = orderMapper.getOrderById(orderid);
        assertEquals(order.getOrderState(),"已执行");
    }
    //OrderServiceTest
    @Test
    void CheckInOrder2() {
        int orderid=15;
        //之前先设置已预订
        orderService.checkInOrder(orderid);
        Order order = orderMapper.getOrderById(orderid);
        assertNotEquals(order.getOrderState(),"已执行");
    }


    @Test
    void annulOrder() {
        int orderId = 39;
        //之前设置已预订
        orderService.annulOrder(orderId);
        Order order = orderMapper.getOrderById(orderId);
        assertEquals(order.getOrderState(),"已取消");
    }


    @Test
    void checkOutOrder() {
        int orderId=40;
        //之前设置已执行
        orderService.checkOutOrder(orderId);
        Order order= orderMapper.getOrderById(orderId);
        assertEquals(order.getOrderState(),"已退房");
    }
    @Test
    void checkOutOrder2() {
        int orderId=39;
        //之前设置非 已执行
        orderService.checkOutOrder(orderId);
        Order order= orderMapper.getOrderById(orderId);
        assertNotEquals(order.getOrderState(),"已退房");
    }
}