package com.example.hotel.controller.coupon;

import com.example.hotel.data.coupon.CouponMapper;
import com.example.hotel.po.Coupon;
import com.example.hotel.vo.ResponseVO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
class CouponControllerTest {

    @Autowired
    CouponController couponController;

    @MockBean
    CouponMapper couponMapper;

    private Integer hotelId = 1;

    @Test
    void getOrderMatchCoupons() {

        // 满五百减一百
        Coupon couponTarget = new Coupon();
        couponTarget.setHotelId(hotelId);
        couponTarget.setId(1);
        couponTarget.setCouponType(3);
        couponTarget.setTargetMoney(500);
        couponTarget.setDiscountMoney(100);
        couponTarget.setDescription("满500减100");

        Mockito.when(couponMapper.selectByHotelId(hotelId))
                .thenReturn(Collections.singletonList(couponTarget));

        ResponseVO orderMatchCoupons = couponController
                .getOrderMatchCoupons(1, hotelId,
                1000.0, 1, "2020-07-01", "2020-07-02");

        Assertions.assertThat(orderMatchCoupons.getSuccess()).isTrue();

        Coupon resCoupon = ((List<Coupon>) orderMatchCoupons.getContent()).get(0);
        Assertions.assertThat(resCoupon.getDescription()).isEqualTo("满500减100");

    }
}