package com.example.hotel.controller.hotel;

import com.example.hotel.data.hotel.RoomRepoMapper;
import com.example.hotel.po.RoomRepoPO;
import com.example.hotel.vo.DatePeriodVO;
import com.example.hotel.vo.DateRoomRepoVO;
import com.example.hotel.vo.ResponseVO;
import com.example.hotel.vo.RoomTypeUpdateVO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@RunWith(SpringRunner.class)
@SpringBootTest
@AutoConfigureMockMvc
class RoomRepoControllerTest {

    @MockBean
    RoomRepoMapper roomRepoMapper;

    @Autowired
    private RoomRepoController roomRepoController;

    @Autowired
    private MockMvc mockMvc;

    String fromDate = "2020-07-01";
    String toDate = "2020-07-02";
    Integer roomId = 1;


    // /api/roomRepo/getCurrPeriodRepo
    @Test
    void getCurrRepo() throws Exception {
        RoomRepoPO roomRepoPO1 = new RoomRepoPO();
        roomRepoPO1.setCurrentNum(10);
        roomRepoPO1.setRoomId(roomId);
        roomRepoPO1.setDate(fromDate);
        Mockito.when(roomRepoMapper.searchRoom(roomRepoPO1))
                .thenReturn(Collections.singletonList(roomRepoPO1));

        RoomRepoPO roomRepoPO2 = new RoomRepoPO();
        roomRepoPO2.setCurrentNum(10);
        roomRepoPO2.setRoomId(roomId);
        roomRepoPO2.setDate(toDate);
        Mockito.when(roomRepoMapper.searchRoom(roomRepoPO2))
                .thenReturn(Collections.singletonList(roomRepoPO2));

        DatePeriodVO datePeriodVO = new DatePeriodVO();
        datePeriodVO.setFromDate(fromDate);
        datePeriodVO.setToDate(toDate);
        datePeriodVO.setRoomId(roomId);

        // 由于SpringSecurity原因，只好直接调用Controller方法
//        mockMvc.perform(MockMvcRequestBuilders.post("/api/roomRepo/getCurrPeriodRepo")
//                .contentType(MediaType.APPLICATION_JSON)
//                .content("{\"fromDate\": \""+ fromDate +
//                        "\", \"toDate\": \""+toDate+
//                        "\", \"roomId\": \""+ roomId+"\"}"))
//                .andExpect(MockMvcResultMatchers.status().isOk());

        ResponseVO resp = roomRepoController.getCurrRepo(datePeriodVO);
        Assertions.assertThat(resp.getContent()).isNotNull();
        List<DateRoomRepoVO> dateRoomRepoVOS = (List<DateRoomRepoVO>) resp.getContent();
        Assertions.assertThat(dateRoomRepoVOS.get(0).getEmptyRoomCnt()).isEqualTo(10);
        Assertions.assertThat(dateRoomRepoVOS.get(1).getEmptyRoomCnt()).isEqualTo(10);

    }

    @Test
    void setAvailableNumOfThisRoomType() {
        RoomRepoPO roomRepoPO1 = new RoomRepoPO();
        roomRepoPO1.setCurrentNum(10);
        roomRepoPO1.setRoomId(roomId);
        roomRepoPO1.setDate(fromDate);
        Mockito.when(roomRepoMapper.setRoomOfDate(roomRepoPO1))
                .thenReturn(1);

        RoomRepoPO roomRepoPO2 = new RoomRepoPO();
        roomRepoPO2.setCurrentNum(10);
        roomRepoPO2.setRoomId(roomId);
        roomRepoPO2.setDate(toDate);
        Mockito.when(roomRepoMapper.setRoomOfDate(roomRepoPO2))
                .thenReturn(1);

        RoomTypeUpdateVO roomTypeUpdateVO = new RoomTypeUpdateVO();
        roomTypeUpdateVO.setDate(fromDate);
        roomTypeUpdateVO.setNewValue(100);
        roomTypeUpdateVO.setRoomId(roomId);
        ResponseVO responseVO = roomRepoController.SetAvailableNumOfThisRoomType(roomTypeUpdateVO);

        Assertions.assertThat(responseVO.getSuccess()).isTrue();
    }
}