create database hotel;
use hotel;
-- MySQL dump 10.13  Distrib 5.7.30, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: hotel
-- ------------------------------------------------------
-- Server version	5.7.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `belongstoent`
--

DROP TABLE IF EXISTS `belongstoent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `belongstoent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `entId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `belongsToEnt_ent_id_fk` (`entId`),
  KEY `belongsToEnt_user_id_fk` (`userId`),
  CONSTRAINT `belongsToEnt_ent_id_fk` FOREIGN KEY (`entId`) REFERENCES `enterprise` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `belongsToEnt_user_id_fk` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `belongstoent`
--

LOCK TABLES `belongstoent` WRITE;
/*!40000 ALTER TABLE `belongstoent` DISABLE KEYS */;
INSERT INTO `belongstoent` VALUES (1,5,1);
/*!40000 ALTER TABLE `belongstoent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bizregion`
--

DROP TABLE IF EXISTS `bizregion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bizregion` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bizRegion_city_id_fk` (`city_id`),
  CONSTRAINT `bizRegion_city_id_fk` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bizregion`
--

LOCK TABLES `bizregion` WRITE;
/*!40000 ALTER TABLE `bizregion` DISABLE KEYS */;
INSERT INTO `bizregion` VALUES ('js_nj_fuzimiao','Fuzimiao','js_nanjing'),('js_nj_xianlin','Xianlin','js_nanjing'),('js_nj_xinjiekou','Xinjiekou','js_nanjing'),('js_sz_guanjianqie','Guanqianjie','js_suzhou'),('zj_hz_xihu','Xihu','zj_hangzhou');
/*!40000 ALTER TABLE `bizregion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `city_province_id_fk` (`province_id`),
  CONSTRAINT `city_province_id_fk` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES ('js_nanjing','Nanjing','jiangsu'),('js_suzhou','Suzhou','jiangsu'),('zj_hangzhou','Hangzhou','zhejiang');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `rate` double NOT NULL,
  `commentDetail` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Comment_order_id_fk` (`orderId`),
  CONSTRAINT `Comment_order_id_fk` FOREIGN KEY (`orderId`) REFERENCES `orderlist` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,14,4.85,'fuck'),(2,15,4.85,'fuck'),(3,16,4.85,'fuck'),(4,49,5,'默认好评'),(5,49,5,'默认好评'),(6,49,5,'默认好评'),(7,52,4.5,'酒店位置在新街口闹市区，周边交通便利，入住舒适，前台小姐姐热情服务，点餐快捷方便，第一次到南京，非常满意。'),(8,52,5,'我很认床，但是这家酒店的床很舒服，还能提供多款枕头非常贴心，每次住这家酒店都睡的特别好。早餐也很丰盛，位置处在市中心，交通非常便利，房间隔音效果也很好，很安静！'),(9,52,5,'这次真的超级棒的体验、前台小姐姐给了免费的升级、还贴心给了暖胃的茶、酒店出门就是新百和中央商场、去哪里都超级方便，走路都可以、床垫超级软！性价比可以说超级无敌高！不要犹豫！选他！'),(10,52,4.5,'视野很好，看夜景很棒！地理位置也非常非常方便，吃完饭散会步到酒店休息正正好。美中不足是浴室大花洒有个孔一直滴水。'),(11,52,3,'住了三次，这次态度最不好，以前从没交过押金，非说我们家一直都是交押金的。交不交没关系，但是你这态度着实不敢恭维，同样的房间也比之前小很多。。。。排除地段，以后应该不会住了。'),(12,52,4.5,'疫情后第一个假期，虽说没有全部开放，住酒店有点忐忑，但酒店的服务给了我们安心。位置很好，就在新街口苏宁广场的街口，停车很方便，酒店前台服务很棒，安康码，停车码，手续虽慢了点，但品质不降低。房间大小适中，双床房，床宽1.1米，很是柔软，没有给到能看到街景的很是遗憾。'),(13,55,5,'我们是医务人员，享受好政策，带孩子和同事一起玩，去了方特后，来南京吃小吃，一进大堂，非常漂亮，刷房卡入住，前台很贴心，因为修路，酒店地下停车场不好找，看我们找地方不容易还免费帮我们升级2间高级状元主题房，送小盆友礼物，晚上还有睡前牛奶和水果'),(14,56,3.5,'酒店位置很好，但是时间太长了。有一股味道，楼道比较闷。性价比不高，五星级的价格，三星的品质，除了位置好，其他和同等五星级没法比！！！博物院边上那家五星级维景还不错哦，前身是希尔顿酒店！'),(15,56,4.5,'位置一流，古色古香！到夫子庙所有景点步行距离完美！陪伴老人孩子游览的不二选择！服务态度非常好，迎来送往热情有礼！下次还会选择这里！'),(16,55,4.5,'地理位置很好，出门拐弯就是步行街，很方便。服务很热情，前台美女很温柔也很效率，晚上秦淮河步行只要5分钟，回来还有意外惊喜送了份水果，房间也很有特色，还可以自己用毛笔写，最重要是免费的！ 一进门还有测温，前台也有免洗消毒液、酒精，感觉防疫做的很到位，入住也很放心，下次还来住\n'),(17,56,5,'酒店很不错，设施齐全，古色古香。服务更是没得说，最主要的是地理位置无敌，出门就是夫子庙，到南京旅游首选！'),(18,56,5,'酒店服务好，位置好，交通方便，前台服务人员耐心介绍博物院，中山陵预约流程，夫子庙里景区离酒店很近，非常方便，早餐口味好，'),(19,56,5,'整体还好，就在夫子庙入口处，虽然人员客流很多，但是房间内还是比较安静，房间整洁，门童略显培训不足，不过不影响整体感受'),(20,54,5,'来南京办事，因为这家酒店离办事点最近所以选了它，看了网上评论住之前心里还比较忐忑，但从住进来开始到离开都让人感觉很棒，差点被网评误导。所以我一定要点赞。首先地理位置绝佳，楼下地铁可以到南京任何一处，酒店在市中心，吃喝玩乐应有尽有，非常方便。入住酒店停车免费。性价比也高。进房间后，我特意检查了卫生情况，很好！'),(21,54,4.5,'出行唯一重复住的宾馆，位置实在是太好。对于一个只有半天逛吃逛喝的人来说，实在是不二选择。楼下就是中央新百莱迪，高中低档商场都有。各色小吃一应俱全。再说酒店，前台做事灵活，免费升级豪华大床房45层，泡了个澡看夜景，透过落地窗，整个南京城尽收眼底，夜太美！床品值得赞，干净、舒服。 稍稍欠缺的就是早餐逊色一点，品种少，上菜不及时，但也够吃了。总体满意，去南京首选。'),(22,54,4.5,'酒店的地理位置很好，在市中心，特别是晚上的夜景特别好看。从地铁里面出来，很快就到酒店了。周围好几个大商场，逛街也方便。还能免费要吃退房到下午两点，退房以后行李就寄存在前台了。出去玩到了晚上吃完饭才回来拿的行李。'),(23,54,4.5,'超级棒??的入住感觉，每次去南京都会选择这个酒店，体验不一样装修风格的房间，值得推荐'),(24,54,4.5,'酒店位置极佳，下楼就是新街口步行街，商场任意逛，下面就是地铁站，去哪都方便。房间挺大的，全景落地窗视野极佳，南京城风光尽收眼底。');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon`
--

DROP TABLE IF EXISTS `coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `hotelId` int(11) DEFAULT '-1',
  `couponType` int(11) NOT NULL,
  `couponName` varchar(255) NOT NULL,
  `target_money` int(11) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `discount_money` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon`
--

LOCK TABLES `coupon` WRITE;
/*!40000 ALTER TABLE `coupon` DISABLE KEYS */;
INSERT INTO `coupon` VALUES (2,'满500-100优惠',1,3,'满减优惠券',500,0,1,NULL,NULL,100),(15,'限时',1,4,'xzh',133,0,1,'2020-05-28 00:00:00','2020-06-02 00:00:00',23),(16,'1000-100优惠',-1,3,'100',1000,0,1,NULL,NULL,100);
/*!40000 ALTER TABLE `coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creditinfo`
--

DROP TABLE IF EXISTS `creditinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creditinfo` (
  `mut_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_val` double(255,0) NOT NULL,
  `after_change` double(255,0) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`mut_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creditinfo`
--

LOCK TABLES `creditinfo` WRITE;
/*!40000 ALTER TABLE `creditinfo` DISABLE KEYS */;
INSERT INTO `creditinfo` VALUES (4,'2020-06-23',0,'AddFrc',1000,9000,8),(5,'2020-06-23',14,'OrderExec',398,498,4),(6,'2020-06-23',0,'AddFrc',1000,23798,5),(7,'2020-06-24',38,'OrderErr',-198,23600,5),(8,'2020-06-25',43,'OrderErr',-594,-494,11),(9,'2020-06-25',44,'OrderErr',-594,-1088,11),(10,'2020-06-25',45,'OrderErr',-594,-1682,11),(11,'2020-06-25',46,'OrderErr',-594,-2276,11),(12,'2020-06-25',47,'OrderErr',-594,-2870,11),(13,'2020-06-25',48,'OrderErr',-594,-3464,11),(14,'2020-07-01',49,'OrderExec',396,23996,5),(15,'2020-07-01',41,'OrderExec',198,24194,5),(16,'2020-07-01',42,'OrderExec',594,24788,5),(17,'2020-07-01',50,'OrderExec',396,25184,5),(18,'2020-07-01',51,'OrderExec',198,25382,5),(19,'2020-07-01',52,'OrderExec',450,25832,5),(20,'2020-07-01',54,'OrderExec',500,26332,5),(21,'2020-07-01',55,'OrderExec',555,26887,5),(22,'2020-07-01',56,'OrderExec',555,27442,5),(23,'2020-07-01',57,'OrderExec',650,28092,5),(24,'2020-07-01',58,'OrderExec',700,28792,5),(25,'2020-06-27',58,'OrderExec',700,29492,5);
/*!40000 ALTER TABLE `creditinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enterprise`
--

DROP TABLE IF EXISTS `enterprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enterprise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inviteCode` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enterprise`
--

LOCK TABLES `enterprise` WRITE;
/*!40000 ALTER TABLE `enterprise` DISABLE KEYS */;
INSERT INTO `enterprise` VALUES (1,'NJU','nju2020');
/*!40000 ALTER TABLE `enterprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotelName` varchar(255) NOT NULL,
  `hotelDescription` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `bizRegion` varchar(255) DEFAULT NULL,
  `hotelStar` varchar(255) DEFAULT NULL,
  `phoneNum` int(11) DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `biz_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
INSERT INTO `hotel` VALUES (1,'汉庭（南京夫子庙中华门店）','经济型酒店，酒店可提供基础的设施及服务，升级了所有的软硬件设施设备，给您一个更加舒适住宿环境','钓鱼台路95号（地铁一号线三山街站4号出口南）','fuzimiao','Four',86906080,4.4,7,'js_nj_fuzhimiao'),(2,'如家商旅酒店（南京夫子庙地铁店）','高档型 高档型酒店，酒店布置典雅，可提供优良的服务，距夫子庙直线300米','平江府路18号中天商厦 夫子庙','fuzimiao','Four',82227000,4.8,7,'js_nj_fuzhimiao'),(4,'7天优品·南京新街口地铁站店','分店位于南京市秦淮区洪武路38号正洪大厦一楼（金陵工人影院对面），地处知名的新街口步行街中心广场上；中央商场、新百百货、大洋百货、时尚莱迪、金鹰国际购物中心、德基广场等大型购物中心近在咫尺，近夫子庙、中山陵、玄武湖等知名旅游景区，车程约10分钟；距离南京奥体中心、国际博览中心地铁15分钟；周边分布南京大学、东南大学、南京航空航天大学、省中医院、南京妇幼保健医院、军区总院等知名学府及省内重点医院；','秦淮区洪武路38号时尚莱迪·正洪大厦8楼（天丰大酒店停车场内，近新街口地铁站12号/24号出口）','xinjiekou','Four',1333321787,4,6,'js_nj_xinjiekou'),(5,'7天酒店·南京夫子庙地铁站景区店','★5A级景区夫子庙推荐入住酒店★，地铁3号线夫子庙站3号出口过马路直行300米右转到到大石坝街 ,看到白鹭宾馆向西20米。步行至南京市中医院和南京市领先人民医院仅需5分钟。位于 国家5A级景区夫子庙中心文源桥畔,独栋仿明清建筑.徒步可游览夫子庙,江南贡院,乌衣巷,白鹭洲等.打车起步价可达新街口。','秦淮区大石坝街37-45号（近地铁3号线夫子庙站2号出口、夫子庙）','fuzimiao','Three',52269699,4,7,'js_nj_fuzhimiao'),(6,'如家酒店(南京新街口中心店)','如家酒店（南京新街口中心店）地处全国闻名的新街口商业圈内，中央商场正对面，紧邻中山陵、夫子庙等著名的风景区，在中山南路和石鼓路两大主干道交界处，交通十分便利。','秦淮区淮海路36号金淮海商务中心3楼（南京银行旁，近地铁1号线、2号线新街口站14号出口）','xinjiekou','Three',84340101,4,6,'js_nj_xinjiekou'),(7,'布丁酒店(南京夫子庙集庆门店)','布丁酒店（南京夫子庙集庆门店）位于秦淮区来凤街2号，毗邻新街口商业金融中心、夫子庙景区（步行约15分钟）。公交乘坐19、81、75、301、35、313到集庆门站，下车5分钟即可到达酒店。','秦淮区双塘街道来凤街2号（集庆路与来凤街交叉口，近1号线三山街地铁站4号出口）','fuzimiao','Three',86598585,4,7,'js_nj_fuzhimiao'),(8,'南京新街口苏宁诺富特酒店','【休闲度假】这里的行政酒廊可俯瞰新街口华灯初上的璀璨美景；高贵典雅的中西餐厅，提供多种美食。 【亲子酒店】酒店提供儿童乐园，您可以跟孩子们在这里体验亲子之乐。 【购物便捷】酒店地处南京淮海路，邻近东方商城和大洋百货两处大型综合商场，吃喝玩乐一应俱全！','秦淮区新街口淮海路68号（苏宁电器旁，近1号线新街口地铁站）','xinjiekou','Five',58798888,5,6,'js_nj_xinjiekou'),(9,'轻住·双子星酒店(新街口华侨路店)','2019年装修2019年开业\n酒店依托南京双子酒店管理有限公司，坐落于江苏省会、副省级市、南京都市圈核心-新街口。是我国特色社会主义社会发展，改革开放成果的重要展现。 酒店成立之初就以“一座城，一个人，一个家”为开店之本，把五心（诚心，耐心，爱心，真心，恒心）当做服务理念，用亲民的价格的迎四方客。','鼓楼区华侨路52号（南京市房产档案馆旁，距上海路地铁站500米）','xinjiekou','Three',189941103,4.3,6,'js_nj_xinjiekou'),(10,'南京商茂国际酒店','酒店位于南京市新街口繁华地段，座落于地标建筑——218米高的商茂世纪广场的楼内，“坐拥金陵形胜地，俯瞰美景仰摘星”是酒店的写照。酒店拥有各类风格迥异、舒适的豪华型的客/套房，极目远眺，紫金山、玄武湖等南京胜景尽收眼底。','秦淮区中山南路49号商茂世纪广场43楼（近淮海路，1号线新街口地铁站13号出口处）','xinjiekou','Five',86898989,4.9,6,'js_nj_xinjiekou'),(11,'南京金丝利喜来登酒店','南京金丝利喜来登酒店位于南京金融商贸中心，周边餐饮、休闲、娱乐场所齐全距；离地铁汉中门近在咫尺，乘地铁即可直达南京火车站和南京火车南站。 　　酒店拥有三百余间具有专业标准的现代客房，无处不体现舒适豪华。38-40层33间全新升级装修的贵宾楼客房兼具时尚科技元素与便捷实用功能，拥有气势非凡的独特视角','秦淮区汉中路169号（近牌楼巷、省中医院）','xinjiekou','Five',86668888,4.8,6,'js_nj_xinjiekou'),(12,'如家商旅酒店(南京新街口地铁站店)','如家商旅（金标）（南京新街口地铁站店）位于南京繁华的商业中心—新街口，距离地铁一号线、二号线新街口站14号出口300米，江苏文化大厦旁。 　　 酒店是首旅如家集团旗下中高端品牌，定位于有品位的商务酒店，打造实用高效、自然纯洁的欧洲现代主义设计风格和生活理念，彰显全感官品质和内敛的商旅气息。 酒店传承中高端酒店服务理念，提供超50种餐品的自助早餐，中西合璧，设有商务会客及休闲区域，并备有自助洗衣房、停车场，让酒店成为城市中的绿洲，旅途中的家。','秦淮区新街口羊皮巷24号（中山南路与羊皮巷交叉口东北50米）','xinjiekou','Four',85899922,4.5,6,'js_nj_xinjiekou'),(13,'布丁酒店(南京新街口省中医院上海路地铁站店)','（本店不接待外宾）布丁酒店（南京省中医院上海路地铁站店）位于秦淮区莫愁路357号（近莫愁路与侯家桥交界处），地位置优越，步行15分钟即可到达新街口商业金融中心；距离地铁二号线上海路站3号出口600米，步行2分钟即可到公交站“莫愁路”，4路直达夫子庙景区，9路可到总统府及中山陵风景区，48路直达莫愁湖公园；','秦淮区莫愁路357号（近妇幼保健医院、省中医院）','xinjiekou','Three',86662758,4,6,'js_nj_xinjiekou'),(14,'南京金陵状元楼大酒店','状元驿站（原状元楼酒店A座）位于中国古城南京著名的秦淮风光带中心区域——夫子庙，是游览夫子庙地区古迹、园林、画舫和民俗、夜市、灯会以及品尝秦淮风味小吃的优选。周边地铁站和公交站点遍布，地理位置优越，交通极其便利。酒店拥有标准双人房、大床房、套房等多种房型，配备24小时的热水淋浴，空调、电视、电话、免费宽带上网等设施一应俱全，是商务客人及休闲旅游客人下榻的理想之选。','秦淮区状元境9号（近夫子庙北门）','fuzimiao','Five',52202555,4.9,7,'js_nj_fuzimiao'),(15,'如家酒店·neo(南京夫子庙店)','2018年装修2008年开业，作为行业标杆企业，如家快捷酒店正用实际行动引领着中国大众住宿业市场走向成熟和完善。','秦淮区建康路状元境41号（夫子庙地铁站3号出口西200米，状元楼隔壁）','fuzimiao','Three',52300009,4.3,7,'js_nj_fuzhimiao'),(16,'如家酒店(南京新街口地铁站天空之都店)',' 酒店位于新街口商业区内户部街与洪武路交界处，毗邻万达广场，周围多条公交直达夫子庙，中山陵，总统府，1912街区；邻近地铁1、2、3号线，可快速到达南京火车站，南京南站，长途汽车站。酒店周边餐饮娱乐一应俱全，各类购物休闲商务场所云集。','秦淮区户部街33号天之都大厦','xinjiekou','Three',85696868,4.1,6,'js_nj_xinjiekou'),(17,'轻住酒店·潘多拉优选(仙林大学城店)','【酒店简介】宾馆是一家现代时尚型酒店，装修风格清新优雅，丰富的房型满足您不同的入住需求。酒店位于仙林大学城尚东花园商业街内，西侧为南京外国语学校仙林分校东校区，环境优美，交通便利。周边有金鹰、中影国际影城等休闲、餐饮、娱乐配套场所，是您商务出行，情侣约会的优质之选。','栖霞区仙林大道尚东商业街118号（近地铁2号线仙林中心站1号口）','xianlin','Three',69089228,3.8,8,'js_nj_xianlin'),(18,'全季酒店(南京徐庄软件园店)','全季南京徐庄软件园店位于徐庄软件园2期聚慧园5号楼，玄武大道108号，距离苏宁总部和南京师范大学仙林校区均只需10分钟车程；距离仙林中心5.5公里，只需15分钟车程；周边交通便利，风景优美，全季酒店坚持质朴与本真的设计理念，为您提供东方风格的优雅住宿环境，是您商务洽谈、休闲旅行、接待亲友的理想场所。','玄武区玄武大道108号聚慧园5号楼1层','xianlin','Four',52208333,4.3,8,'js_nj_xianlin'),(19,'南京玄武苏宁诺富特酒店','南京玄武苏宁诺富特酒店毗邻“金陵毓秀”的紫金山风景区，紧邻苏宁总部及时尚生活广场，是一座兼并深厚文化底蕴和现代科技感的高端商务酒店，酒店四周交通网发达，能够快速对接市中心繁华生活，归依自然而不摒弃繁华。','玄武区苏宁大道9号（近地铁4号线徐庄苏宁总部站6、7号出口）','xianlin','Five',85208888,4.7,8,'js_nj_xianlin'),(20,'尚客优快捷酒店(苏州观前因果巷店)','酒店坐落于市中心观前街商业区内，酒店秉承尚客优连锁三大统一性：统一建筑风格、统一硬件设施、统一服务标准。酒店拥有大床房、家庭房房、风情房等多种房型。提供24小时热水冲淋、冷暖空调、液晶电视、电话和互联网，人体工程学设计的席梦思床具、舒适的环境，将是您愉快的商旅之选。','姑苏区因果巷12号（集美厨具旁）','guanjianqie','Four',67228966,4,8,'js_sz_guanjianqie'),(21,'麗枫酒店(苏州观前店)','酒店位于拥有150年历史的观前街,紧邻苏州四大园林、平江历史老街区。交通方便，步行至地铁1号线（乐桥站7号出口）、4号线（察院场站2号出口）仅300米；距离拙政园 、网师园、狮子林均5分钟车程；距离苏州火车站、苏州乐园、 金鸡湖、寒山寺、虎丘仅15分钟左右车程，高铁至上海虹桥站只需20分钟。其中热门景区金鸡湖景区是国内极少数对外开放的重点景区之一，包含了文化会展区、时尚购物区、休闲美食区、城市观光区、中央水景区五大功能区。','姑苏区观前街212号（地铁4号线察院场站2号出口东100米，地铁1号线乐桥站7号出口北500米）','guanjianqie','Four',67871177,4.5,8,'js_sz_guanjianqie'),(22,'苏州万豪酒店','苏州万豪酒店地处苏州市中心，毗邻繁华商业区，信步可达新区商业街、家乐福大型购物广场；便捷通往诸多高速公路、苏州高新区和苏州工业园区。酒店距寒山寺、留园、西园寺、观前街和苏州乐园等著名旅游景点仅5-10分钟车程。 　　苏州万豪酒店楼高48层，现代化的楼体造型，寓意月照虎丘塔，与苏州古城风貌交相辉映，成为市区的地标性建筑。','姑苏区干将西路1296号（近桐泾路、地铁1号线西环路站3号出口）','guanjianqie','Five',82258888,4.8,8,'js_sz_guanjianqie'),(23,'汉庭(杭州西湖定安路地铁站店)','酒店位于上城区定安路128号，地铁一号线定安路站B出口步行到达酒店，座落在繁华湖滨商圈，毗邻美丽的西子湖畔。适宜、购物和旅游。闹中取静，交通便捷，秉承“人在旅途，家在这里”的服务理念，提供优质床上用品、宽带上网、豪华淋浴设备、舒适办公桌椅、丰富的电视节目等，为旅途中的人们带来一份温馨舒适的享受。','上城区定安路128号（距定安路地铁口50米，近西湖）','xihu','Three',56920788,4.1,14,'zj_hz_xihu'),(24,'如家精选酒店(杭州西湖河坊街南宋御街店)','本店步行至西湖10分钟，位于步行街河坊街和南宋御街步行街内，小桥流水的景色，娴静优美，又紧邻美食街高银街，大型超市家乐福/世纪联华，大型商场银泰百货/解百商厦，都近在咫尺。且酒店交通便利，鼓楼公交站有众多线路可到达西湖，雷峰塔，灵隐寺，音乐喷泉，钱江世纪城等旅游景点。','上城区中山中路17号','xihu','Four',87807079,4.5,14,'zj_hz_xihu'),(25,'杭州西湖国宾馆','沉醉西湖文化，尽享国宾尊贵！ 西湖国宾馆是“G20杭州峰会”和“金砖五国领导人非正式会晤（B5）”中 国国 家领导人会见、宴请外国元首的场所。 宾馆由知名的园林设计大师戴念慈先生重新设计，庭院内建筑精巧、曲廊修竹、异步一景，加之丰富的人文景观而冠居“西湖第壹名园”。 天成佳境，宾馆位于西湖核心，被誉为“西湖里的西湖”。它背山面湖，占地36万平方米（540多亩），独揽2000多米湖岸线。居于此，近观“苏堤春晓”，远眺“雷峰夕照”，步行可至“花港观鱼”、“曲院风荷”，半小时车程可达杭州所有景点。','西湖区杨公堤18号（近曲院风荷、花港观鱼）','xihu','Five',87979889,5,14,'zj_hz_xihu');
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_image`
--

DROP TABLE IF EXISTS `hotel_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel_image` (
  `hotelId` int(11) NOT NULL,
  `img` mediumblob,
  PRIMARY KEY (`hotelId`),
  UNIQUE KEY `hotel_image_hotelId_uindex` (`hotelId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_image`
--

/*!40000 ALTER TABLE `hotel_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderlist`
--

DROP TABLE IF EXISTS `orderlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `hotelId` int(11) DEFAULT NULL,
  `hotelName` varchar(255) DEFAULT NULL,
  `checkInDate` varchar(255) DEFAULT NULL,
  `checkOutDate` varchar(255) DEFAULT NULL,
  `roomType` varchar(255) DEFAULT NULL,
  `roomNum` int(255) DEFAULT NULL,
  `peopleNum` int(255) DEFAULT NULL,
  `haveChild` tinytext,
  `createDate` varchar(255) DEFAULT NULL,
  `price` decimal(65,0) DEFAULT NULL,
  `clientName` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `orderState` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderlist`
--

LOCK TABLES `orderlist` WRITE;
/*!40000 ALTER TABLE `orderlist` DISABLE KEYS */;
INSERT INTO `orderlist` VALUES (14,4,1,'汉庭（南京夫子庙中华门店）','2020-06-23','2020-06-25','BigBed',2,2,'1','2020-04-26',398,'测试一号','12345678919','已退房'),(15,4,1,'汉庭（南京夫子庙中华门店）','2020-04-27','2020-04-28','BigBed',2,2,'1','2020-04-26',398,'测试一号','12345678919','已取消'),(16,4,1,'汉庭（南京夫子庙中华门店）','2020-05-02','2020-05-04','BigBed',3,3,'1','2020-04-26',845,'测试一号','12345678919','已取消'),(17,4,2,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-25','Family',2,2,'1','2020-05-15',798,'测试一号','12345678919','已退房'),(18,6,1,'汉庭（南京夫子庙中华门店）','2020-05-26','2020-05-27','BigBed',1,1,'0','2020-05-25',199,NULL,NULL,'已取消'),(19,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-30','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(20,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已取消'),(21,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-30','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(22,6,1,'汉庭（南京夫子庙中华门店）','2020-05-27','2020-05-30','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(23,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-25','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(24,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已取消'),(25,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(26,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(27,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(28,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',1,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(29,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(30,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(31,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,3,'0','2020-05-25',1094,NULL,NULL,'异常'),(32,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,1,'0','2020-05-25',1094,NULL,NULL,'异常'),(33,6,1,'汉庭（南京夫子庙中华门店）','2020-05-25','2020-05-28','BigBed',2,1,'0','2020-05-25',1094,NULL,NULL,'异常'),(34,5,1,'汉庭（南京夫子庙中华门店）','2020-05-27','2020-05-30','BigBed',2,2,'1','2020-05-27',3200,'测试二号','12345678911','已退房'),(35,5,1,'汉庭（南京夫子庙中华门店）','2020-05-27','2020-05-30','BigBed',2,2,'1','2020-05-27',1600,'测试二号','12345678911','已退房'),(36,6,1,'汉庭（南京夫子庙中华门店）','2020-05-29','2020-05-31','BigBed',2,2,'0','2020-05-28',3552,NULL,'9090\r\n','异常'),(38,5,1,'汉庭（南京夫子庙中华门店）','2020-06-23','2020-06-24','BigBed',1,2,'0','2020-06-23',198,'测试二号','12345678911','异常'),(39,5,1,'汉庭（南京夫子庙中华门店）','2020-06-23','2020-06-24','BigBed',1,2,'0','2020-06-23',198,'测试二号','12345678911','已取消'),(40,5,1,'汉庭（南京夫子庙中华门店）','2020-06-23','2020-06-23','BigBed',1,2,'0','2020-06-23',198,'测试二号','23','已退房'),(41,5,1,'汉庭（南京夫子庙中华门店）','2020-06-26','2020-06-26','BigBed',1,2,'1','2020-06-24',198,'测试二号','12345678911','已退房'),(42,5,1,'汉庭（南京夫子庙中华门店）','2020-06-26','2020-06-26','BigBed',3,4,'1','2020-06-24',594,'测试二号','12345678911','已退房'),(43,11,1,'汉庭（南京夫子庙中华门店）','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(44,11,1,'汉庭（南京夫子庙中华门店）','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(45,11,1,'汉庭（南京夫子庙中华门店）','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(46,11,1,'汉庭（南京夫子庙中华门店）','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(47,11,1,'汉庭（南京夫子庙中华门店）','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(48,11,1,'汉庭（南京夫子庙中华门店）','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(49,5,1,'汉庭（南京夫子庙中华门店）','2020-06-26','2020-06-26','BigBed',2,1,'1','2020-06-26',396,'测试二号','12345678911','已退房'),(50,5,1,'汉庭（南京夫子庙中华门店）','2020-06-26','2020-06-26','BigBed',2,1,'1','2020-06-26',396,'测试二号','12345678911','已退房'),(51,5,1,'汉庭（南京夫子庙中华门店）','2020-06-26','2020-06-26','BigBed',1,1,'1','2020-06-26',198,'测试二号','12345678911','已退房'),(52,5,8,'南京新街口苏宁诺富特酒店','2020-06-27','2020-06-27','BigBed',1,1,'1','2020-06-27',450,'用户1号','12345678911','已退房'),(53,5,25,'杭州西湖国宾馆','2020-07-01','2020-07-02','BigBed',1,1,'1','2020-06-27',1000,'用户1号','12345678911','已预订'),(54,5,10,'南京商茂国际酒店','2020-06-27','2020-06-27','BigBed',1,1,'1','2020-06-27',500,'用户1号','12345678911','已退房'),(55,5,14,'南京金陵状元楼大酒店','2020-06-27','2020-06-27','BigBed',1,1,'1','2020-06-27',555,'用户1号','12345678911','已退房'),(56,5,14,'南京金陵状元楼大酒店','2020-06-27','2020-06-27','BigBed',1,1,'1','2020-06-27',555,'用户1号','12345678911','已退房'),(57,5,8,'南京新街口苏宁诺富特酒店','2020-06-27','2020-06-27','DoubleBed',1,1,'1','2020-06-27',650,'用户1号','12345678911','已退房'),(58,5,14,'南京金陵状元楼大酒店','2020-06-27','2020-06-27','DoubleBed',1,1,'1','2020-06-27',700,'用户1号','12345678911','已执行'),(59,5,8,'南京新街口苏宁诺富特酒店','2020-06-27','2020-07-01','BigBed',1,1,'1','2020-06-27',1800,'用户1号','12345678911','已预订'),(60,5,11,'南京金丝利喜来登酒店','2020-06-27','2020-07-01','BigBed',1,1,'1','2020-06-27',2400,'用户1号','12345678911','已预订');
/*!40000 ALTER TABLE `orderlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES ('jiangsu','Jiangsu'),('zhejiang','Zhejiang');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` double DEFAULT NULL,
  `curNum` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `hotel_id` int(11) DEFAULT NULL,
  `roomType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (2,198,897,20,1,'BigBed'),(3,299,30,30,1,'DoubleBed'),(4,399,10,10,1,'Family'),(6,800,10,10,2,'Family'),(13,800,0,0,3,'BigBed'),(14,244,0,0,4,'BigBed'),(15,2,0,0,5,'BigBed'),(16,450,0,0,2,'BigBed'),(17,400,0,0,4,'Family'),(18,233,0,0,6,'BigBed'),(19,400,0,0,6,'DoubleBed'),(20,600,0,0,6,'Family'),(21,450,0,0,8,'BigBed'),(22,650,0,0,8,'DoubleBed'),(23,800,0,0,8,'Family'),(24,300,0,0,9,'BigBed'),(25,500,0,0,10,'BigBed'),(26,800,0,0,10,'DoubleBed'),(27,1000,0,0,10,'Family'),(28,600,0,0,11,'BigBed'),(29,800,0,0,11,'DoubleBed'),(30,1200,0,0,11,'Family'),(31,0,0,0,12,'BigBed'),(32,300,0,0,13,'BigBed'),(33,333,0,0,16,'BigBed'),(34,600,0,0,2,'DoubleBed'),(35,333,0,0,7,'BigBed'),(36,555,0,0,14,'BigBed'),(37,700,0,0,14,'DoubleBed'),(38,999,0,0,14,'Family'),(39,321,0,0,15,'BigBed'),(40,444,0,0,17,'BigBed'),(41,555,0,0,18,'BigBed'),(42,666,0,0,19,'BigBed'),(43,543,0,0,20,'BigBed'),(44,656,0,0,21,'BigBed'),(45,455,0,0,22,'BigBed'),(46,1000,0,0,25,'BigBed'),(47,2000,0,0,25,'DoubleBed'),(48,5000,0,0,25,'Family'),(49,420,0,0,24,'BigBed'),(50,333,0,0,23,'BigBed');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roomrepo`
--

DROP TABLE IF EXISTS `roomrepo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomrepo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentNum` int(11) NOT NULL DEFAULT '0',
  `roomId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roomRepo_room_id_fk` (`roomId`)
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roomrepo`
--

LOCK TABLES `roomrepo` WRITE;
/*!40000 ALTER TABLE `roomrepo` DISABLE KEYS */;
INSERT INTO `roomrepo` VALUES (1,'2020-05-21',7,2),(2,'2020-05-22',8,2),(3,'2020-05-23',100,2),(5,'2020-05-22',20,3),(6,'2020-05-23',20,3),(7,'2020-05-24',20,3),(8,'2020-05-30',58,2),(9,'2020-05-31',87,2),(10,'2020-05-28',98,2),(11,'2020-05-29',30,2),(12,'2020-06-23',31,2),(13,'2020-06-24',33,2),(18,'2020-07-01',11,-1),(19,'2020-07-01',6,2),(20,'2020-07-02',2,2),(21,'2020-07-03',11,2),(22,'2020-07-08',11,2),(23,'2020-06-26',11,2),(24,'2020-06-27',11,2),(25,'2020-06-26',11,14),(26,'2020-06-27',11,14),(27,'2020-07-01',3,3),(28,'2020-07-02',3,3),(29,'2020-07-01',3,4),(30,'2020-07-02',3,4),(31,'2020-07-01',3,6),(32,'2020-07-02',3,6),(33,'2020-07-01',3,16),(34,'2020-07-02',3,16),(35,'2020-07-01',3,14),(36,'2020-07-02',3,14),(37,'2020-07-01',3,18),(38,'2020-07-02',3,18),(39,'2020-07-01',3,19),(40,'2020-07-02',3,19),(41,'2020-07-01',3,20),(42,'2020-07-02',3,20),(43,'2020-07-01',1,21),(44,'2020-07-02',2,21),(45,'2020-07-01',2,22),(46,'2020-07-02',2,22),(47,'2020-07-01',3,23),(48,'2020-07-02',3,23),(49,'2020-07-01',3,24),(50,'2020-07-02',3,24),(51,'2020-07-01',2,25),(52,'2020-07-02',2,25),(53,'2020-07-01',3,26),(54,'2020-07-02',3,26),(55,'2020-07-01',3,27),(56,'2020-07-02',3,27),(57,'2020-07-01',2,28),(58,'2020-07-02',3,28),(59,'2020-07-01',3,29),(60,'2020-07-02',3,29),(61,'2020-07-01',3,30),(62,'2020-07-02',3,30),(63,'2020-07-01',3,31),(64,'2020-07-02',3,31),(65,'2020-07-01',3,32),(66,'2020-07-02',3,32),(67,'2020-07-01',3,33),(68,'2020-07-02',2,33),(69,'2020-07-01',3,34),(70,'2020-07-02',3,34),(71,'2020-07-01',3,15),(72,'2020-07-02',3,15),(73,'2020-07-01',3,35),(74,'2020-07-02',3,35),(75,'2020-07-01',1,36),(76,'2020-07-02',0,36),(77,'2020-07-01',2,37),(78,'2020-07-02',1,37),(79,'2020-07-01',3,38),(80,'2020-07-02',3,38),(81,'2020-07-01',3,39),(82,'2020-07-02',3,39),(83,'2020-07-01',3,40),(84,'2020-07-02',3,40),(85,'2020-07-01',3,41),(86,'2020-07-02',3,41),(87,'2020-07-01',3,42),(88,'2020-07-02',3,42),(89,'2020-07-01',3,43),(90,'2020-07-02',3,43),(91,'2020-07-01',3,44),(92,'2020-07-02',3,44),(93,'2020-07-01',3,45),(94,'2020-07-02',3,45),(95,'2020-07-01',2,46),(96,'2020-07-02',2,46),(97,'2020-07-01',3,47),(98,'2020-07-02',3,47),(99,'2020-07-01',3,48),(100,'2020-07-02',3,48),(101,'2020-07-01',3,49),(102,'2020-07-02',3,49),(103,'2020-07-01',3,50),(104,'2020-07-02',3,50),(105,'2020-06-27',2,21),(106,'2020-06-28',2,21),(107,'2020-06-29',2,21),(108,'2020-06-30',2,21),(109,'2020-06-27',2,28),(110,'2020-06-28',1,28),(111,'2020-06-29',1,28),(112,'2020-06-30',1,28);
/*!40000 ALTER TABLE `roomrepo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_permission`
--

DROP TABLE IF EXISTS `sys_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission` varchar(32) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_permission_permission_name_uindex` (`permission`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_permission`
--

LOCK TABLES `sys_permission` WRITE;
/*!40000 ALTER TABLE `sys_permission` DISABLE KEYS */;
INSERT INTO `sys_permission` VALUES (1,'admin_normal',NULL),(2,'htlmgr_normal',NULL),(3,'client_normal',NULL);
/*!40000 ALTER TABLE `sys_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_role_role_name_uindex` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'Admin'),(3,'Client'),(2,'HotelManager');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_permission`
--

DROP TABLE IF EXISTS `sys_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_permission` (
  `rpid` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(32) NOT NULL,
  `permission_name` varchar(32) NOT NULL,
  PRIMARY KEY (`rpid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_permission`
--

LOCK TABLES `sys_role_permission` WRITE;
/*!40000 ALTER TABLE `sys_role_permission` DISABLE KEYS */;
INSERT INTO `sys_role_permission` VALUES (1,'Client','client_normal'),(2,'HotelManager','client_normal'),(3,'HotelManager','htlmgr_normal'),(4,'Admin','admin_normal'),(5,'Admin','client_normal'),(6,'Admin','htlmgr_normal');
/*!40000 ALTER TABLE `sys_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `credit` double(255,0) DEFAULT NULL,
  `usertype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'mgr@nju.edu.cn','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','supermgr','17305200812',100,'Admin'),(4,'1012681@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','用户0号','12345678919',498,'Client'),(5,'123@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','用户1号','12345678911',29492,'Client'),(6,'000@qq.com','$2a$10$6FJxonw0eTFAK11aE5NgceI9qsNZYLcv4wdOaZa91ky0E0thf.HjK','酒店管理员0号','13333217870',-10973,'HotelManager'),(7,'001@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','酒店管理员1号','10086',0,'HotelManager'),(8,'002@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','酒店管理员2号','0502000',9000,'HotelManager'),(9,'12222@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','用户2号','110@qq.com',100,'Client'),(11,'jinyu@qq.com','$2a$10$ZF/pA2uZfKvKx75C1JGayOWJQfvxs9IJyLHw9WXqoKmx6TikHblZO','用户3号','13333217870',-3464,'Client'),(14,'003@qq.com','$2a$10$0a6QjewYjsHUqjFOuiNdlOCgJ7lnTti9eZpwooU6aRF8kQ5XSqZqK','酒店管理员3号','9999',0,'HotelManager');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_image`
--

DROP TABLE IF EXISTS `user_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_image` (
  `userId` int(11) NOT NULL,
  `img` mediumblob,
  UNIQUE KEY `user_image_userId_uindex` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_image`
--

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-27 22:54:28
