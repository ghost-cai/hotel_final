-- MySQL dump 10.13  Distrib 5.7.30, for macos10.14 (x86_64)
--
-- Host: 127.0.0.1    Database: hotel
-- ------------------------------------------------------
-- Server version	5.7.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `belongstoent`
--

DROP TABLE IF EXISTS `belongstoent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `belongstoent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `entId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `belongsToEnt_ent_id_fk` (`entId`),
  KEY `belongsToEnt_user_id_fk` (`userId`),
  CONSTRAINT `belongsToEnt_ent_id_fk` FOREIGN KEY (`entId`) REFERENCES `enterprise` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `belongsToEnt_user_id_fk` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `belongstoent`
--

LOCK TABLES `belongstoent` WRITE;
/*!40000 ALTER TABLE `belongstoent` DISABLE KEYS */;
/*!40000 ALTER TABLE `belongstoent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bizregion`
--

DROP TABLE IF EXISTS `bizregion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bizregion` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `bizRegion_city_id_fk` (`city_id`),
  CONSTRAINT `bizRegion_city_id_fk` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bizregion`
--

LOCK TABLES `bizregion` WRITE;
/*!40000 ALTER TABLE `bizregion` DISABLE KEYS */;
INSERT INTO `bizregion` VALUES ('js_nj_xianlin','Xianlin','js_nanjing'),('js_nj_xinjiekou','Xinjiekou','js_nanjing'),('zj_hz_xihu','Xihu','zj_hangzhou');
/*!40000 ALTER TABLE `bizregion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `province_id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `city_province_id_fk` (`province_id`),
  CONSTRAINT `city_province_id_fk` FOREIGN KEY (`province_id`) REFERENCES `province` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES ('js_nanjing','Nanjing','jiangsu'),('js_suzhou','Suzhou','jiangsu'),('zj_hangzhou','Hangzhou','zhejiang');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `rate` double NOT NULL,
  `commentDetail` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Comment_order_id_fk` (`orderId`),
  CONSTRAINT `Comment_order_id_fk` FOREIGN KEY (`orderId`) REFERENCES `orderlist` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,14,4.85,'fuck'),(2,15,4.85,'fuck'),(3,16,4.85,'fuck');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon`
--

DROP TABLE IF EXISTS `coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `hotelId` int(11) DEFAULT '-1',
  `couponType` int(11) NOT NULL,
  `couponName` varchar(255) NOT NULL,
  `target_money` int(11) DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `discount_money` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon`
--

LOCK TABLES `coupon` WRITE;
/*!40000 ALTER TABLE `coupon` DISABLE KEYS */;
INSERT INTO `coupon` VALUES (2,'满500-100优惠',1,3,'满减优惠券',500,0,1,NULL,NULL,100),(15,'限时',1,4,'xzh',133,0,1,'2020-05-28 00:00:00','2020-06-02 00:00:00',23),(16,'1000-100优惠',-1,3,'100',1000,0,1,NULL,NULL,100);
/*!40000 ALTER TABLE `coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creditinfo`
--

DROP TABLE IF EXISTS `creditinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creditinfo` (
  `mut_id` int(11) NOT NULL AUTO_INCREMENT,
  `time` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `change_val` double(255,0) NOT NULL,
  `after_change` double(255,0) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`mut_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creditinfo`
--

LOCK TABLES `creditinfo` WRITE;
/*!40000 ALTER TABLE `creditinfo` DISABLE KEYS */;
INSERT INTO `creditinfo` VALUES (4,'2020-06-23',0,'AddFrc',1000,9000,8),(5,'2020-06-23',14,'OrderExec',398,498,4),(6,'2020-06-23',0,'AddFrc',1000,23798,5),(7,'2020-06-24',38,'OrderErr',-198,23600,5),(8,'2020-06-25',43,'OrderErr',-594,-494,11),(9,'2020-06-25',44,'OrderErr',-594,-1088,11),(10,'2020-06-25',45,'OrderErr',-594,-1682,11),(11,'2020-06-25',46,'OrderErr',-594,-2276,11),(12,'2020-06-25',47,'OrderErr',-594,-2870,11),(13,'2020-06-25',48,'OrderErr',-594,-3464,11);
/*!40000 ALTER TABLE `creditinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enterprise`
--

DROP TABLE IF EXISTS `enterprise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enterprise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entName` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `inviteCode` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enterprise`
--

LOCK TABLES `enterprise` WRITE;
/*!40000 ALTER TABLE `enterprise` DISABLE KEYS */;
INSERT INTO `enterprise` VALUES (1,'NJU','nju2020');
/*!40000 ALTER TABLE `enterprise` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotelName` varchar(255) NOT NULL,
  `hotelDescription` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `bizRegion` varchar(255) DEFAULT NULL,
  `hotelStar` varchar(255) DEFAULT NULL,
  `phoneNum` int(11) DEFAULT NULL,
  `rate` double DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `biz_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
INSERT INTO `hotel` VALUES (1,'汉庭酒店','欢迎您入住','南京市珠江路222号','XiDan','Four',1829373819,4.8,6,'js_nj_xianlin'),(2,'儒家酒店','欢迎您入住','南京市鼓楼区珠江路268号','XiDan','Four',1829373819,4.8,6,'js_nj_xinjiekou'),(3,'桂圆酒店','欢迎您入住','南京市栖霞区珠江路268号','XiDan','Four',1829553719,4.8,7,'js_nj_xinjiekou'),(4,'法家酒店','撒旦撒','江苏省南京市仙林大道南京大学',NULL,'Three',1231231,4,6,'js_nj_xianlin'),(5,'法家酒店','撒旦撒','江苏省南京市仙林大道南京大学',NULL,'One',1231231,4,6,'js_nj_xianlin'),(6,'goosasdasdad','gppp','sss','xidan','Five',123443,4,6,'js_nj_xianlin');
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_image`
--

DROP TABLE IF EXISTS `hotel_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel_image` (
  `hotelId` int(11) NOT NULL,
  `img` mediumblob,
  PRIMARY KEY (`hotelId`),
  UNIQUE KEY `hotel_image_hotelId_uindex` (`hotelId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_image`
--

LOCK TABLES `hotel_image` WRITE;
/*!40000 ALTER TABLE `hotel_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `hotel_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderlist`
--

DROP TABLE IF EXISTS `orderlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) DEFAULT NULL,
  `hotelId` int(11) DEFAULT NULL,
  `hotelName` varchar(255) DEFAULT NULL,
  `checkInDate` varchar(255) DEFAULT NULL,
  `checkOutDate` varchar(255) DEFAULT NULL,
  `roomType` varchar(255) DEFAULT NULL,
  `roomNum` int(255) DEFAULT NULL,
  `peopleNum` int(255) DEFAULT NULL,
  `haveChild` tinytext,
  `createDate` varchar(255) DEFAULT NULL,
  `price` decimal(65,0) DEFAULT NULL,
  `clientName` varchar(255) DEFAULT NULL,
  `phoneNumber` varchar(255) DEFAULT NULL,
  `orderState` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderlist`
--

LOCK TABLES `orderlist` WRITE;
/*!40000 ALTER TABLE `orderlist` DISABLE KEYS */;
INSERT INTO `orderlist` VALUES (14,4,1,'汉庭酒店','2020-06-23','2020-06-25','BigBed',2,2,'1','2020-04-26',398,'测试一号','12345678919','已退房'),(15,4,1,'汉庭酒店','2020-04-27','2020-04-28','BigBed',2,2,'1','2020-04-26',398,'测试一号','12345678919','已取消'),(16,4,1,'汉庭酒店','2020-05-02','2020-05-04','BigBed',3,3,'1','2020-04-26',845,'测试一号','12345678919','已取消'),(17,4,2,'儒家酒店','2020-05-25','2020-05-25','Family',2,2,'1','2020-05-15',798,'测试一号','12345678919','已退房'),(18,6,1,'汉庭酒店','2020-05-26','2020-05-27','BigBed',1,1,'0','2020-05-25',199,NULL,NULL,'已取消'),(19,6,1,'汉庭酒店','2020-05-25','2020-05-30','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(20,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已取消'),(21,6,1,'汉庭酒店','2020-05-25','2020-05-30','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(22,6,1,'汉庭酒店','2020-05-27','2020-05-30','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(23,6,1,'汉庭酒店','2020-05-25','2020-05-25','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已退房'),(24,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'已取消'),(25,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(26,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(27,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(28,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',1,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(29,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(30,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,2,'0','2020-05-25',1094,NULL,NULL,'异常'),(31,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,3,'0','2020-05-25',1094,NULL,NULL,'异常'),(32,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,1,'0','2020-05-25',1094,NULL,NULL,'异常'),(33,6,1,'汉庭酒店','2020-05-25','2020-05-28','BigBed',2,1,'0','2020-05-25',1094,NULL,NULL,'异常'),(34,5,1,'汉庭酒店','2020-05-27','2020-05-30','BigBed',2,2,'1','2020-05-27',3200,'测试二号','12345678911','已退房'),(35,5,1,'汉庭酒店','2020-05-27','2020-05-30','BigBed',2,2,'1','2020-05-27',1600,'测试二号','12345678911','已退房'),(36,6,1,'汉庭酒店','2020-05-29','2020-05-31','BigBed',2,2,'0','2020-05-28',3552,NULL,'9090\r\n','异常'),(37,6,3,'桂圆酒店','2020-05-26','2020-05-30','BigBed',1,1,'0','2020-05-28',800,NULL,'9090\r\n','异常'),(38,5,1,'汉庭酒店','2020-06-23','2020-06-24','BigBed',1,2,'0','2020-06-23',198,'测试二号','12345678911','异常'),(39,5,1,'汉庭酒店','2020-06-23','2020-06-24','BigBed',1,2,'0','2020-06-23',198,'测试二号','12345678911','已取消'),(40,5,1,'汉庭酒店','2020-06-23','2020-06-23','BigBed',1,2,'0','2020-06-23',198,'测试二号','23','已退房'),(41,5,1,'汉庭酒店','2020-07-01','2020-07-02','BigBed',1,2,'1','2020-06-24',198,'测试二号','12345678911','已预订'),(42,5,1,'汉庭酒店','2020-07-01','2020-07-02','BigBed',3,4,'1','2020-06-24',594,'测试二号','12345678911','已预订'),(43,11,1,'汉庭酒店','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(44,11,1,'汉庭酒店','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(45,11,1,'汉庭酒店','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(46,11,1,'汉庭酒店','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(47,11,1,'汉庭酒店','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常'),(48,11,1,'汉庭酒店','2020-05-21','2020-05-22','BigBed',3,2,'1','2020-06-25',594,'zhu','17305200812','异常');
/*!40000 ALTER TABLE `orderlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `province`
--

DROP TABLE IF EXISTS `province`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `province` (
  `id` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `province`
--

LOCK TABLES `province` WRITE;
/*!40000 ALTER TABLE `province` DISABLE KEYS */;
INSERT INTO `province` VALUES ('jiangsu','Jiangsu'),('zhejiang','Zhejiang');
/*!40000 ALTER TABLE `province` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` double DEFAULT NULL,
  `curNum` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `hotel_id` int(11) DEFAULT NULL,
  `roomType` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (2,198,897,20,1,'BigBed'),(3,299,30,30,1,'DoubleBed'),(4,399,10,10,1,'Family'),(6,399,10,10,2,'Family'),(13,800,0,0,3,'BigBed'),(14,100,0,0,4,'BigBed'),(15,2,0,0,5,'BigBed');
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roomrepo`
--

DROP TABLE IF EXISTS `roomrepo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roomrepo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currentNum` int(11) NOT NULL DEFAULT '0',
  `roomId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roomRepo_room_id_fk` (`roomId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roomrepo`
--

LOCK TABLES `roomrepo` WRITE;
/*!40000 ALTER TABLE `roomrepo` DISABLE KEYS */;
INSERT INTO `roomrepo` VALUES (1,'2020-05-21',7,2),(2,'2020-05-22',8,2),(3,'2020-05-23',100,2),(5,'2020-05-22',20,3),(6,'2020-05-23',20,3),(7,'2020-05-24',20,3),(8,'2020-05-30',58,2),(9,'2020-05-31',87,2),(10,'2020-05-28',98,2),(11,'2020-05-29',30,2),(12,'2020-06-23',31,2),(13,'2020-06-24',33,2),(18,'2020-07-01',11,-1),(19,'2020-07-01',11,2),(20,'2020-07-02',7,2),(21,'2020-07-03',11,2),(22,'2020-07-08',11,2);
/*!40000 ALTER TABLE `roomrepo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_permission`
--

DROP TABLE IF EXISTS `sys_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permission` varchar(32) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_permission_permission_name_uindex` (`permission`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_permission`
--

LOCK TABLES `sys_permission` WRITE;
/*!40000 ALTER TABLE `sys_permission` DISABLE KEYS */;
INSERT INTO `sys_permission` VALUES (1,'admin_normal',NULL),(2,'htlmgr_normal',NULL),(3,'client_normal',NULL);
/*!40000 ALTER TABLE `sys_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role`
--

DROP TABLE IF EXISTS `sys_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sys_role_role_name_uindex` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role`
--

LOCK TABLES `sys_role` WRITE;
/*!40000 ALTER TABLE `sys_role` DISABLE KEYS */;
INSERT INTO `sys_role` VALUES (1,'Admin'),(3,'Client'),(2,'HotelManager');
/*!40000 ALTER TABLE `sys_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_role_permission`
--

DROP TABLE IF EXISTS `sys_role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_role_permission` (
  `rpid` int(11) NOT NULL AUTO_INCREMENT,
  `role_name` varchar(32) NOT NULL,
  `permission_name` varchar(32) NOT NULL,
  PRIMARY KEY (`rpid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_role_permission`
--

LOCK TABLES `sys_role_permission` WRITE;
/*!40000 ALTER TABLE `sys_role_permission` DISABLE KEYS */;
INSERT INTO `sys_role_permission` VALUES (1,'Client','client_normal'),(2,'HotelManager','client_normal'),(3,'HotelManager','htlmgr_normal'),(4,'Admin','admin_normal'),(5,'Admin','client_normal'),(6,'Admin','htlmgr_normal');
/*!40000 ALTER TABLE `sys_role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `phonenumber` varchar(255) DEFAULT NULL,
  `credit` double(255,0) DEFAULT NULL,
  `usertype` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'mgr@nju.edu.cn','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','supermgr','17305200812',100,'Admin'),(4,'1012681@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','测试一号','12345678919',498,'Client'),(5,'123@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','测试二号','12345678911',23600,'Client'),(6,'333@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','管理员1','9090\r\n',-10973,'HotelManager'),(7,'999@nju.edu.cn','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','企业用户nju999','10086',0,'HotelManager'),(8,'1019@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa',NULL,NULL,9000,'HotelManager'),(9,'12222@qq.com','$2a$10$08cGz3j7u.1L5FNR89PnIuGCftCzFh907or61i3kh/h7zQqxMPIXa','Jinyu','110@qq.com',100,'Client'),(11,'jinyu@qq.com','$2a$10$WQMnlQhBiNa0gc2Qu.el3eKcry5JBJhYSPAr2QW8rUFckteqP2so6','zhu','17305200812',-3464,'Client');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_image`
--

DROP TABLE IF EXISTS `user_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_image` (
  `userId` int(11) NOT NULL,
  `img` mediumblob,
  UNIQUE KEY `user_image_userId_uindex` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_image`
--

LOCK TABLES `user_image` WRITE;
/*!40000 ALTER TABLE `user_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-06-25 15:57:44
