-- auto-generated definition
create table user_image
(
    userId int        not null,
    img    mediumblob null,
    constraint user_image_userId_uindex
        unique (userId)
);


-- auto-generated definition
create table hotel_image
(
    hotelId int        not null,
    img     mediumblob null,
    constraint hotel_image_hotelId_uindex
        unique (hotelId)
);

alter table hotel_image
    add primary key (hotelId);

